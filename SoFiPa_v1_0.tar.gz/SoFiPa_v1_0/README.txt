SoFiPa: Sort Filament Particles


#### TERMINOLOGY
filament particle: a square filament segment
extracted particles: particles extracted using Relion Extract (Extract/jobxxx/particles.star)     
refined particles: particles after running Relion Refine3D (Refine3D/jobxxx/run_data.star)
continuous fragment: a non-breaking fragment in a long filament; it contains five or more properly particles
consistently aligned particle: a particle properply aligned to the expected position
inconsistently aligned particle: a particle properly aligned to the previous or next position                   


#### MODES
0sep (old 0b): smooth defocusU, defocusV, defocusA, angleTilt, anglePsi for extracted particles
      IN:  Extract/jobxxx/particles.star (after particle local CTF estimation)
      OUT: ProteinName_plCTF_jobxxx_particles_sel_0sep.star (for running Relion Refine3D)
0srp (old 0a): smooth defocusU, defocusV, defocusA, angleTilt, anglePsi for refined particles
      IN:  Refine3D/jobxxx/run_data.star (after running Relion Refine3D)
      OUT: ProteinName_plCTF_jobxxx_run_data_sel_0srp.star (for running Relion Refine3D)

1scf (old 1a): select particles in continuous fragments (rise range: +/-5 pixels; twist range: +/-5 degrees)
      IN:  Refine3D/jobxxx/run_data.star (after running SoFiPa in 0sep mode and Relion Refine3D)
      OUT: ProteinName_plCTF_jobxxx_run_data_sel_1scf.star (for running SoFiPa in 2eca mode)
2eca (old 1b): estimate consistent alignments (shiftXY, angleRot) for particles in continuous fragments
      IN:  ProteinName_plCTF_jobxxx_run_data_sel_1scf.star (after running SoFiPa in 1scf mode)  
      OUT: ProteinName_plCTF_jobxxx_run_data_sel_1scf.star (for running Relion Refine3D)

3sca (old 2a): select consistently aligned particles in continuous fragments in defined rise and twist ranges (+/-2 sd)
      IN:  Refine3D/jobxxx/run_data.star (after running SoFiPa in 2eca mode and Relion Refine3D)
      OUT: ProteinName_plCTF_jobxxx_run_data_sel_3sca.star (for running relion_reconstruct and post-processing)

Xcrt (old Xa): calculate the rise and twist for consistently aligned particles only
      IN:  Refine3D/jobxxx/run_data.star (after running SoFiPa in 2eca mode and Relion Refine3D usually before 3sca)
      OUT: ProteinName_plCTF_jobxxx_run_data_all_xcrt.star (convert it to .csv w/ star2csv; for plotting with R) 
           

#### COMPILATION
# You need to have a c++ compiler and boost library installed first.
# Tested platforms: Red Hat Enterprise Linux 7.5 (g++: 4.8.5; boost: 1.53.0)
#                   MacOS 10.13.4 (xcode: 9.4.1/c++: 4.2.1; boost: 1.68.0)
make clean
make


#### RUN
./sofipa -parFile sofipa_ProteinName_0sep.par > temp_ProteinName_0sep

e.g.,

sofipa -parFile  sofipa_ADPPiPA5_plCTF_j011_Xcrt_5k_lines.par > temp_sofipa_ADPPiPA5_plCTF_j011_Xcrt_5k_lines.log
