// TEMPLATE CLASS:         TC_StarToCsv.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_StarToCsv.h and TC_StarToCsv.cpp in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TC_StarToCsv.h"

** After defining 'inputFileName' and 'outputFileName', add ---
   StarToCsv s2c;
   s2c.star2csv(inputFileName, outputFileName);  
*/


#pragma once 
// It serves the same purpose as include guards.
// It tells the preprocesser to include the current source file only once in a single compilation. 

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <string>
// String class; string object where the extracted line is stored.


#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 



class StarToCsv {

public:
    StarToCsv();
    ~StarToCsv();
    void star2csv(std::string inputFileName, std::string outputFileName);
    
};  



