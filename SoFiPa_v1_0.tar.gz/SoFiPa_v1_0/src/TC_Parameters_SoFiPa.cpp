// TO COMPILE: g++ -std=c++11 -c TC_Parameters.cpp -o TC_Parameters.o
// TO LINK   :  see the 'Makefile'


#include "TC_Parameters_SoFiPa.h"

#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>

#include <cstdlib>
//C Standard General Utilities Library; exit; 

#include <boost/algorithm/string.hpp>
//Split algorithms are an extension to the find iterator for one common usage scenario. 
//These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cctype>
// Character handling functions; including isspace(int c)



Parameters::Parameters()
{
}


Parameters::~Parameters()
{
}

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
// local function:                    declared and defined in .cpp (but not in .h) and called (from the same .cpp)
// Inside class member function:      declared and defined in (.h or main.cpp) and called after creating an object
// outside class member function:     declared in (.h), defined in (.cpp) and called after creating an object


void Parameters::storeParameterNamesAndValues(std::string parName, std::string parValue)
{
  if      ( parName == "parFile"                     ) {} // parameter file
  else if ( parName == "mode"                        ) {mode       = parValue; modeF       = 1;} 
  //else if ( parName == "original_run_data_star"      ) {original_run_data_star       = parValue; original_run_data_starF       = 1;}
  else if ( parName == "inp_run_data_star"      ) {inp_run_data_star       = parValue; inp_run_data_starF       = 1;}  
  //else if ( parName == "updated_run_data_star_est_all_RLN") {updated_run_data_star_est_all_RLN = parValue; updated_run_data_star_est_all_RLNF = 1;}	   
  //else if ( parName == "updated_run_data_star_est_all_CHK") {updated_run_data_star_est_all_CHK = parValue; updated_run_data_star_est_all_CHKF = 1;}  
  //else if ( parName == "updated_run_data_star_cal_sel_RLN") {updated_run_data_star_cal_sel_RLN = parValue; updated_run_data_star_cal_sel_RLNF = 1;}	   
  //else if ( parName == "updated_run_data_star_cal_sel_CHK") {updated_run_data_star_cal_sel_CHK = parValue; updated_run_data_star_cal_sel_CHKF = 1;} 
     
  else if ( parName == "out_run_data_star_all") {out_run_data_star_all = parValue; out_run_data_star_allF = 1;}  
  else if ( parName == "out_run_data_star_sel") {out_run_data_star_sel = parValue; out_run_data_star_selF = 1;}	   
  	
  //else if ( parName == "updated_run_data_star_RELION") {updated_run_data_star_RELION = parValue; updated_run_data_star_RELIONF = 1;}	   
  //else if ( parName == "updated_run_data_star_CHECK" ) {updated_run_data_star_CHECK  = parValue; updated_run_data_star_CHECKF  = 1;}	   

  else if ( parName == "rlnCoordinateXLabel"         ) {rlnCoordinateXLabel          = parValue; rlnCoordinateXLabelF          = 1;}	     
  else if ( parName == "rlnCoordinateYLabel"         ) {rlnCoordinateYLabel          = parValue; rlnCoordinateYLabelF          = 1;}
  else if ( parName == "rlnOriginXLabel"             ) {rlnOriginXLabel              = parValue; rlnOriginXLabelF              = 1;}	     
  else if ( parName == "rlnOriginYLabel"             ) {rlnOriginYLabel              = parValue; rlnOriginYLabelF              = 1;}	     
  else if ( parName == "rlnAngleRotLabel"            ) {rlnAngleRotLabel             = parValue; rlnAngleRotLabelF             = 1;}
  else if ( parName == "rlnAngleTiltLabel"           ) {rlnAngleTiltLabel            = parValue; rlnAngleTiltLabelF            = 1;}	      
  else if ( parName == "rlnAnglePsiLabel"            ) {rlnAnglePsiLabel             = parValue; rlnAnglePsiLabelF             = 1;}	    
  else if ( parName == "rlnDefocusULabel"	     ) {rlnDefocusULabel             = parValue; rlnDefocusULabelF             = 1;}	       
  else if ( parName == "rlnDefocusVLabel"            ) {rlnDefocusVLabel             = parValue; rlnDefocusVLabelF             = 1;} 	
  else if ( parName == "rlnDefocusAngleLabel"        ) {rlnDefocusAngleLabel         = parValue; rlnDefocusAngleLabelF         = 1;}       
  else if ( parName == "rlnHelicalTrackLengthLabel"  ) {rlnHelicalTrackLengthLabel   = parValue; rlnHelicalTrackLengthLabelF   = 1;}     
  
  else if ( parName == "rlnRiseLabel"                ) {rlnRiseLabel                 = parValue; rlnRiseLabelF                 = 1;}
  else if ( parName == "rlnTwistLabel"               ) {rlnTwistLabel                = parValue; rlnTwistLabelF                = 1;}  			
  else if ( parName == "rlnDThetaLabel"              ) {rlnDThetaLabel               = parValue; rlnDThetaLabelF               = 1;}	
  else if ( parName == "rlnDPsiLabel"                ) {rlnDPsiLabel                 = parValue; rlnDPsiLabelF                 = 1;}	
  else if ( parName == "rlnDiscontinuityLabel"       ) {rlnDiscontinuityLabel        = parValue; rlnDiscontinuityLabelF        = 1;}	

  else if ( parName == "helix_rise_mean"             ) {helix_rise_mean         = std::stod(parValue); helix_rise_meanF         = 1;}	
  else if ( parName == "helix_rise_sd"               ) {helix_rise_sd           = std::stod(parValue); helix_rise_sdF           = 1;}
  else if ( parName == "helix_rise_range_in_sd"      ) {helix_rise_range_in_sd  = std::stod(parValue); helix_rise_range_in_sdF  = 1;}  
  else if ( parName == "helix_rise_range"      ) {helix_rise_range  = std::stod(parValue); helix_rise_rangeF  = 1;}
  else if ( parName == "helix_twist_mean"            ) {helix_twist_mean        = std::stod(parValue); helix_twist_meanF        = 1;}	
  else if ( parName == "helix_twist_sd"              ) {helix_twist_sd          = std::stod(parValue); helix_twist_sdF          = 1;}
  else if ( parName == "helix_twist_range_in_sd"     ) {helix_twist_range_in_sd = std::stod(parValue); helix_twist_range_in_sdF = 1;}
  else if ( parName == "helix_twist_range"     ) {helix_twist_range = std::stod(parValue); helix_twist_rangeF = 1;}	  

  else { std::cout << "IGNORED PARAMETER <NAME> AND <VALUE>: <" << parName << "> <" << parValue << ">\n";}      
}


////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
void Parameters::parseCommandLine(std::vector<std::string> argList)
{
  std::string parName;
  std::string parValue; 
  for(std::vector<std::string>::iterator it=argList.begin(); it!=argList.end();it++)
  {
    parName=*it;
    std::vector<std::string>::iterator nextArgument = it+1;

    if (parName.substr(0,1) == "-" && nextArgument != argList.end())
    {
      parName.erase(0,1); //erase "-" at the beginning of of line in 
      parValue = *nextArgument;
      //std::cout <<  "parName " <<  parName << " parValue " << parValue << "\n";
      storeParameterNamesAndValues(parName, parValue);
      it++; // every other argument   
    }
  }
}


////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
void Parameters::parseParameterFile(const std::string parameterFileName)
{
  std::ifstream parameterFileS(parameterFileName.c_str());
  if (!parameterFileS){ std::cout << "FAIL to open: " << parameterFileName << "\n"; return;}

  std::string lineInParameterFile;
  std::string parName;
  std::string parValue;	 
  while(std::getline(parameterFileS, lineInParameterFile))
  {
    // lineInParameterFile: -voltage  300  kV  # /// Accelerating Voltage (in KiloVolts)    
    //std::cout << lineInInputFile << "\n";

    std::vector<std::string> vectorContainingTheSplitLine;
    boost::split(vectorContainingTheSplitLine, lineInParameterFile, boost::is_any_of("\t "),boost::token_compress_on );

    //std::cout << vectorContainingTheSplitLine[i] << "\n";
    parName = vectorContainingTheSplitLine[0];
    //std::cout <<  "parName" << parName.substr(0,2) << "\n";		    
    if (parName.substr(0,1) == "_")
    {
      parName.erase(0,1); //erase "-" at the beginning of of line in 
      parValue = vectorContainingTheSplitLine[1];
      //std::cout <<  "parName " <<  parName << " parValue " << parValue << "\n";
      storeParameterNamesAndValues(parName, parValue);
    } // if 
  } // while
} // void 

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100  

Parameters::Parameters(std::vector<std::string> argList)
{
    
  //if (argList.size() % 2 != 0) { std::cout << "ERROR: At least, one parameter was specified incorrectly.\n"; exit(EXIT_FAILURE);}
  
  // Check if .par file is among the parameters and if so parse it first.
  // The command line parameters have higher priority than those in the par file.
  // The command line parameters can change any parameters set by .par file.
  int parFileExists = 0; // for checking the existance of .par file
  for(std::vector<std::string>::iterator it=argList.begin(); it!=argList.end(); it++)
  {
    if((*it)=="-parFile")
    {
      std::vector<std::string>::iterator nextArgument = it + 1;
      std::cout << "Parsing the parameter file: " << *nextArgument << "\n";
      parseParameterFile( (*nextArgument) );
      parFileExists = 1;
    } // if
  } // for
  
  if (parFileExists == 1){ 
  std::cout << "Parsing the command line. \n";
  //std::cout << "Command line values overwrite their corresponding parts in the parameter file.\n";
  } else { std::cout << "Parsing the command line. \n";}
  
  parseCommandLine(argList);

} // Parameters::Parameters(std::vector<std::string> argList)

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
//void Parameters::checkParameters(std::string mode)
void Parameters::checkParameters()
{
  std::cout << "Checking parameters : \n";
  std::cout.precision(7);
    if(modeF                        <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    mode                    	  \n"; return;} 
        	                  else {std::cout<<"mode                         : "<<mode              	      << "\n";} 
				   
    //if(original_run_data_starF      <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    original_run_data_star	  \n"; return;} 
    //    	                  else {std::cout<<"original_run_data_star       : "<<original_run_data_star	      << "\n";}
				  
    if(inp_run_data_starF           <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    inp_run_data_star	  \n"; return;} 
        	                  else {std::cout<<"inp_run_data_star            : "<<inp_run_data_star	      << "\n";}
			     
    if(out_run_data_star_allF       <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    out_run_data_star_all\n"; return;} 
        	                  else {std::cout<<"out_run_data_star_all        : "<<out_run_data_star_all << "\n";}	
    if(out_run_data_star_selF       <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    out_run_data_star_sel\n"; return;} 
        	                  else {std::cout<<"out_run_data_star_sel        : "<<out_run_data_star_sel << "\n";}
				      
				      				  				  
    //if(updated_run_data_star_est_all_RLNF<1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    updated_run_data_star_est_all_RLN\n"; return;} 
    //    	                      else {std::cout<<"updated_run_data_star_est_all_RLN : "<<updated_run_data_star_est_all_RLN << "\n";}	
    //if(updated_run_data_star_est_all_CHKF<1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    updated_run_data_star_est_all_CHK\n"; return;} 
    //    	                      else {std::cout<<"updated_run_data_star_est_all_CHK : "<<updated_run_data_star_est_all_CHK << "\n";}
				      
				      				    
    //if(updated_run_data_star_cal_sel_RLNF<1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    updated_run_data_star_cal_sel_RLN\n"; return;} 
    //    	                      else {std::cout<<"updated_run_data_star_cal_sel_RLN : "<<updated_run_data_star_cal_sel_RLN << "\n";}	
    //if(updated_run_data_star_cal_sel_CHKF<1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    updated_run_data_star_cal_sel_CHK\n"; return;} 
    //    	                      else {std::cout<<"updated_run_data_star_cal_sel_CHK : "<<updated_run_data_star_cal_sel_CHK << "\n";}				  			  
				  
    //if(updated_run_data_star_RELIONF<1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    updated_run_data_star_RELION\n"; return;} 
    //    	                  else {std::cout<<"updated_run_data_star_RELION : "<<updated_run_data_star_RELION    << "\n";}
    //if(updated_run_data_star_CHECKF <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    updated_run_data_star_CHECK \n"; return;} 
    //    	                  else {std::cout<<"updated_run_data_star_CHECK  : "<<updated_run_data_star_CHECK     << "\n";}

    if(rlnCoordinateXLabelF         <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnCoordinateXLabel	  \n"; return;} 
        	                  else {std::cout<<"rlnCoordinateXLabel          : "<<rlnCoordinateXLabel             << "\n";}
    if(rlnCoordinateYLabelF         <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnCoordinateYLabel	  \n"; return;} 
        	                  else {std::cout<<"rlnCoordinateYLabel          : "<<rlnCoordinateYLabel             << "\n";}
    if(rlnOriginXLabelF             <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnOriginXLabel	          \n"; return;} 
        	                  else {std::cout<<"rlnOriginXLabel              : "<<rlnOriginXLabel	              << "\n";}
    if(rlnOriginYLabelF             <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnOriginYLabel	          \n"; return;} 
        	                  else {std::cout<<"rlnOriginYLabel              : "<<rlnOriginYLabel	              << "\n";} 
    if(rlnAngleRotLabelF            <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnAngleRotLabel            \n"; return;} 
        	                  else {std::cout<<"rlnAngleRotLabel             : "<<rlnAngleRotLabel                << "\n";} 
    if(rlnAngleTiltLabelF           <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnAngleTiltLabel           \n"; return;} 
        	                  else {std::cout<<"rlnAngleTiltLabel            : "<<rlnAngleTiltLabel 	      << "\n";} 
    if(rlnAnglePsiLabelF            <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnAnglePsiLabel  	  \n"; return;} 
        	                  else {std::cout<<"rlnAnglePsiLabel             : "<<rlnAnglePsiLabel  	      << "\n";} 
    if(rlnDefocusULabelF            <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnDefocusULabel  	  \n"; return;} 
        	                  else {std::cout<<"rlnDefocusULabel             : "<<rlnDefocusULabel  	      << "\n";} 
    if(rlnDefocusVLabelF            <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnDefocusVLabel            \n"; return;} 
        	                  else {std::cout<<"rlnDefocusVLabel             : "<<rlnDefocusVLabel  	      << "\n";} 
    if(rlnDefocusAngleLabelF        <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnDefocusAngleLabel        \n"; return;} 
        	                  else {std::cout<<"rlnDefocusAngleLabel         : "<<rlnDefocusAngleLabel	      << "\n";} 
    if(rlnHelicalTrackLengthLabelF  <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnHelicalTrackLengthLabel  \n"; return;} 
        	                  else {std::cout<<"rlnHelicalTrackLengthLabel   : "<<rlnHelicalTrackLengthLabel      << "\n";} 

    if(rlnRiseLabelF                <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnRiseLabel                \n"; return;} 
        	                  else {std::cout<<"rlnRiseLabel                 : "<<rlnRiseLabel	              << "\n";} 
    if(rlnTwistLabelF               <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnTwistLabel               \n"; return;} 
        	                  else {std::cout<<"rlnTwistLabel                : "<<rlnTwistLabel	              << "\n";} 
    if(rlnDThetaLabelF              <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnDThetaLabel	          \n"; return;} 
        	                  else {std::cout<<"rlnDThetaLabel               : "<<rlnDThetaLabel	              << "\n";} 
    if(rlnDPsiLabelF                <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnDPsiLabel                \n"; return;} 
        	                  else {std::cout<<"rlnDPsiLabel                 : "<<rlnDPsiLabel	              << "\n";} 
    if(rlnDiscontinuityLabelF       <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    rlnDiscontinuityLabel       \n"; return;} 
        	                  else {std::cout<<"rlnDiscontinuityLabel        : "<<rlnDiscontinuityLabel	      << "\n";} 

    if(helix_rise_meanF             <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_rise_mean	          \n"; return;} 
        	                  else {std::cout<<"helix_rise_mean              : "<<helix_rise_mean	              << "\n";} 
    if(helix_rise_sdF               <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_rise_sd               \n"; return;} 
        	                  else {std::cout<<"helix_rise_sd                : "<<helix_rise_sd	              << "\n";} 
    if(helix_rise_range_in_sdF      <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_rise_range_in_sd      \n"; return;} 
        	                  else {std::cout<<"helix_rise_range_in_sd       : "<<helix_rise_range_in_sd	      << "\n";} 				
    if(helix_rise_rangeF            <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_rise_range	  \n"; return;} 
        	                  else {std::cout<<"helix_rise_range             : "<<helix_rise_range	      << "\n";} 
    if(helix_twist_meanF            <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_twist_mean            \n"; return;} 
        	                  else {std::cout<<"helix_twist_mean             : "<<helix_twist_mean  	      << "\n";} 
    if(helix_twist_sdF              <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_twist_sd              \n"; return;} 
        	                  else {std::cout<<"helix_twist_sd               : "<<helix_twist_sd	              << "\n";} 
    if(helix_twist_range_in_sdF     <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_twist_range_in_sd     \n"; return;} 
        	                  else {std::cout<<"helix_twist_range_in_sd      : "<<helix_twist_range_in_sd	      << "\n";} 				
    if(helix_twist_rangeF           <1){std::cout<<"UNDEFINED/INCORRECT PARAMETER:    helix_twist_range     \n"; return;} 
        	                  else {std::cout<<"helix_twist_range            : "<<helix_twist_range	      << "\n";}		

} // void Parameters::checkParameters(std::string mode)

////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
