// TEMPLATE CLASS:         TC_StarToBox.cpp
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_StarToBox.h and TC_StarToBox.cpp in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TC_StarToBox.h"

** After defining 'inputFileName' and 'inputFileName', add ---
   StarToBox s2b;
   s2b.star2box(inputFileName, outputFileName, binFactor, tubeWidth);  
*/

#include "TC_FileOpenAndFormatExceptions.h"

#include "TC_StarToBox.h"


// ofstream: Stream class to write on files
// ifstream: Stream class to read from files
// fstream: Stream class to both read and write from/to files.

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <vector>
// vector class; including std::vector; It's one kind of containers.

#include <string>
// String class; string object where the extracted line is stored.

#include <boost/algorithm/string.hpp>
//Split algorithms are an extension to the find iterator for one common usage scenario. 
//These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 


StarToBox::StarToBox() 
{
  int x = 1;
  // The constructor can NOT be empty
}

StarToBox::~StarToBox() 
{
  // The destructor can be empty.
}


void StarToBox::star2box(std::string inputFileName, std::string outputFileName, int binFactor, int tubeWidth) 
{

    // progress
    //std::cout << "working on: " << inputFileName << "\n";  
    //std::cout << "\rworking on: " << inputFileName ;
    
     
    //// read
    std::ifstream inputFile (inputFileName.c_str(), std::ifstream::in);
    std::string lineInInputFile;
    if ( inputFile.is_open() )
    {
      int tubeIdPrev = 0;
      int tubeIdCurr = 0;
      
      int tubeIdCol = 0;
      int coordXCol = 0;
      int coordYCol = 0;
      
      float coordXStart;
      float coordYStart;
      float coordXStartNext;
      float coordYStartNext;      
      float coordXEnd;
      float coordYEnd;
            
      int numOfPtclsInCurrTube;
      
      std::ofstream outputFile(outputFileName, std::ofstream::out); // clean and write
      //std::ofstream outputFile(outputFileName, std::ofstream::out | std::ofstream::app);// append  
      //D/std::cout << "$$$$$$" << "\n"; 	      
      while ( std::getline(inputFile, lineInInputFile) )
      {
        
        //D/outputFile << "Writing this to a file.\n";
	
	
	//// split lines      
        std::vector<std::string> vectorContainingTheSplitLine;
        boost::split(vectorContainingTheSplitLine, lineInInputFile, boost::is_any_of("\t "),boost::token_compress_on );
        //std::cout << "vectorSplit for current line: " << vectorSplit << "\n";
        //std::cout << "* size of the vector: " << vectorContainingTheSplitLine.size() << "\n"; 
        // std::size_t usually works better than int when indexing C++ containers, such as std::vectors, std::string.
        //for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++)
            //std::cout << vectorContainingTheSplitLine[i] << "\n";
	
	
	//// get column IDs    
        if ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnHelicalTubeID" ) {
            tubeIdCol = std::stod(vectorContainingTheSplitLine[1].substr(1)); 
            //std::cout << "tubeIdCol: " << tubeIdCol << "\n";
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnCoordinateX" ) {
            coordXCol = std::stod(vectorContainingTheSplitLine[1].substr(1)); 
            //std::cout << "coordXCol: " << coordXCol << "\n";
        } else if  ( vectorContainingTheSplitLine.size() == 3 && vectorContainingTheSplitLine[0] == "_rlnCoordinateY" ) {
            coordYCol = std::stod(vectorContainingTheSplitLine[1].substr(1)); 
            //std::cout << "coordYCol: " << coordYCol << "\n";
        }
        
	
	//// work on data lines
        //D/std::cout << "######" << "\n"; 
	if (vectorContainingTheSplitLine.size() > 3) {	
	  tubeIdCurr = std::stod(vectorContainingTheSplitLine[tubeIdCol]);
	   //D/std::cout << "###### tubeIdCurr " << tubeIdCurr << "\n";	  
	}
	//D/std::cout << "######" << "\n"; 
        if ( (vectorContainingTheSplitLine.size() > 3) && (tubeIdCurr != tubeIdPrev) && (tubeIdPrev == 0) ) {
           coordXStart = std::stod(vectorContainingTheSplitLine[coordXCol]);
	   coordYStart = std::stod(vectorContainingTheSplitLine[coordYCol]);
	   //D/std::cout << "###### FirstDataLineInInputFile " << lineInInputFile << "\n";
        } else if ( vectorContainingTheSplitLine.size() > 3 && tubeIdCurr == tubeIdPrev) {
           coordXEnd = std::stod(vectorContainingTheSplitLine[coordXCol]);
	   coordYEnd = std::stod(vectorContainingTheSplitLine[coordYCol]);
	   //std::cout << "###### coordXStart " << lineInInputFile << "\n";
	   numOfPtclsInCurrTube = numOfPtclsInCurrTube + 1;  
        } else if ( vectorContainingTheSplitLine.size() > 3 && tubeIdCurr != tubeIdPrev && tubeIdPrev != 0) {
           coordXStartNext = std::stod(vectorContainingTheSplitLine[coordXCol]);
	   coordYStartNext = std::stod(vectorContainingTheSplitLine[coordYCol]);
	   //D/std::cout << "###### FirstDataLineInCurrTube " << lineInInputFile << "\n";
	   if ( numOfPtclsInCurrTube >= 6 ) { // the tube should have at least 6 particles.
	     //D/std::cout << coordXStart << "\n";
	     char lineInBoxStart[100];
	     sprintf(lineInBoxStart, "%d\t%d\t%d\t%d\t%s\n", (int)coordXStart/binFactor-tubeWidth/2, (int)coordYStart/binFactor-tubeWidth/2, tubeWidth, tubeWidth, "-1");
	     outputFile << lineInBoxStart;
	     //D/std::cout  << lineInBoxStart;
	     char lineInBoxEnd[100];	     
	     sprintf(lineInBoxEnd,   "%d\t%d\t%d\t%d\t%s\n", (int)coordXEnd/binFactor-tubeWidth/2,   (int)coordYEnd/binFactor-tubeWidth/2,   tubeWidth, tubeWidth, "-2");	   
	     outputFile << lineInBoxEnd;
	   } // if ( numOfPtclsInCurrTube >= 6 ) 
           //tubeIdPrev  = tubeIdCurr;
           coordXStart = coordXStartNext;
	   coordYStart = coordYStartNext;	   
	   numOfPtclsInCurrTube = 0;
        }  
       
        tubeIdPrev  = tubeIdCurr;
	
	
      } // while ( std::getline(inputFile, lineInInputFile) )
      
      
           //// last tube in a .star file
      	   if ( numOfPtclsInCurrTube >= 6 ) { // the tube should have at least 6 particles.
	     //D/std::cout << coordXStart << "\n";
	     char lineInBoxStart[100];
	     sprintf(lineInBoxStart, "%d\t%d\t%d\t%d\t%s\n", (int)coordXStart/binFactor-tubeWidth, (int)coordYStart/binFactor-tubeWidth, tubeWidth, tubeWidth, "-1");
	     outputFile << lineInBoxStart;
	     //D/std::cout  << lineInBoxStart;
	     char lineInBoxEnd[100];	     
	     sprintf(lineInBoxEnd,   "%d\t%d\t%d\t%d\t%s\n", (int)coordXEnd/binFactor-tubeWidth,   (int)coordYEnd/binFactor-tubeWidth,   tubeWidth, tubeWidth, "-2");	   
	     outputFile << lineInBoxEnd;
	   } // if ( numOfPtclsInCurrTube >= 6 )
	   numOfPtclsInCurrTube = 0;
      outputFile.close();
      inputFile.close();
    } else {
      //std::cout << "Cannot open input file: " << inputFileName << "\n";
      std::stringstream inputFileName_srcFileNameAndLineNumSS;
      inputFileName_srcFileNameAndLineNumSS << "[file:" << inputFileName << "; src: " << __FILE__ << ", line: " << __LINE__ << "]";
      std::string inputFileName_srcFileNameAndLineNumS = inputFileName_srcFileNameAndLineNumSS.str();
      //throw FileOpenException(inputFileName_srcFileNameAndLineNumS);
      //throw FileFormatException(inputFileName_srcFileNameAndLineNumS);
    } // if ( inputFile.is_open() )
    
    //return 0;
    


    

}; // class StarToBox {

 

