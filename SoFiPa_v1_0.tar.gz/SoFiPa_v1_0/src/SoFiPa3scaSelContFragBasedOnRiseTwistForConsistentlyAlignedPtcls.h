// TEMPLATE CLASS:         TC_StarToCsv.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_StarToCsv.h and TC_StarToCsv.cpp in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TC_StarToCsv.h"

** After defining 'inputFileName' and 'outputFileName', add ---
   StarToCsv s2c;
   s2c.star2csv(inputFileName, outputFileName);  
*/

#include "TC_Parameters_SoFiPa.h"

#pragma once 
// It serves the same purpose as include guards.
// It tells the preprocesser to include the current source file only once in a single compilation. 

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <string>
// String class; string object where the extracted line is stored.

#include <vector>
// vector class; including std::vector; It's a kind of containers.


#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 



class SmoothFilamentsInRunDataStar3sca {

public:
    SmoothFilamentsInRunDataStar3sca(Parameters& parO);
    ~SmoothFilamentsInRunDataStar3sca();
    void smoothFilamentsInRunDataStar3sca();

    Parameters iParO;

        
private:

    
    double AlignRelFirst;
    
    double prevDirection;
    double currDirection;
    double nextDirection; 
	
    double currAlignRelPrev;
    
    double currAlignRelFirst;
    double prevAlignRelFirst;  
      	       
    int numOfcurrAlignRelFirstZ0;
    int numOfcurrAlignRelFirstM1;
    int numOfcurrAlignRelFirstP1;
    int numOfcurrAlignRelFirstM2;
    int numOfcurrAlignRelFirstP2; 
    double discon; //discontinuity
    
    int nonChgLengthZ0;
    int nonChgLengthM1;
    int nonChgLengthP1;
    int filAlignRelFirst; // -1; 0; 1 
        
    double currDirRelPrev;    
    int numOfCurrDirP1;
    int numOfCurrDirM1;
    int numOfCurrDirZ0;    
    int numOfCurrDirXX;    
    int filDir; // -1; 0; 1
    
    ////    
    int imgNameCol;
    int micNameCol;
    int tubeIdCol;
    int detPixSizeCol;  
      
    ////   
    int coordXCol;
    int coordYCol;

    int oriXCol;
    int oriYCol;

    int angRotCol;
    int angTiltCol;
    int angPsiCol;

    int defUCol;
    int defVCol;
    int defACol;

    int helTLCol;
    
    
    //// These parameters will be fitted separately
    double defU;
    double defV;   
    double defA;      
    double angTilt;
    double angPsi;
    
    double smoothData1D5E2A(double arrayData1D5E[], int position); 
           // 1D array with 5 elements // DefU, DefV, DefA; angTilt, angPsi
    
    
    //// These parameters will be fitted together
    double coordX;
    double coordY;   
    double oriX;      
    double oriY;
    double angRot;
           double angRotTemp;
	   
    double coOrX; // = coordX - oriX
    double coOrY; // = coordY - oriY	   
	   
    // EST: estimated (alignment + prior knowledge); CALC: calculated (alignment only)
    
    
    
    //// ESTIMATE RISE & TWIST (CHECK ALIGNMENT, DIRECTION, DISCONTINUITY)        
    double arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6]; // [0]: alignRelPrev; [1]: directionRelPrev; //[2]: rise; [3]: twist; //[4]: alignRelFirst; [5]: discontinuity  
                                                          // [9] & [10]: the same as in the last two columns in table...[]
                                                 
						 
						 
														
    double getAlignDirRiseTwist(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], double arrayAngRot1D5E[], std::vector<std::string> vectorImgName1D5E, int position);

 
 
 
 
 
    //// ESTIMATE COORD (2), ANG (Rot)
    double arrayEST_CoOrX_CoOrY_AngRot[3]; //[0]: coordX; [1]: coordY; [2]: oriX; [3]: oriY; [4]: angRot; 
  
    
    double estimateCoordxyAngrot(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], double arrayAngRot1D5E[], std::vector<std::string> vectorImgName1D5E, int position, int filAlignRelFirst, int filDir, double arrayAlignRelFirst1D5E[], double arrayDiscon1D5E[]);  

           double arrayCoordEst[2];    
           double estimateAlignedXY(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], int position, double subunitRise, double NoOfSubunits);


/*
    //// CALCULATE RISE & TWIST
    
    //// CALCULATE COORD (2), ANG (All 3), DEF (All 3)
    double calculateCoordxyAngrot(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], double arrayAngRot1D5E[], std::vector<std::string> vectorImgName1D5E, int position, int filAlignRelFirst, int filDir, double arrayAlignRelFirst1D5E[], double arrayDiscon1D5E[]);  
*/
/*

	      EAClineInOutputSS << "  " << currAlignRelPrev;   // extra column 1 in output .star file
	      EAClineInOutputSS << "  " << currAlignRelFirst;  // extra column 2 in output .star file
	      EAClineInOutputSS << "  " << discon;   	     // extra column 3 in output .star file
	      EAClineInOutputSS << "  " << currDirRelPrev;     // extra column 4 in output .star file
	      EAClineInOutputSS << "  " << arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2]; // estimated rise; extra column 5 in output .star file
	      EAClineInOutputSS << "  " << arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3]; // estimated twist; extra column 6 in output .star file
	      
	      EAClineInOutputSS << "  " << sprintfCoOrX;   // extra column 1 in output .star file
	      EAClineInOutputSS << "  " << sprintfCoOrY;  // extra column 2 in output .star file
	      EAClineInOutputSS << "  " << sprintfOriX;   	     // extra column 3 in output .star file
	      EAClineInOutputSS << "  " << sprintfOriY;     // extra column 4 in output .star file
	      EAClineInOutputSS << "  " << sprintfAngRot; // estimated rise; extra column 5 in output .star file

*/

};  



