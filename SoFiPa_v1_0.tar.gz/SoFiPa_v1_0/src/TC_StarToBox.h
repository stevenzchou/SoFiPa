// TEMPLATE CLASS:         TC_StarToBox.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_StarToBox.h and TC_StarToBox.cpp in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TC_StarToBox.h"

** After defining 'inputFileName' and 'inputFileName', add ---
   StarToBox s2b;
   s2b.star2box(inputFileName, outputFileName, binFactor, tubeWidth);  
*/


#pragma once 
// It serves the same purpose as include guards.
// It tells the preprocesser to include the current source file only once in a single compilation. 

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <string>
// String class; string object where the extracted line is stored.


#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 



class StarToBox {

public:
    StarToBox();
    ~StarToBox();
    void star2box(std::string inputFileName, std::string outputFileName, int binFactor, int tubeWidth);
    
}; // class StarToBox {



