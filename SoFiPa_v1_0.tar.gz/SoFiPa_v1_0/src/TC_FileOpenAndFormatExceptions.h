// TEMPLATE CLASS:         TC_FileOpenAndFormatExceptions.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_FileOpenAndFormatExceptions.h in the directory where your main.cpp resides.
  
** In your *.cpp

** At the beginning of the file, add ---
   #include "TC_FileOpenAndFormatExceptions.h"

** Whenever necessary, add ---
   std::stringstream inputFileName_srcFileNameAndLineNumSS;
   inputFileName_srcFileNameAndLineNumSS << "[file:" << inputFileName << "; src: " << __FILE__ << ", line: " << __LINE__ << "]";
   std::string inputFileName_srcFileNameAndLineNumS = inputFileName_srcFileNameAndLineNumSS.str();
   throw FileOpenException(inputFileName_srcFileNameAndLineNumS);
   //throw FileFormatException(inputFileName_srcFileNameAndLineNumS);

*/

#include <iostream>
#include <exception>
#include <string>
#include <sstream>
#include <cstdlib>


class FileOpenException : public std::exception
{
public:
	std::string FoeMessageS;
	FileOpenException(std::string inputFileName_srcFileNameAndLineNum)
	{
		FoeMessageS = "The file could not be opened! " + inputFileName_srcFileNameAndLineNum + "\n";
	}

	~FileOpenException() throw() {}

	const char * what() const throw ()
	{
		return FoeMessageS.c_str();
	}

};


class FileFormatException : public std::exception
{
public:
	std::string FfemessageS;
	FileFormatException(std::string inputFileName_srcFileNameAndLineNum)
	{
		std::stringstream FfemessageSS;
		FfemessageSS << "The file format is not supported! " << inputFileName_srcFileNameAndLineNum << "\n";	
		FfemessageS = FfemessageSS.str();
	}

	~FileFormatException() throw() {}

	const char * what() const throw ()
	{
		return FfemessageS.c_str();
	}

};

