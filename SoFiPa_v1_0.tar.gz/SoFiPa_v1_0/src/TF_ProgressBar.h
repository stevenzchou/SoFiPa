// TEMPLATE FUNCTION:      TF_ProgressBar.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE FUNCTION?    

** Put TF_ProgressBar.h and TF_ProgressBar.cpp in the directory where your main.cpp resides.
   
** In your main.cpp

** At the beginning of the file, add ---
   #include "TF_ProgressBar.h"

** Before the loop, add ---
   // progess bar
   int file_num = 0;
   double progress_percentage;
  
** At the end of the loop, add ---
    // progess bar
    file_num = file_num + 1;
    progress_percentage = (double) file_num / (endNum - startNum + 1);
    printProgress(progress_percentage); 
*/


#pragma once 
// It serves the same purpose as include guards.
// It tells the preprocesser to include the current source file only once in a single compilation. 

#include <iostream>
//Input and output stream; std::cout;

#include <string>
// String class; string object where the extracted line is stored.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 



void printProgress(double progressPercentage);









