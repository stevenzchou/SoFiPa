#pragma once

#include <vector>
#include <string>


class Parameters
{

public:
    // unparameterized constructor
    Parameters();
    // parameterized constructor (special function)
    Parameters(std::vector<std::string> argList);
    // destructor
    ~Parameters();
    
    // the following parameters are read from the command line or a parameter file. 
    std::string mode;     
    
    //std::string original_run_data_star; 		    
    std::string inp_run_data_star;
        
    //std::string updated_run_data_star_est_all_RLN;	
    //std::string updated_run_data_star_est_all_CHK;   
    //std::string updated_run_data_star_cal_sel_RLN;	
    //std::string updated_run_data_star_cal_sel_CHK; 
      
    std::string out_run_data_star_all;
    std::string out_run_data_star_sel; 
     
    //std::string updated_run_data_star_RELION;	
    //std::string updated_run_data_star_CHECK;	    
    
    std::string rlnCoordinateXLabel;	
    std::string rlnCoordinateYLabel;	
	              
    std::string rlnOriginXLabel;	      
    std::string rlnOriginYLabel;	      
	              
    std::string rlnAngleRotLabel;	      
    std::string rlnAngleTiltLabel;	
    std::string rlnAnglePsiLabel;	      
	              
    std::string rlnDefocusULabel;	      
    std::string rlnDefocusVLabel;	      
    std::string rlnDefocusAngleLabel;	
	              
    std::string rlnHelicalTrackLengthLabel; 
    
    std::string rlnRiseLabel;    
    std::string rlnTwistLabel;      
    std::string rlnDThetaLabel;     
    std::string rlnDPsiLabel;	   
    std::string rlnDiscontinuityLabel; 
    
    double helix_rise_mean;    
    double helix_rise_sd;
    double helix_rise_range_in_sd;   
    double helix_rise_range;
	
    double helix_twist_mean;   
    double helix_twist_sd;  
    double helix_twist_range_in_sd; // for selecting ptcls
    double helix_twist_range;   // for estimating alignments and directions
    
    
    void checkParameters();        
    
private:

    void readParameters(std::vector<std::string> argList);
    
    void parseParameterFile(const std::string tiltcom);
    void parseCommandLine(std::vector<std::string> argList);
    void storeParameterNamesAndValues(std::string parName, std::string parValue);    
    
    
    // the following parameters are read from the command line or a parameter file.
    int modeF;   
    //int original_run_data_starF;
    int inp_run_data_starF;    
    
    //int updated_run_data_star_est_all_RLNF;  
    //int updated_run_data_star_est_all_CHKF;			 
    //int updated_run_data_star_cal_sel_RLNF;  
    //int updated_run_data_star_cal_sel_CHKF;
    
    int out_run_data_star_allF;  
    int out_run_data_star_selF;    
       
    //int updated_run_data_star_RELIONF;  
    //int updated_run_data_star_CHECKF;	    

    int rlnCoordinateXLabelF;	 
    int rlnCoordinateYLabelF;	 
		      
    int rlnOriginXLabelF;	      
    int rlnOriginYLabelF;	      
		      
    int rlnAngleRotLabelF;	      
    int rlnAngleTiltLabelF;	 
    int rlnAnglePsiLabelF;	      
		      
    int rlnDefocusULabelF;	      
    int rlnDefocusVLabelF;	      
    int rlnDefocusAngleLabelF;   
		      
    int rlnHelicalTrackLengthLabelF; 
    
    int rlnRiseLabelF;        
    int rlnTwistLabelF;      
    int rlnDThetaLabelF;     
    int rlnDPsiLabelF;      
    int rlnDiscontinuityLabelF; 
    
    int helix_rise_meanF;      
    int helix_rise_sdF;      
    int helix_rise_range_in_sdF;     
    int helix_rise_rangeF;
	
    int helix_twist_meanF;     
    int helix_twist_sdF;       
    int helix_twist_range_in_sdF;       
    int helix_twist_rangeF;   
    
 
};
