// COMPILATION:            g++ -std=c++11 Pctf.cpp -o Pctf
// USAGE:                  ./Pctf
// EXAMPLE:                ./Pctf . dp6_ 4 101 1960 _autopick.star 2 82
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>
#include "SoFiPa0srpSmoothCtfUvaAngPsiTilt.h"
#include "SoFiPa0sepSmoothCtfUvaAngPsiTilt.h"
#include "SoFiPa1scfSelContFragBasedOnRiseTwist.h"
#include "SoFiPa2ecaEstCoOrAngRot.h"
#include "SoFiPa3scaSelContFragBasedOnRiseTwistForConsistentlyAlignedPtcls.h"
#include "SoFiPaXcrtCalcRiseTwistForConsistentlyAlignedPtcls.h"

#include "TC_Parameters_SoFiPa.h"
//#include "TF_ElapsedTime.h"
//#include "TC_StarToBox.h"
//#include "TF_ProgressBar.h"

//#include "TC_FileOpenAndFormatExceptions.h"
//#include "PctfSimulator.h"
//#include "PctfEstimator.h"

#include <iostream>
// Input and output stream; std::cout;

#include <string>
// String class; string object where the extracted line is stored.

#include <boost/algorithm/string.hpp>
// Split algorithms are an extension to the find iterator for one common usage scenario. 
// These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 

#include <cstdlib>
// C Standard General Utilities Library; exit; fprintf

#include <iomanip>
// Input and output manipulation; including std::put_time (not in g++ --version 4.9 !!!), setfill, setw


int main(int argc, char *argv[]){

  std::cout << "*****************************************************************************************\n";


////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
//////// PRINTING USAGES
  if (argc < 2) {
    std::cout << 
    "USAGE:  \n"
    "      "<< argv[0] <<"   -parFile  sofipa_ProteinName_mode.par > temp_ProteinName_mode.log                            \n"
    "                                                                                       				  \n"	 
    "#### PARAMETER FILE                                                                                                  \n"
    "The parameter file is a plain .txt file containing one parameter per line.                                           \n"
    "Each line has a format of '_parName  parValue  # annotation of the parameter'                                        \n"
    "                                                                                       				  \n"	 
    "# EVERYTHING AFTER '#' IN THIS PAR FILE WILL BE IGNORED.                                                                              \n"
    "# EVERY PARAMETER LINE IN THIS PAR FILE MUST START WITH '_' AT THE BEGINNING.                                                         \n"
    "# ALL THE PARAMETERS NEED TO BE PROVIDED; BUT NOT ALL OF THEM ARE USED IN A MODE.                                                     \n"
    "                                                                                                                                      \n"
    "_mode                        3sca                                          # 0sep; 0srp; 1scf; 2eca; 3sca; Xcrt                       \n"
    "                                                                                                                                      \n"
    "# input files                                                                                                                         \n"
    "_inp_run_data_star           ADPPiPA5_plCTF_j011_run_data.star             # string; from RELION Extract or Refine3D                  \n"
    "                                                                                                                                      \n"
    "# output files                                                                                                                        \n"
    "_out_run_data_star_all       ADPPiPA5_plCTF_j011_run_data_3sca3sd_all.star # string; contains all the particles                       \n"
    "_out_run_data_star_sel       ADPPiPA5_plCTF_j011_run_data_3sca3sd_sel.star # string; only contains selected particles                 \n"
    "                                                                                                                                      \n"
    "# RELION labels for particle re-extraction (to update the value, set it to 'y'; to keep it the same, set it to 'n')                   \n"
    "_rlnCoordinateXLabel         y # _rlnCoordinateX     # X-Position (in pixels) of an particle image in a micrograph 		   \n"
    "_rlnCoordinateYLabel         y # _rlnCoordinateY     # Y-Position (in pixels) of an particle image in a micrograph 		   \n"
    "                                                     										   \n"
    "_rlnOriginXLabel             y # _rlnOriginX         # shift along X	    # X-coord (in pixels) for the origin of rotation	   \n"
    "_rlnOriginYLabel             y # _rlnOriginY         # shift along Y	    # Y-coord (in pixels) for the origin of rotation	   \n"
    "							     										   \n"
    "_rlnAngleRotLabel            y # _rlnAngleRot        # along-filament rotation # First Euler angle  (in degrees, phi)		   \n"
    "_rlnAngleTiltLabel           y # _rlnAngleTilt       # out-of-plane rotation   # Second Euler angle (in degrees, theta)		   \n"
    "_rlnAnglePsiLabel            y # _rlnAnglePsi        # in-plane rotation       # Third Euler angle  (in degrees, psi)		   \n"
    "							     										   \n"
    "_rlnDefocusULabel            y # _rlnDefocusU        # defocus in U-direction (in Angstroms, positive values for underfocus)	   \n"
    "_rlnDefocusVLabel            y # _rlnDefocusV        # defocus in V-direction (in Angstroms, positive values for underfocus)	   \n"
    "_rlnDefocusAngleLabel        y # _rlnDefocusAngle    # angle between X and defocus U direction (in degrees)			   \n"
    "																	   \n"
    "_rlnHelicalTrackLengthLabel  y # _rlnHelicalTrackLength # distance from the position of this particle to the start of the tube	   \n"
    "																	   \n"
    "# extra labels for checking with NEDIT or plotting with R (to update the value, set it to 'y'; to keep it the same, set it to 'n')    \n"
    "_rlnRiseLabel                y # _rlnRise            # rise between two segments							   \n"
    "_rlnTwistLabel               y # _rlnTwist           # twist between two segments							   \n"
    "_rlnDThetaLabel              y # _rlnDTheta          # theta deviation								   \n"
    "_rlnDPsiLabel                y # _rlnDPsi            # psi deviation 								   \n"
    "_rlnDiscontinuityLabel       y # _rlnDiscontinuity   # segment rise/twist beyond 2 SD # when you have rise/twist SD already           \n"
    "		  															   \n"
    "# relationship between standard deviation and confidence level: 1*sd: 68%; 2*sd: 95%; 3*sd: 99%                                       \n"
    "# helix rise of the dataset         # [ADPPi (dp6) rise: 27.37726;  ADPPi (dp6) rise SD: 0.3890504]                                   \n"
    "_helix_rise_mean         26.198     # double float; mean from R (or RELION run_model.star); in unit of pixels: 27.377/1.045=26.198    \n"
    "_helix_rise_sd            0.3890504 # double float; standard deviation from R (for selecting segments in mode 3sca)                   \n"
    "_helix_rise_range_in_sd   3.00      # double float; rise range in unit of sd for selecting ptcls (mode 3sca only)                     \n"
    "_helix_rise_range         5.00      # double float; rise range for estimating alignments and directions (mode 1scf only)              \n"
    "															  		   \n"
    "# helix twist of the dataset        # [ADPPi (dp6) twist: -166.6371;  ADPPi (dp6) twist SD: 0.6186463]		  		   \n"
    "_helix_twist_mean      -166.57000   # double float; mean from R (or RELION run_model.star); in unit of degrees			   \n"
    "_helix_twist_sd           0.6186463 # double float; standard deviation from R (for selecting segments in mode 3sca)                   \n"
    "_helix_twist_range_in_sd  3.00      # double float; twist range in unit of sd for selecting ptcls (mode 3sca only)                    \n"
    "_helix_twist_range        5.00      # double float; twist range for estimating alignments and directions (mode 1scf only)             \n"
    "		  															   \n"
    "#### TERMINOLOGY													     \n"
    "filament particle: a square filament segment									     \n"
    "extracted particles: particles extracted using Relion Extract (Extract/jobxxx/particles.star)      		     \n"
    "refined particles: particles after running Relion Refine3D (Refine3D/jobxxx/run_data.star) 			     \n"
    "continuous fragment: a non-breaking fragment in a long filament; it contains five or more properly aligned particles    \n"
    "consistently aligned particle: a particle properply aligned to the expected position (relative to the previous particle)\n"
    "inconsistently aligned particle: a particle properly aligned to the previous or next position		     	     \n"
    "															     \n"
    "#### MODES 													     \n"
    "0sep (old 0b): smooth defocusU, defocusV, defocusA, angleTilt, anglePsi for extracted particles			     \n"
    "	   IN:  Extract/jobxxx/particles.star (after particle local CTF estimation)					     \n"
    "	   OUT: ProteinName_plCTF_jobxxx_particles_sel_0sep.star (for running Relion Refine3D)				     \n"
    "0srp (old 0a): smooth defocusU, defocusV, defocusA, angleTilt, anglePsi for refined particles			     \n"
    "	   IN:  Refine3D/jobxxx/run_data.star (after running Relion Refine3D)						     \n"
    "	   OUT: ProteinName_plCTF_jobxxx_run_data_sel_0srp.star (for running Relion Refine3D)				     \n"
    "															     \n"
    "1scf (old 1a): select particles in continuous fragments (rise range: +/-5 pixels; twist range: +/-5 degrees)	     \n"
    "	   IN:  Refine3D/jobxxx/run_data.star (after running SoFiPa in 0sep mode and Relion Refine3D)			     \n"
    "	   OUT: ProteinName_plCTF_jobxxx_run_data_sel_1scf.star (for running SoFiPa in 2eca mode)			     \n"
    "2eca (old 1b): estimate consistent alignments (shiftXY, angleRot) for particles in continuous fragments		     \n"
    "	   IN:  ProteinName_plCTF_jobxxx_run_data_sel_1scf.star (after running SoFiPa in 1scf mode)  			     \n"
    "	   OUT: ProteinName_plCTF_jobxxx_run_data_sel_1scf.star (for running Relion Refine3D)				     \n"
    "															     \n"
    "3sca (old 2a): select consistently aligned particles in continuous fragments in defined rise and twist ranges (+/-2 sd) \n"
    "	   IN:  Refine3D/jobxxx/run_data.star (after running SoFiPa in 2eca mode and Relion Refine3D)			     \n"
    "	   OUT: ProteinName_plCTF_jobxxx_run_data_sel_3sca.star (for running relion_reconstruct and post-processing)	     \n"
    "															     \n"
    "Xcrt (old Xa): calculate the rise and twist for consistently aligned particles only				     \n"
    "	   IN:  Refine3D/jobxxx/run_data.star (after running SoFiPa in 2eca mode and Relion Refine3D usually before 3sca)    \n"
    "	   OUT: ProteinName_plCTF_jobxxx_run_data_all_xcrt.star (convert it to .csv w/ star2csv; for plotting with R) 	     \n"
    "															     \n"
    "															     \n";
  std::cout << "=========================================================================================\n";
  exit(EXIT_FAILURE);    
  } // if  
  
  //// start time 
  //auto rawTimeStartURDS = std::chrono::system_clock::now(); 
   
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
//////// READING PARAMETERS

  std::cout << ">>>> Reading parameters\n";  
  std::vector<std::string> argList;
  for(int i=1; i<argc; i++){argList.push_back(argv[i]);}
  Parameters parO(argList);
  std::cout << ">>>> Done reading parameters\n";  
  
  //// check parameters
  std::cout << ">>>> Checking parameters" << std::endl; 
  parO.checkParameters();
  std::cout << ">>>> Done checking parameters" << std::endl;
  std::cout << "-----------------------------------------------------------------------------------------\n";
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100
  /*
  std::cout << ">>>> Running " << argv[0] << "\n"; 
  // Dynamic memory allocation and deallocation with 'new' and 'delte' 
  // Dynamic memories remains there until either they are deallocated or program terminates.
  // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
  // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
  SmoothFilamentsInRunDataStar* newSmoothFilamentsInRunDataStarP = new SmoothFilamentsInRunDataStar(parO); 
  //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
  newSmoothFilamentsInRunDataStarP->smoothFilamentsInRunDataStar(); // = (*newPctfEstimatorP).run();	
  std::cout << ">>>> Done running " << argv[0] << "\n";     
  delete newSmoothFilamentsInRunDataStarP;  
  */
  if (parO.mode == "0srp"){
    std::cout << ">>>> Running " << argv[0] << "in mode: 0srp\n"; 
    // Dynamic memory allocation and deallocation with 'new' and 'delte' 
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    SmoothFilamentsInRunDataStar0srp* newSmoothFilamentsInRunDataStar0srpP = new SmoothFilamentsInRunDataStar0srp(parO); 
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    newSmoothFilamentsInRunDataStar0srpP->smoothFilamentsInRunDataStar0srp(); // = (*newPctfEstimatorP).run();	
    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete newSmoothFilamentsInRunDataStar0srpP;   
  } else if (parO.mode == "0sep"){
    std::cout << ">>>> Running " << argv[0] << "in mode: 0sep\n"; 
    // Dynamic memory allocation and deallocation with 'new' and 'delte' 
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    SmoothFilamentsInRunDataStar0sep* newSmoothFilamentsInRunDataStar0sepP = new SmoothFilamentsInRunDataStar0sep(parO); 
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    newSmoothFilamentsInRunDataStar0sepP->smoothFilamentsInRunDataStar0sep(); // = (*newPctfEstimatorP).run();	
    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete newSmoothFilamentsInRunDataStar0sepP;   
  } else if (parO.mode == "1scf"){
    std::cout << ">>>> Running " << argv[0] << "in mode: 1scf\n"; 
    // Dynamic memory allocation and deallocation with 'new' and 'delte' 
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    SmoothFilamentsInRunDataStar1scf* newSmoothFilamentsInRunDataStar1scfP = new SmoothFilamentsInRunDataStar1scf(parO); 
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    newSmoothFilamentsInRunDataStar1scfP->smoothFilamentsInRunDataStar1scf(); // = (*newPctfEstimatorP).run();	
    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete newSmoothFilamentsInRunDataStar1scfP;   
  } else if (parO.mode == "2eca"){
    std::cout << ">>>> Running " << argv[0] << "in mode: 2eca\n"; 
    // Dynamic memory allocation and deallocation with 'new' and 'delte' 
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    SmoothFilamentsInRunDataStar2eca* newSmoothFilamentsInRunDataStar2ecaP = new SmoothFilamentsInRunDataStar2eca(parO); 
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    newSmoothFilamentsInRunDataStar2ecaP->smoothFilamentsInRunDataStar2eca(); // = (*newPctfEstimatorP).run();	
    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete newSmoothFilamentsInRunDataStar2ecaP;  
  } else if (parO.mode == "3sca"){
    std::cout << ">>>> Running " << argv[0] << "in mode: 3sca\n"; 
    // Dynamic memory allocation and deallocation with 'new' and 'delte' 
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    SmoothFilamentsInRunDataStar3sca* newSmoothFilamentsInRunDataStar3scaP = new SmoothFilamentsInRunDataStar3sca(parO); 
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    newSmoothFilamentsInRunDataStar3scaP->smoothFilamentsInRunDataStar3sca(); // = (*newPctfEstimatorP).run();	
    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete newSmoothFilamentsInRunDataStar3scaP;   
  } else if (parO.mode == "Xcrt"){
    std::cout << ">>>> Running " << argv[0] << "in mode: Xcrt\n"; 
    // Dynamic memory allocation and deallocation with 'new' and 'delte' 
    // Dynamic memories remains there until either they are deallocated or program terminates.
    // syntax for 'new': pointer-variable = new data-type; pointer-variable = new data-type[size];
    // syntax for 'delete': delete pointer-variable; delete[] pointer-variable;
      
    SmoothFilamentsInRunDataStarXcrt* newSmoothFilamentsInRunDataStarXcrtP = new SmoothFilamentsInRunDataStarXcrt(parO); 
    //newPctfEstimatorP->run(); // = (*newPctfEstimatorP).run();      
    newSmoothFilamentsInRunDataStarXcrtP->smoothFilamentsInRunDataStarXcrt(); // = (*newPctfEstimatorP).run();	
    std::cout << ">>>> Done running " << argv[0] << "\n";     
    delete newSmoothFilamentsInRunDataStarXcrtP;   
  }
  //// calculateElapsedTime
  //std::cout << calculateElapsedTime(rawTimeStartURDS) << "\n"; 
  std::cout << "=========================================================================================\n"; 
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100


} // main
