// TEMPLATE CLASS:         TC_UpdateRunDataStar.h
// REFERENCES:             n/a
// TESTED PLATFORM:        RHEL7.5 (g++ 4.8.5; boost 1.53.0)
// AUTHOR INFO:            Steven Chou <stevenzchou@gmail.com>


/*
** HOW TO USE THIS TEMPLATE CLASS?    

** Put TC_UpdateRunDataStar.h and TC_UpdateRunDataStar.cpp in the directory where your main.cpp resides.
  
** In your main.cpp

** At the beginning of the file, add ---
   #include "TC_UpdateRunDataStar.h"

** After defining 'inputFileName' and 'outputFileName', add ---
   UpdateRunDataStar s2c;
   s2c.star2csv(inputFileName, outputFileName);  
*/


#include "TC_Parameters_SoFiPa.h"

#include "SoFiPaXcrtCalcRiseTwistForConsistentlyAlignedPtcls.h"

// ofstream: Stream class to write on files
// ifstream: Stream class to read from files
// fstream: Stream class to both read and write from/to files.
#include <iomanip>
// IO Manipulators; e.g., std::setw(6)

#include <iostream>
//Input and output stream; std::cout;

#include <fstream>
// C++ Stream class for reading from and writing to files

#include <sstream>
//String stream; std::stringstream;

#include <vector>
// vector class; including std::vector; It's a kind of containers.

#include <string>
// String class; string object where the extracted line is stored.

//#include </Applications/boost/boost_1_55_0/boost/algorithm/string.hpp>

#include <boost/algorithm/string.hpp>
//Split algorithms are an extension to the find iterator for one common usage scenario. 
//These algorithms use a find iterator and store all matches into the provided container.
// including boost::split
// The boost functions are usually slow, but split is fast.

#include <cstdio>
// C Stream class for reading from and writing to terminals/files in C++; 
 

#include <cmath>
SmoothFilamentsInRunDataStarXcrt::SmoothFilamentsInRunDataStarXcrt(Parameters& parO) 
{
  iParO = parO;
  int x = 1;
  // The constructor can NOT be empty
}

SmoothFilamentsInRunDataStarXcrt::~SmoothFilamentsInRunDataStarXcrt() 
{
  // The destructor can be empty.
}


double SmoothFilamentsInRunDataStarXcrt::smoothData1D5E2A(double arrayData1D5E[], int position) 
{
  // NOTE: positions in arrayData1D5E[] are: 0-4
  double min = arrayData1D5E[0];
  double max = arrayData1D5E[4];
  int minIndex5E = 0;
  int maxIndex5E = 4;
  
  for (int u = 0; u < 5; u++){ // find out minIndex5E and maxIndex5E
    if (arrayData1D5E[u] <= min) { min = arrayData1D5E[u]; minIndex5E = u; }
    if (arrayData1D5E[u] >= max) { max = arrayData1D5E[u]; maxIndex5E = u; }    
  } // for
  
  if (minIndex5E == maxIndex5E) { // all 5 items are the same
    minIndex5E = 0;
    maxIndex5E = 4;
  } // if

  // NOTE: positions in arrayData1D3E[] are: 0-2
  double arrayData1D3Ex[3] = {}; // index/position of arrayData1D5E[]: 0-4
  double arrayData1D3Ey[3] = {}; // value of arrayData1D5E[]
  int i = 0; // index of arrayData1D3Ex[] & arrayData1D3Ey[]
  for (int u = 0; u < 5; u++){ // construct arrayData1D3Ex[] & arrayData1D3Ey[]
    if        (u == minIndex5E) { 
    } else if (u == maxIndex5E) {
    } else {
     arrayData1D3Ex[i] = u;   
     arrayData1D3Ey[i] = arrayData1D5E[u];
     i = i + 1;
    } // if  
  } // for
  
  //// linear fitting (using linear regression)
  int n = 3; // number of points (x,y pairs)
  double xsum=0.00,x2sum=0.00,ysum=0.00,xysum=0.00; 	//variables for sums/sigma of xi,yi,xi^2,xiyi etc
  for (int i=0;i<n;i++)
  {
    xsum=xsum+arrayData1D3Ex[i];                        //calculate sigma(xi)
    ysum=ysum+arrayData1D3Ey[i];                        //calculate sigma(yi)
    x2sum=x2sum+pow(arrayData1D3Ex[i],2);  	        //calculate sigma(x^2i)
    xysum=xysum+arrayData1D3Ex[i]*arrayData1D3Ey[i];    //calculate sigma(xi*yi)
  } // for
  double a=(n*xysum-xsum*ysum)/(n*x2sum-xsum*xsum);     //calculate slope
  double b=(x2sum*ysum-xsum*xysum)/(n*x2sum-xsum*xsum); //calculate intercept
  
  //double y_fit[n];                                     //an array to store the new fitted values of y    
  //for (i=0;i<n;i++) { y_fit[i]=a*arrayData1D3Ex[i]+b;} //to calculate y(fitted) at given x (position) points
    
  return a*position+b; // a function of position // DefU, DefV, DefA; angTilt, angPsi
}




double SmoothFilamentsInRunDataStarXcrt::getAlignDirRiseTwist(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], double arrayAngRot1D5E[], std::vector<std::string> vectorImgName1D5E, int position)
{

  //// make sure that the 5 particles are not aligned to the same position in RELION, othersie you cannot do linear fitting
  double cx0 = arrayCoordX1D5E[0]; double cy0 = arrayCoordY1D5E[0];
  double ox0 = arrayOriX1D5E[0];   double oy0 = arrayOriY1D5E[0];

  double cx1 = arrayCoordX1D5E[1]; double cy1 = arrayCoordY1D5E[1];
  double ox1 = arrayOriX1D5E[1];   double oy1 = arrayOriY1D5E[1];
  
  double cx2 = arrayCoordX1D5E[2]; double cy2 = arrayCoordY1D5E[2];
  double ox2 = arrayOriX1D5E[2];   double oy2 = arrayOriY1D5E[2];
 
  double cx3 = arrayCoordX1D5E[3]; double cy3 = arrayCoordY1D5E[3];
  double ox3 = arrayOriX1D5E[3];   double oy3 = arrayOriY1D5E[3];
  
  double cx4 = arrayCoordX1D5E[4]; double cy4 = arrayCoordY1D5E[4];
  double ox4 = arrayOriX1D5E[4];   double oy4 = arrayOriY1D5E[4];  
  
  if ( sqrt( pow( (cx0-ox0)-(cx1-ox1),2) + pow( (cy0-oy0)-(cy1-oy1),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx1-ox1)-(cx2-ox2),2) + pow( (cy1-oy1)-(cy2-oy2),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx2-ox2)-(cx3-ox3),2) + pow( (cy2-oy2)-(cy3-oy3),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx3-ox3)-(cx4-ox4),2) + pow( (cy3-oy3)-(cy4-oy4),2) )  > iParO.helix_rise_range  ){
    //// do sth here
  } else {
    std::cout << "NOTE_ADRT: all 5 particles were aligned to the same position: " << vectorImgName1D5E[position]  << "\n"; 
  } 
  
  // WHEN WORKING ON AN PTCL, THE IMMEDIATELY PREVIOUS ONE IS USED AS A REFERENCE!!!
  double rise  = -400.00;
  double twist = -400.00;
  double alignRelPrev = -8.00; // alignRelPrev shift; <-2.00: unknown; (-2.00, -1.00, 0.00, 1.00, 2.00)
  double directionRel =  0.00; // filament direction; 0.00: unknown; (-1.00, 0.00, 1.00)
  if (position == 0) { // ptcl1
    alignRelPrev = -5.00; // first particle in the filament
    directionRel =  0.00;
    
    if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) ) < iParO.helix_rise_range ) {
      //std::cout << "NOTE_ADRT 00: the particle was aligned to the 00 position: " << vectorImgName1D5E[position]   << "\n";
      //alignRelPrev =  0.00;  
          
      // rise 
      rise = sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ); // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( ( (0+iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0+iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[0];
         //directionRel = 1.00;
	 } else 
      if ( ( (  (0+iParO.helix_twist_mean+360) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (  (0+iParO.helix_twist_mean+360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[0] - 360.00;
         //directionRel = 1.00;
	 } else 
      if ( ( (  (0-iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (  (0-iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[0] - arrayAngRot1D5E[1];
         //directionRel = -1.00;
	 } else 
      if ( ( ( (0-iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0-iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[0] - arrayAngRot1D5E[1] - 360.00;
         //directionRel = -1.00;
	 } else  { twist = 500.00;}
 
           
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl1 (actual position: [(cx0-ox0), (cy0-oy0)])
    } else if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ) < iParO.helix_rise_range ){
      //std::cout << "NOTE_ADRT -1: the particle was aligned to the -1 position: " << vectorImgName1D5E[position] << "\n";   
      //alignRelPrev = -1.00;   
      
      // rise [close to 0.00 pixels]
      rise = sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ) + iParO.helix_rise_mean; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // rise can also be - sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ) + iParO.helix_rise_mean but we cannot determine the direction.

      // twist [close to 0.00 pixels]
      twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[0] +iParO.helix_twist_mean; // twist can also be arrayAngRot1D5E[1] - arrayAngRot1D5E[2] +iParO.helix_twist_mean
                                                              // but we cannot determine the direction.
      if (twist < -180) { twist = twist + 360;} else if (twist > 180) { twist = twist - 360;}
      
      // direction [cannot be determined]
      //directionRel =  -1000.00;
      
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl3 (estimated position: [(cx2-ox0), (cy2-oy0)])
    } else if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx1-ox1)-(cx2-ox0),2) + pow( (cy1-oy1)-(cy2-oy0),2) ) < iParO.helix_rise_range ){  
      //std::cout << "NOTE_ADRT +1: the particle was aligned to the +1 position: " << vectorImgName1D5E[position] << "\n"; 
      //alignRelPrev =  1.00;   
         
       // rise [needs to be divided by 2] 
      rise = sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) )/2; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( (   (0+2*iParO.helix_twist_mean+360)  -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (   (0+2*iParO.helix_twist_mean+360)  +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[1] - arrayAngRot1D5E[0] - 360)/2;
         //directionRel = 1.00;
	 } else 
      if ( ( ( (0+2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0+2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])/2;
         //directionRel = 1.00;
	 } else 
      if ( ( (  (0-2*iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0-2*iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[0] - arrayAngRot1D5E[1] - 360)/2;
         //directionRel = -1.00;
	 } else 
      if ( ( (  (0-2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (  (0-2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[0] - arrayAngRot1D5E[1])/2;
         //directionRel = -1.00;
	 } else { twist = 1000.00;}

    
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) CANNOT BE  aligned to -2 position!!! 
    
        
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl4 (estimated position: [(cx3-ox0), (cy3-oy0)])
    } else if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx1-ox1)-(cx3-ox0),2) + pow( (cy1-oy1)-(cy3-oy0),2) )  < 2*iParO.helix_rise_range  ){  
      //std::cout << "NOTE_ADRT +2: the particle was aligned to the +2 position: " << vectorImgName1D5E[position] << "\n";     
      //alignRelPrev =  2.00;
      //directionRel =  0.00;  
    // ptcl2 was aligned to ptcl? [before ptcl1 or after ptcl4]    	      	    
    } else {
      //std::cout << "NOTE_ADRT ??: the particle was aligned to an unknown position: " << vectorImgName1D5E[position] << "\n"; 
      //alignRelPrev = -9.00;  
      //directionRel =  0.00;
      //std::cout << " cx0: " << cx0 << " cy0: " << cy0 << " ox0: " << ox0  << " oy0: " << oy0<< "\n";  
      //std::cout << " cx1: " << cx1 << " cy1: " << cy1 << " ox1: " << ox1  << " oy1: " << oy1<< "\n";          
    }
    
    
  } else if (position == 1) { // ptcl2
  
    // check the alignRelPrev of ptcl2 (position = 1) using ptcl1 (position = 0)
    // left: actual position; right: actual position (1st) or estimated position (2nd, 3rd, 4th)
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl2 (estimated position: [(cx1-ox0), (cy1-oy0)])
    if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy0)-(cy1-oy0),2) ) < iParO.helix_rise_range ) {
      std::cout << "NOTE_ADRT 00 (p1): the particle was aligned to the 00 position: " << vectorImgName1D5E[position]   << "\n";
      alignRelPrev =  0.00;  
          
      // rise 
      rise = sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ); // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( ( (0+iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0+iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[0];
         directionRel = 1.00;} else 
      if ( ( (  (0+iParO.helix_twist_mean+360) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (  (0+iParO.helix_twist_mean+360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[0] - 360.00;
         directionRel = 1.00;} else 
      if ( ( (  (0-iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (  (0-iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[0] - arrayAngRot1D5E[1];
         directionRel = -1.00;} else 
      if ( ( ( (0-iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0-iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[0] - arrayAngRot1D5E[1] - 360.00;
         directionRel = -1.00;} else  { twist = 500.00;}
 
           
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl1 (actual position: [(cx0-ox0), (cy0-oy0)])
    } else if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ) < iParO.helix_rise_range ){
      std::cout << "NOTE_ADRT -1 (p1): the particle was aligned to the -1 position: " << vectorImgName1D5E[position] << "\n";   
      alignRelPrev = -1.00;   
      
      // rise [close to 0.00 pixels]
      rise = sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ) + iParO.helix_rise_mean; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // rise can also be - sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) ) + iParO.helix_rise_mean but we cannot determine the direction.

      // twist [close to 0.00 pixels]
      twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[0] +iParO.helix_twist_mean; // twist can also be arrayAngRot1D5E[1] - arrayAngRot1D5E[2] +iParO.helix_twist_mean
                                                              // but we cannot determine the direction.
      if (twist < -180) { twist = twist + 360;} else if (twist > 180) { twist = twist - 360;}
      
      // direction [cannot be determined]
      directionRel =  -1000.00;
      
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl3 (estimated position: [(cx2-ox0), (cy2-oy0)])
    } else if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx1-ox1)-(cx2-ox0),2) + pow( (cy1-oy1)-(cy2-oy0),2) ) < iParO.helix_rise_range ){  
      std::cout << "NOTE_ADRT +1 (p1): the particle was aligned to the +1 position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev =  1.00;   
         
       // rise [needs to be divided by 2] 
      rise = sqrt( pow( (cx1-ox1)-(cx0-ox0),2) + pow( (cy1-oy1)-(cy0-oy0),2) )/2; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( (   (0+2*iParO.helix_twist_mean+360)  -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (   (0+2*iParO.helix_twist_mean+360)  +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[1] - arrayAngRot1D5E[0] - 360)/2;
         directionRel = 1.00;} else 
      if ( ( ( (0+2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0+2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])/2;
         directionRel = 1.00;} else 
      if ( ( (  (0-2*iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < ( (0-2*iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[0] - arrayAngRot1D5E[1] - 360)/2;
         directionRel = -1.00;} else 
      if ( ( (  (0-2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[1] - arrayAngRot1D5E[0])) && ( (arrayAngRot1D5E[1] - arrayAngRot1D5E[0]) < (  (0-2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[0] - arrayAngRot1D5E[1])/2;
         directionRel = -1.00;} else { twist = 1000.00;}

    
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) CANNOT BE  aligned to -2 position!!! 
    
        
    // ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)]) was aligned to ptcl4 (estimated position: [(cx3-ox0), (cy3-oy0)])
    } else if ( sqrt( pow( (cx1-ox1)-(cx1-ox0),2) + pow( (cy1-oy1)-(cy1-oy0),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx1-ox1)-(cx3-ox0),2) + pow( (cy1-oy1)-(cy3-oy0),2) )  < 2*iParO.helix_rise_range  ){  
      std::cout << "NOTE_ADRT +2 (p1): the particle was aligned to the +2 position: " << vectorImgName1D5E[position] << "\n";     
      alignRelPrev =  2.00;
      directionRel =  0.00;  
    // ptcl2 was aligned to ptcl? [before ptcl1 or after ptcl4]    	      	    
    } else {
      std::cout << "NOTE_ADRT ?? (p1): the particle was aligned to an unknown position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev = -9.00;  
      directionRel =  0.00;
      std::cout << " cx0: " << cx0 << " cy0: " << cy0 << " ox0: " << ox0  << " oy0: " << oy0<< "\n";  
      std::cout << " cx1: " << cx1 << " cy1: " << cy1 << " ox1: " << ox1  << " oy1: " << oy1<< "\n";          
    }

  } else if (position == 2) { // ptcl3
  
    // check the alignRelPrev of ptcl3 (position = 2) using ptcl2 (position = 1)
    // left: actual position; right: actual position (2nd) or estimated position (1st, 3rd, 4th & 5th)
    // ptcl3 (actual position: [(cx2-ox2), (cy2-oy2)]) was aligned to ptcl3 (estimated position: [(cx2-ox1), (cy2-oy1)])
    if ( sqrt( pow( (cx2-ox2)-(cx2-ox1),2) + pow( (cy2-oy2)-(cy2-oy1),2) ) < iParO.helix_rise_range ) {
      std::cout << "NOTE_ADRT 00 (p2): the particle was aligned to the 00 position: " << vectorImgName1D5E[position]   << "\n";
      alignRelPrev =  0.00;  
          
      // rise 
      rise = sqrt( pow( (cx2-ox2)-(cx1-ox1),2) + pow( (cy2-oy2)-(cy1-oy1),2) ); // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( ( (0+iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < ( (0+iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[2] - arrayAngRot1D5E[1];
         directionRel = 1.00;} else
      if ( ( (  (0+iParO.helix_twist_mean+360) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < (  (0+iParO.helix_twist_mean+360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[2] - arrayAngRot1D5E[1] - 360.00;
         directionRel = 1.00;} else
      if ( ( (  (0-iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < (  (0-iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[2];
         directionRel = -1.00;} else
      if ( ( ( (0-iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < ( (0-iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[1] - arrayAngRot1D5E[2] - 360.00;
         directionRel = -1.00;} else { twist = 500.00;}
            
    // ptcl3 (actual position: [(cx2-ox2), (cy2-oy2)]) was aligned to ptcl2 (actual position: [(cx1-ox1), (cy1-oy1)])
    } else if ( sqrt( pow( (cx2-ox2)-(cx2-ox1),2) + pow( (cy2-oy2)-(cy2-oy1),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx2-ox2)-(cx1-ox1),2) + pow( (cy2-oy2)-(cy1-oy1),2) ) < iParO.helix_rise_range ){
      std::cout << "NOTE_ADRT -1 (p2): the particle was aligned to the -1 position: " << vectorImgName1D5E[position] << "\n";   
      alignRelPrev = -1.00;  
      
      // rise [close to 0.00 pixels]
      rise = sqrt( pow( (cx2-ox2)-(cx1-ox1),2) + pow( (cy2-oy2)-(cy1-oy1),2) ) + iParO.helix_rise_mean; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // rise can also be - sqrt( pow( (cx2-ox2)-(cx1-ox1),2) + pow( (cy2-oy2)-(cy1-oy1),2) ) + iParO.helix_rise_mean but we cannot determine the direction.

      // twist [close to 0.00 pixels]
      twist =  arrayAngRot1D5E[2] - arrayAngRot1D5E[1] +iParO.helix_twist_mean; // twist can also be arrayAngRot1D5E[1] - arrayAngRot1D5E[2] +iParO.helix_twist_mean
                                                              // but we cannot determine the direction.
      if (twist < -180) { twist = twist + 360;} else if (twist > 180) { twist = twist - 360;}
      
      // direction [cannot be determined]
      directionRel =  -1000.00;
      
    // ptcl3 (actual position: [(cx2-ox2), (cy2-oy2)]) was aligned to ptcl4 (estimated position: [(cx3-ox1), (cy3-oy1)])
    } else if ( sqrt( pow( (cx2-ox2)-(cx2-ox1),2) + pow( (cy2-oy2)-(cy2-oy1),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx2-ox2)-(cx3-ox1),2) + pow( (cy2-oy2)-(cy3-oy1),2) ) < iParO.helix_rise_range ){  
      std::cout << "NOTE_ADRT +1 (p2): the particle was aligned to the +1 position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev =  1.00;   
      
       // rise [needs to be divided by 2]
      rise = sqrt( pow( (cx2-ox2)-(cx1-ox1),2) + pow( (cy2-oy2)-(cy1-oy1),2) )/2; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( (   (0+2*iParO.helix_twist_mean+360)  -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < (   (0+2*iParO.helix_twist_mean+360)  +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[2] - arrayAngRot1D5E[1] - 360)/2;
         directionRel = 1.00;} else 
      if ( ( ( (0+2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < ( (0+2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])/2;
         directionRel = 1.00;} else 
      if ( ( (  (0-2*iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < (  (0-2*iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[1] - arrayAngRot1D5E[2] - 360)/2;
         directionRel = -1.00;} else 
      if ( ( (  (0-2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[2] - arrayAngRot1D5E[1])) && ( (arrayAngRot1D5E[2] - arrayAngRot1D5E[1]) < (  (0-2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[1] - arrayAngRot1D5E[2])/2;
         directionRel = -1.00;} else { twist = 1000.00;}
  

    // ptcl3 (actual position: [(cx2-ox2), (cy2-oy2)]) was aligned to ptcl1 (estimated position: [(cx0-ox1), (cy0-oy1)])
    } else if ( sqrt( pow( (cx2-ox2)-(cx2-ox1),2) + pow( (cy2-oy2)-(cy2-oy1),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx2-ox2)-(cx0-ox1),2) + pow( (cy2-oy2)-(cy0-oy1),2) )  < 2*iParO.helix_rise_range  ){  
      std::cout << "NOTE_ADRT -2 (p2): the particle was aligned to the -2 position: " << vectorImgName1D5E[position] << "\n";     
      alignRelPrev = -2.00;  
      directionRel =  0.00;        
        
    // ptcl3 (actual position: [(cx2-ox2), (cy2-oy2)]) was aligned to ptcl5 (estimated position: [(cx4-ox1), (cy4-oy1)])
    } else if ( sqrt( pow( (cx2-ox2)-(cx2-ox1),2) + pow( (cy2-oy2)-(cy2-oy1),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx2-ox2)-(cx4-ox1),2) + pow( (cy2-oy2)-(cy4-oy1),2) )  < 2*iParO.helix_rise_range  ){  
      std::cout << "NOTE_ADRT +2: the particle was aligned to the +2 position: " << vectorImgName1D5E[position] << "\n";     
      alignRelPrev =  2.00;
      directionRel =  0.00;          
    // ptcl3 was aligned to ptcl? [before ptcl1 or after ptcl4]    	      	    
    } else {
      std::cout << "NOTE_ADRT ?? (p2): the particle was aligned to an unknown position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev = -9.00;  
      directionRel =  0.00;       
      std::cout << " cx1: " << cx1 << " cy1: " << cy1 << " ox1: " << ox1  << " oy1: " << oy1<< "\n";  
      std::cout << " cx2: " << cx2 << " cy2: " << cy2 << " ox2: " << ox2  << " oy2: " << oy2<< "\n";          
    }

  
  } else if (position == 3) { // ptcl4
  
    // check the alignRelPrev of ptcl4 (position = 3) using ptcl3 (position = 2)
    // left: actual position; right: actual position (4th) or estimated position (1st, 2nd 3rd & 5th)
    // ptcl4 (actual position: [(cx3-ox3), (cy3-oy3)]) was aligned to ptcl4 (estimated position: [(cx3-ox2), (cy3-oy2)])
    if ( sqrt( pow( (cx3-ox3)-(cx3-ox2),2) + pow( (cy3-oy3)-(cy3-oy2),2) ) < iParO.helix_rise_range ) {
      std::cout << "NOTE_ADRT 00 (p3): the particle was aligned to the 00 position: " << vectorImgName1D5E[position]   << "\n";
      alignRelPrev =  0.00;  
          
      // rise 
      rise = sqrt( pow( (cx3-ox3)-(cx2-ox2),2) + pow( (cy3-oy3)-(cy2-oy2),2) ); // [(cx3-ox3),(cy3-oy3)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( ( (0+iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < ( (0+iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[3] - arrayAngRot1D5E[2];
         directionRel =  1.00;} else 
      if ( ( (  (0+iParO.helix_twist_mean+360) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < (  (0+iParO.helix_twist_mean+360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[3] - arrayAngRot1D5E[2] - 360.00;
         directionRel =  1.00;} else 
      if ( ( (  (0-iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < (  (0-iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[2] - arrayAngRot1D5E[3];
         directionRel = -1.00;} else 
      if ( ( ( (0-iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < ( (0-iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[2] - arrayAngRot1D5E[3] - 360.00;
         directionRel = -1.00;} else { twist = 500.00;}
           
    // ptcl4 (actual position: [(cx3-ox3), (cy3-oy3)]) was aligned to ptcl3 (actual position: [(cx2-ox2), (cy2-oy2)])
    } else if ( sqrt( pow( (cx3-ox3)-(cx3-ox2),2) + pow( (cy3-oy3)-(cy3-oy2),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx3-ox3)-(cx2-ox2),2) + pow( (cy3-oy3)-(cy2-oy2),2) ) < iParO.helix_rise_range ){
      std::cout << "NOTE_ADRT -1 (p3): the particle was aligned to the -1 position: " << vectorImgName1D5E[position] << "\n";   
      alignRelPrev = -1.00;   
      
      // rise [close to 0.00 pixels]
      rise = sqrt( pow( (cx3-ox3)-(cx2-ox2),2) + pow( (cy3-oy3)-(cy2-oy2),2) ) + iParO.helix_rise_mean; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // rise can also be - sqrt( pow( (cx3-ox3)-(cx2-ox2),2) + pow( (cy3-oy3)-(cy2-oy2),2) ) + iParO.helix_rise_mean but we cannot determine the direction.

      // twist [close to 0.00 pixels]
      twist =  arrayAngRot1D5E[3] - arrayAngRot1D5E[2] +iParO.helix_twist_mean; // twist can also be arrayAngRot1D5E[1] - arrayAngRot1D5E[2] +iParO.helix_twist_mean
                                                              // but we cannot determine the direction.
      if (twist < -180) { twist = twist + 360;} else if (twist > 180) { twist = twist - 360;}							      
							      
      // direction [cannot be determined]
      directionRel =  -1000.00;
 
    // ptcl4 (actual position: [(cx3-ox3), (cy3-oy3)]) was aligned to ptcl5 (estimated position: [(cx4-ox2), (cy4-oy2)])
    } else if ( sqrt( pow( (cx3-ox3)-(cx3-ox2),2) + pow( (cy3-oy3)-(cy3-oy2),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx3-ox3)-(cx4-ox2),2) + pow( (cy3-oy3)-(cy4-oy2),2) ) < iParO.helix_rise_range ){  
      std::cout << "NOTE_ADRT +1 (p3): the particle was aligned to the +1 position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev =  1.00;   
      
      // rise [needs to be divided by 2]
      rise = sqrt( pow( (cx3-ox3)-(cx2-ox2),2) + pow( (cy3-oy3)-(cy2-oy2),2) )/2; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( (   (0+2*iParO.helix_twist_mean+360)  -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < (   (0+2*iParO.helix_twist_mean+360)  +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[3] - arrayAngRot1D5E[2] - 360)/2;
         directionRel = 1.00;} else 
      if ( ( ( (0+2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < ( (0+2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])/2;
         directionRel = 1.00;} else 
      if ( ( (  (0-2*iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < (  (0-2*iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[2] - arrayAngRot1D5E[3] - 360)/2;
         directionRel = -1.00;} else 
      if ( ( (  (0-2*iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[3] - arrayAngRot1D5E[2])) && ( (arrayAngRot1D5E[3] - arrayAngRot1D5E[2]) < (  (0-2*iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  (arrayAngRot1D5E[2] - arrayAngRot1D5E[3])/2;
         directionRel = -1.00;} else { twist = 1000.00;}
   

    // ptcl4 (actual position: [(cx3-ox3), (cy3-oy3)]) was aligned to ptcl2 (estimated position: [(cx1-ox2), (cy1-oy2)])
    } else if ( sqrt( pow( (cx3-ox3)-(cx3-ox2),2) + pow( (cy3-oy3)-(cy3-oy2),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx3-ox3)-(cx1-ox2),2) + pow( (cy3-oy3)-(cy1-oy2),2) )  < 2*iParO.helix_rise_range  ){  
      std::cout << "NOTE_ADRT -2 (p3): the particle was aligned to the -2 position: " << vectorImgName1D5E[position] << "\n";     
      alignRelPrev = -2.00;   
      directionRel =  0.00;       
       
    // ptcl4 (actual position: [(cx3-ox3), (cy3-oy3)]) CANNOT BE  aligned to the +2 position!!!         
    
    // ptcl4 was aligned to ptcl? [before ptcl1 or after ptcl4]    	      	    
    } else {
      std::cout << "NOTE_ADRT ?? (p3): the particle was aligned to an unknown position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev = -9.00;  
      directionRel =  0.00;       
      std::cout << " cx1: " << cx1 << " cy1: " << cy1 << " ox1: " << ox1  << " oy1: " << oy1<< "\n";  
      std::cout << " cx2: " << cx2 << " cy2: " << cy2 << " ox2: " << ox2  << " oy2: " << oy2<< "\n";          
    }
  
  } else if (position == 4) { // ptcl5
  
    // check the alignRelPrev of ptcl5 (position = 4) using ptcl4 (position = 3)
    // left: actual position; right: actual position (5th) or estimated position (2nd 3rd & 4th)
    // ptcl5 (actual position: [(cx4-ox4), (cy4-oy4)]) was aligned to ptcl5 (estimated position: [(cx4-ox3), (cy4-oy3)])
    if ( sqrt( pow( (cx4-ox4)-(cx4-ox3),2) + pow( (cy4-oy4)-(cy4-oy3),2) ) < iParO.helix_rise_range ) {
      std::cout << "NOTE_ADRT 00 (p4): the particle was aligned to the 00 position: " << vectorImgName1D5E[position]   << "\n";
      alignRelPrev =  0.00;  
          
      // rise 
      rise = sqrt( pow( (cx4-ox4)-(cx3-ox3),2) + pow( (cy4-oy4)-(cy3-oy3),2) ); // [(cx3-ox3),(cy3-oy3)] is the aligned position of ptcl3.
      // twist & direction
      if ( ( ( (0+iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[4] - arrayAngRot1D5E[3])) && ( (arrayAngRot1D5E[4] - arrayAngRot1D5E[3]) < ( (0+iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[4] - arrayAngRot1D5E[3];
         directionRel =  1.00;} else 
      if ( ( (  (0+iParO.helix_twist_mean+360) -iParO.helix_twist_range) < (arrayAngRot1D5E[4] - arrayAngRot1D5E[3])) && ( (arrayAngRot1D5E[4] - arrayAngRot1D5E[3]) < (  (0+iParO.helix_twist_mean+360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[4] - arrayAngRot1D5E[3] - 360.00;
         directionRel =  1.00;} else 
      if ( ( (  (0-iParO.helix_twist_mean) -iParO.helix_twist_range) < (arrayAngRot1D5E[4] - arrayAngRot1D5E[3])) && ( (arrayAngRot1D5E[4] - arrayAngRot1D5E[3]) < (  (0-iParO.helix_twist_mean) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[3] - arrayAngRot1D5E[4];
         directionRel = -1.00;} else 
      if ( ( ( (0-iParO.helix_twist_mean-360) -iParO.helix_twist_range) < (arrayAngRot1D5E[4] - arrayAngRot1D5E[3])) && ( (arrayAngRot1D5E[4] - arrayAngRot1D5E[3]) < ( (0-iParO.helix_twist_mean-360) +iParO.helix_twist_range) ) ) {
         twist =  arrayAngRot1D5E[3] - arrayAngRot1D5E[4] - 360.00;
         directionRel = -1.00;} else  { twist = 500.00;}
           
    // ptcl5 (actual position: [(cx4-ox4), (cy4-oy4)]) was aligned to ptcl4 (actual position: [(cx3-ox3), (cy3-oy3)])
    } else if ( sqrt( pow( (cx4-ox4)-(cx4-ox3),2) + pow( (cy4-oy4)-(cy4-oy3),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx4-ox4)-(cx3-ox3),2) + pow( (cy4-oy4)-(cy3-oy3),2) ) < iParO.helix_rise_range ){
      std::cout << "NOTE_ADRT -1 (p4): the particle was aligned to the -1 position: " << vectorImgName1D5E[position] << "\n";   
      alignRelPrev = -1.00;   
      
      // rise [close to 0.00 pixels]
      rise = sqrt( pow( (cx4-ox4)-(cx3-ox3),2) + pow( (cy4-oy4)-(cy3-oy3),2) ) + iParO.helix_rise_mean; // [(cx2-ox2),(cy2-oy2)] is the aligned position of ptcl3.
      // rise can also be - sqrt( pow( (cx4-ox4)-(cx3-ox3),2) + pow( (cy4-oy4)-(cy3-oy3),2) ) + iParO.helix_rise_mean but we cannot determine the direction.

      // twist [close to 0.00 pixels]
      twist =  arrayAngRot1D5E[4] - arrayAngRot1D5E[3] +iParO.helix_twist_mean; // twist can also be arrayAngRot1D5E[1] - arrayAngRot1D5E[2] +iParO.helix_twist_mean
                                                              // but we cannot determine the direction.
      if (twist < -180) { twist = twist + 360;} else if (twist > 180) { twist = twist - 360;}  
      
      // direction [cannot be determined]
      directionRel =  -1000.00;

    // ptcl5 (actual position: [(cx4-ox4), (cy4-oy4)]) CANNOT BE  aligned to +1 position!!! 
      
    // ptcl5 (actual position: [(cx4-ox4), (cy4-oy4)]) was aligned to ptcl3 (estimated position: [(cx2-ox3), (cy2-oy3)])
    } else if ( sqrt( pow( (cx4-ox4)-(cx4-ox3),2) + pow( (cy4-oy4)-(cy4-oy3),2) )  > iParO.helix_rise_range  && 
                sqrt( pow( (cx4-ox4)-(cx2-ox3),2) + pow( (cy4-oy4)-(cy2-oy3),2) )  < 2*iParO.helix_rise_range  ){  
      std::cout << "NOTE_ADRT -2 (p4): the particle was aligned to the -2 position: " << vectorImgName1D5E[position] << "\n";     
      alignRelPrev = -2.00;   
      directionRel =  0.00;      
       
    // ptcl5 (actual position: [(cx4-ox4), (cy4-oy4)]) CANNOT BE  aligned to +2 position!!!         
    
    // ptcl5 was aligned to ptcl? [before ptcl1 or after ptcl4]    	      	    
    } else {
      std::cout << "NOTE_ADRT ?? (p4): the particle was aligned to an unknown position: " << vectorImgName1D5E[position] << "\n"; 
      alignRelPrev = -9.00;  
      directionRel =  0.00;      
      std::cout << " cx1: " << cx1 << " cy1: " << cy1 << " ox1: " << ox1  << " oy1: " << oy1<< "\n";  
      std::cout << " cx2: " << cx2 << " cy2: " << cy2 << " ox2: " << ox2  << " oy2: " << oy2<< "\n";          
    }  
  
  
  } else {
    std::cout << "ERROR: position can only be 0, 1, 2, 3, 4; currently it's set to: " << position  << "\n";
  }


  std::cout << " rise: " << rise << " twist: " << twist << " alignment: " << alignRelPrev << " directionRel: " << directionRel << " position: " << position << " " << vectorImgName1D5E[position] << "\n";
  
  arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[0] = alignRelPrev; 
  arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[1] = directionRel; 
  arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2] = rise; // without considering out-of-plane tilt  
                                                        // after 2eca and Refine3D, you NEED to  / cos((angTilt-90) * 3.1415926/180) to calculate the rise later
  arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3] = twist; // without considering out-of-plane tilt  
                                                         // after 2eca and Refine3D, you DO NOT NEED to  * cos((angTilt-90) * 3.1415926/180) to calculate the twist later
  return arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6];
}



double SmoothFilamentsInRunDataStarXcrt::estimateAlignedXY(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], int position, double subunitRise, double NoOfSubunits)
{

  
  //// make sure that the 5 particles are not aligned to the same position in RELION, othersie you cannot do linear fitting
  double cx0 = arrayCoordX1D5E[0]; double cy0 = arrayCoordY1D5E[0];
  double ox0 = arrayOriX1D5E[0];   double oy0 = arrayOriY1D5E[0];
  
 
  double cx1 = arrayCoordX1D5E[1]; double cy1 = arrayCoordY1D5E[1];
  double ox1 = arrayOriX1D5E[1];   double oy1 = arrayOriY1D5E[1];
  
  double cx2 = arrayCoordX1D5E[2]; double cy2 = arrayCoordY1D5E[2];
  double ox2 = arrayOriX1D5E[2];   double oy2 = arrayOriY1D5E[2];
  
 
  double cx3 = arrayCoordX1D5E[3]; double cy3 = arrayCoordY1D5E[3];
  double ox3 = arrayOriX1D5E[3];   double oy3 = arrayOriY1D5E[3];
  
  double cx4 = arrayCoordX1D5E[4]; double cy4 = arrayCoordY1D5E[4];
  double ox4 = arrayOriX1D5E[4];   double oy4 = arrayOriY1D5E[4];  
  
  if ( sqrt( pow( (cx0-ox0)-(cx1-ox1),2) + pow( (cy0-oy0)-(cy1-oy1),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx1-ox1)-(cx2-ox2),2) + pow( (cy1-oy1)-(cy2-oy2),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx2-ox2)-(cx3-ox3),2) + pow( (cy2-oy2)-(cy3-oy3),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx3-ox3)-(cx4-ox4),2) + pow( (cy3-oy3)-(cy4-oy4),2) )  > iParO.helix_rise_range  ){
    //// do sth here
  } else {
    std::cout << "NOTE_AXY: all 5 particles were aligned to the same position: \n"; 
  } 
  
  // Xa: aligned X; coordX - oriX
  // Ya: aligned Y: coordY - oriY
  
  // Xe: estimated X; coordX - oriX
  // Ye: estimated Y: coordY - oriY  
  
  //// linear fitting (using linear regression)
  int n = 5; // number of points (x,y pairs)
  double x=0.00,y=0.00;
  double xsum=0.00,x2sum=0.00,ysum=0.00,xysum=0.00; 	//variables for sums/sigma of xi,yi,xi^2,xiyi etc
  for (int i=0;i<n;i++)
  {
    x=arrayCoordX1D5E[i] - arrayOriX1D5E[i];
    y=arrayCoordY1D5E[i] - arrayOriY1D5E[i];
    xsum=xsum+x;                        //calculate sigma(xi)
    ysum=ysum+y;                        //calculate sigma(yi)
    x2sum=x2sum+pow(x,2);  	        //calculate sigma(x^2i)
    xysum=xysum+x*y;    //calculate sigma(xi*yi)
  } // for
  double a=(n*xysum-xsum*ysum)/(n*x2sum-xsum*xsum);     //calculate slope
  double b=(x2sum*ysum-xsum*xysum)/(n*x2sum-xsum*xsum); //calculate intercept
  std::cout << "a: " << a << " b: " << b << "\n"; 


  /*
  xsum=0.00,x2sum=0.00,ysum=0.00,xysum=0.00; 	//variables for sums/sigma of xi,yi,xi^2,xiyi etc
  for (int i=0;i<n;i++)
  {
    x=arrayCoordX1D5E[i];
    y=arrayCoordY1D5E[i];
    xsum=xsum+x;                        //calculate sigma(xi)
    ysum=ysum+y;                        //calculate sigma(yi)
    x2sum=x2sum+pow(x,2);  	        //calculate sigma(x^2i)
    xysum=xysum+x*y;    //calculate sigma(xi*yi)
  } // for
  double c=(n*xysum-xsum*ysum)/(n*x2sum-xsum*xsum);     //calculate slope
  double d=(x2sum*ysum-xsum*xysum)/(n*x2sum-xsum*xsum); //calculate intercept
  std::cout << "c: " << c << " d: " << d << "\n"; 
  */
  
  
  // AX^2+BX+C=0  // distance between [Xa,Ya] and [Xe,Ye] should be 1 subunit rise. Rearrange the distance equation.
  // sqrt( (Xa-Xe)^2 + (Ya-Ye)^2) )= subunitRise * NoOfSubunits
  double B = 0.00;
  double Bs = 0.00;
  double C = 0.00;
  double A = 0.00;
  double sr = subunitRise; // subunit rise 
  double ns = NoOfSubunits; // number of subunits
    //std::cout << "subunitRise: " << subunitRise << " NoOfSubunits: " << NoOfSubunits << "\n"; 
    
  double Xa;
  double Ya;
  double Bsm4AC;
  
  double Xe1;
  double Ye1;
  double Xe2;
  double Ye2;
  
  double distS_e1;
  double distS_e2;
  double Xe;
  double Ye;  
  /*
  if (position == 0) { // ptcl1
    Xa = arrayCoordX1D5E[0] - arrayOriX1D5E[0];
    Ya = arrayCoordY1D5E[0] - arrayOriY1D5E[0]; 
  } else if (position == 1) { // ptcl2 
    Xa = arrayCoordX1D5E[1] - arrayOriX1D5E[1];
    Ya = arrayCoordY1D5E[1] - arrayOriY1D5E[1];     
  } else if (position == 2) { // ptcl3  
    Xa = arrayCoordX1D5E[2] - arrayOriX1D5E[2];
    Ya = arrayCoordY1D5E[2] - arrayOriY1D5E[2]; 
  } else if (position == 3) { // ptcl4  
    Xa = arrayCoordX1D5E[3] - arrayOriX1D5E[3];
    Ya = arrayCoordY1D5E[3] - arrayOriY1D5E[3];   
  } else if (position == 4) { // ptcl5
    Xa = arrayCoordX1D5E[4] - arrayOriX1D5E[4];
    Ya = arrayCoordY1D5E[4] - arrayOriY1D5E[4]; 
  }   
  */
  Xa = arrayCoordX1D5E[position] - arrayOriX1D5E[position];
  Ya = arrayCoordY1D5E[position] - arrayOriY1D5E[position];
  
    //std::cout << "Xa: " << Xa << " Ya: " << Ya << "\n";
    
    A = 1 + pow(a,2);          // A = (1+a)^2; always >= 1.00
    B = 2*a*b - 2*Xa -2*a*Ya;  // B = 2ab -aXa -2aYa
    Bs = pow(B,2);
    C = pow(Xa,2) + pow(b,2) + pow(Ya,2) - 2*b*Ya - pow((ns*sr),2);  // C= Xa^2 + Ya^2 + b^2 - 2bYa - (ns*sr)^2

    //std::cout << "B: " << B << " Bs: " << Bs << "\n";
    //std::cout << "A: " << A << " C: " << C << "\n";
     
    Bsm4AC = Bs-4*A*C;
    //std::cout << "Bsm4AC: " << Bsm4AC << " C: " << C << "\n";  
            
    Xe1 = (0.00- B + pow(Bsm4AC,0.5) )/A/2;
    Ye1 = a*Xe1+b;
    Xe2 = (0.00- B - pow(Bsm4AC,0.5) )/A/2;
    Ye2 = a*Xe2+b;
    
    //std::cout << "Xe1: " << Xe1 << " Ye1: " << Ye1 << "\n";
    //std::cout << "Xe2: " << Xe2 << " Ye2: " << Ye2 << "\n";    
	    
    distS_e1 = pow ( (Xe1 - arrayCoordX1D5E[position]), 2) + pow ( (Ye1 - arrayCoordY1D5E[position]), 2);	       
    distS_e2 = pow ( (Xe2 - arrayCoordX1D5E[position]), 2) + pow ( (Ye2 - arrayCoordY1D5E[position]), 2);
    //std::cout << "distS_e1: " << pow (distS_e1, 0.5) << " distS_e2: " << pow (distS_e2, 0.5) << "\n";
    
    if ( distS_e1 < distS_e2) { Xe = Xe1; Ye = Ye1;} else
    if ( distS_e1 > distS_e2) { Xe = Xe2; Ye = Ye2;} else
    { Xe = Xe2; Ye = Ye2; std::cout << "NOTE_AXY: Could NOT determine Xe and Ye! \n";}
    // This assumes that the one closer to [Xo,Yo] is the right one!!!
    
    //std::cout << "Xe: " << Xe << " Ye: " << Ye << "\n";  
    
    arrayCoordEst[0] = Xe;
    arrayCoordEst[1] = Ye;
    return arrayCoordEst[2];
}




double SmoothFilamentsInRunDataStarXcrt::estimateCoordxyAngrot(double arrayCoordX1D5E[], double arrayCoordY1D5E[], double arrayOriX1D5E[], double arrayOriY1D5E[], double arrayAngRot1D5E[], std::vector<std::string> vectorImgName1D5E, int position, int filAlignRelFirst, int filDir, double arrayAlignRelFirst1D5E[], double arrayDiscon1D5E[])
{
  
  //// make sure that the 5 particles are not aligned to the same position in RELION, othersie you cannot do linear fitting
  double cx0 = arrayCoordX1D5E[0]; double cy0 = arrayCoordY1D5E[0];
  double ox0 = arrayOriX1D5E[0];   double oy0 = arrayOriY1D5E[0];
  
 
  double cx1 = arrayCoordX1D5E[1]; double cy1 = arrayCoordY1D5E[1];
  double ox1 = arrayOriX1D5E[1];   double oy1 = arrayOriY1D5E[1];
  
  double cx2 = arrayCoordX1D5E[2]; double cy2 = arrayCoordY1D5E[2];
  double ox2 = arrayOriX1D5E[2];   double oy2 = arrayOriY1D5E[2];
  
 
  double cx3 = arrayCoordX1D5E[3]; double cy3 = arrayCoordY1D5E[3];
  double ox3 = arrayOriX1D5E[3];   double oy3 = arrayOriY1D5E[3];
  
  double cx4 = arrayCoordX1D5E[4]; double cy4 = arrayCoordY1D5E[4];
  double ox4 = arrayOriX1D5E[4];   double oy4 = arrayOriY1D5E[4];  
  
  if ( sqrt( pow( (cx0-ox0)-(cx1-ox1),2) + pow( (cy0-oy0)-(cy1-oy1),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx1-ox1)-(cx2-ox2),2) + pow( (cy1-oy1)-(cy2-oy2),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx2-ox2)-(cx3-ox3),2) + pow( (cy2-oy2)-(cy3-oy3),2) )  > iParO.helix_rise_range  ||
       sqrt( pow( (cx3-ox3)-(cx4-ox4),2) + pow( (cy3-oy3)-(cy4-oy4),2) )  > iParO.helix_rise_range  ){
    //// do sth here
  } else {
    std::cout << "WARNING: all 5 particles were aligned to the same position: " << vectorImgName1D5E[position]  << "\n"; 
  } 

  // to-do:  
  double subunitRise = iParO.helix_rise_mean; 
  double NoOfSubunits = 1.00; // change this later in parameter file
  coOrX = 0.00; 
  coOrY = 0.00; 
  angRot = 0.00;   

  std::cout << " coordX: " << arrayCoordX1D5E[position] << " coordY: " << arrayCoordY1D5E[position] 
            << " oriX: " << arrayOriX1D5E[position] << " oriY: " << arrayOriY1D5E[position] 
	    << " angRot: " << arrayAngRot1D5E[position] << "\n";
	  
  // WE"RE TRYING TO CHANGE COORDX AND COORDY, SO THAT ORIX AND ORIY ARE (CLOSE TO) 0.
  if (position == 0) { // ptcl1	
    if (filAlignRelFirst == 0.00) { // checked
      //if (arrayAlignRelFirst1D5E[0] ==  0.00) { 
        coOrX = arrayCoordX1D5E[0] - arrayOriX1D5E[0];
        coOrY = arrayCoordY1D5E[0] - arrayOriY1D5E[0];
        angRot = arrayAngRot1D5E[0];
		
      /*} else if (arrayAlignRelFirst1D5E[2] == -1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  0.00) { 
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  0.00) {
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		 
      } else if (arrayAlignRelFirst1D5E[2] == 1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  0.00) { 
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  0.00) {
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      }// if (arrayAlignRelFirst1D5E[2] ==
      */
           
    } else if (filAlignRelFirst == -1.00) {
      /*if (arrayAlignRelFirst1D5E[2] ==  -1.00) { 
        coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[2];
        coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[2];
        angRot = arrayAngRot1D5E[2];	
      } else if (arrayAlignRelFirst1D5E[2] == 0.00) {
      */
        if (arrayAlignRelFirst1D5E[1] ==  -1.00) { 
          coOrX = arrayCoordX1D5E[0] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[0] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  -1.00) {
          coOrX = arrayCoordX1D5E[0] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[0] - arrayOriY1D5E[2];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[0] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[0] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      /*} else if (arrayAlignRelFirst1D5E[2] == 1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  -1.00) { 
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  -1.00) {
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] + 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] - 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 
      */

    } else if (filAlignRelFirst ==  1.00) {   
      /*if (arrayAlignRelFirst1D5E[2] ==  1.00) { 
        coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[2];
        coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[2];
        angRot = arrayAngRot1D5E[2];	
      } else if (arrayAlignRelFirst1D5E[2] == 0.00) {*/
        if (arrayAlignRelFirst1D5E[1] ==  1.00) { 
	                                                 // problem ? 000021@Extract/job010/Micrographs/dp6_0004.mrcs
          coOrX = arrayCoordX1D5E[0] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[0] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  1.00) {
          coOrX = arrayCoordX1D5E[0] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[0] - arrayOriY1D5E[2];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[0] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[0] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      /*} else if (arrayAlignRelFirst1D5E[2] == -1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  1.00) { 
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  1.00) {
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] - 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] + 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 
      */

    } //if (filAlignRelFirst ==  


    
  } else if (position == 1) { // ptcl2   
    if (filAlignRelFirst == 0.00) { // checked
      if (arrayAlignRelFirst1D5E[1] ==  0.00) { 
        coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[1];
        coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[1];
        angRot = arrayAngRot1D5E[1];
      } else if (arrayAlignRelFirst1D5E[1] == -1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  0.00) { // [2] is more reliable than [0]
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[0] ==  0.00) { // always
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[0];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[0];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[1] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[1] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		 
      } else if (arrayAlignRelFirst1D5E[1] == 1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  0.00) { // [2] is more reliable than [0]
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[0] ==  0.00) { // always
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[0];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[0];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[1] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[1] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      }// if (arrayAlignRelFirst1D5E[2] ==
      
           
    } else if (filAlignRelFirst == -1.00) {
      if (arrayAlignRelFirst1D5E[1] ==  -1.00) { 
        coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[1];
        coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[1];
        angRot = arrayAngRot1D5E[1];	
      } else if (arrayAlignRelFirst1D5E[1] == 0.00) {	 
        if (arrayAlignRelFirst1D5E[2] ==  -1.00) { 
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  -1.00) {
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[3];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[1] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[1] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[1] == 1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  -1.00) { // almost impossible
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  -1.00) {
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[3];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[1] + 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[1] - 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } else if (filAlignRelFirst ==  1.00) {   
      if (arrayAlignRelFirst1D5E[1] ==  1.00) { 
        coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[1];
        coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[1];
        angRot = arrayAngRot1D5E[1];	
      } else if (arrayAlignRelFirst1D5E[1] == 0.00) {	
        if (arrayAlignRelFirst1D5E[2] ==  1.00) { 
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  1.00) {
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[3];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[1] == -1.00) { 
        if (arrayAlignRelFirst1D5E[2] ==  1.00) { // almost impossible
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  1.00) {
          coOrX = arrayCoordX1D5E[1] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[1] - arrayOriY1D5E[3];	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] - 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] + 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } //if (filAlignRelFirst ==  

    
  } else if (position == 2) { // ptcl3    
    if (filAlignRelFirst == 0.00) {
      if (arrayAlignRelFirst1D5E[2] ==  0.00) {  // 000003@Extract/job010/Micrographs/dp6_0001.mrcs
        coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[2];
        coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[2];
        angRot = arrayAngRot1D5E[2];
      } else if (arrayAlignRelFirst1D5E[2] == -1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  0.00) {  // 000416@Extract/job010/Micrographs/dp6_0002.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  0.00) { // 000414@Extract/job010/Micrographs/dp6_0002.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else { // 000181@Extract/job010/Micrographs/dp6_0014.mrcs
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		 
      } else if (arrayAlignRelFirst1D5E[2] == 1.00) { 
        if (arrayAlignRelFirst1D5E[1] ==  0.00) { // 000205@Extract/job010/Micrographs/dp6_0004.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  0.00) { // 000208@Extract/job010/Micrographs/dp6_0004.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else { // 000206@Extract/job010/Micrographs/dp6_0004.mrcs
	         // FILAMENT (Rot) BREAK? 000204@Extract/job010/Micrographs/dp6_0004.mrcs 000205@Extract/job010/Micrographs/dp6_0004.mrcs
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      }// if (arrayAlignRelFirst1D5E[2] ==
      
           
    } else if (filAlignRelFirst == -1.00) {
      if (arrayAlignRelFirst1D5E[2] ==  -1.00) { // 000226@Extract/job010/Micrographs/dp6_0002.mrcs
        coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[2];
        coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[2];
        angRot = arrayAngRot1D5E[2];	
      } else if (arrayAlignRelFirst1D5E[2] == 0.00) {	 
        if (arrayAlignRelFirst1D5E[1] ==  -1.00) { // 000227@Extract/job010/Micrographs/dp6_0002.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  -1.00) { // 000344@Extract/job010/Micrographs/dp6_0002.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else { // 000335@Extract/job010/Micrographs/dp6_0002.mrcs
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[2] == 1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  -1.00) { // almost impossible
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  -1.00) {
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] + 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] - 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } else if (filAlignRelFirst ==  1.00) {   
      if (arrayAlignRelFirst1D5E[2] ==  1.00) { // 000023@Extract/job010/Micrographs/dp6_0004.mrcs
        coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[2];
        coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[2];
        angRot = arrayAngRot1D5E[2];	
      } else if (arrayAlignRelFirst1D5E[2] == 0.00) {
        if (arrayAlignRelFirst1D5E[1] ==  1.00) { // 000234@Extract/job010/Micrographs/dp6_0004.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  1.00) { // 000235@Extract/job010/Micrographs/dp6_0004.mrcs
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else { // 000109@Extract/job010/Micrographs/dp6_0014.mrcs
	         // filament (Rot) break? between 000108@Extract/job010/Micrographs/dp6_0014.mrcs 000109@Extract/job010/Micrographs/dp6_0014.mrcs
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[2] == -1.00) {
        if (arrayAlignRelFirst1D5E[1] ==  1.00) { // almost impossible 
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[1];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[1];	 
        } else if (arrayAlignRelFirst1D5E[3] ==  1.00) {
          coOrX = arrayCoordX1D5E[2] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[2] - arrayOriY1D5E[3];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] - 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] + 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } //if (filAlignRelFirst ==  

  } else if (position == 3) { // ptcl4  
    if (filAlignRelFirst == 0.00) {
      if (arrayAlignRelFirst1D5E[3] ==  0.00) { // checked
        coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[3];
        coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[3];
        angRot = arrayAngRot1D5E[3];
      } else if (arrayAlignRelFirst1D5E[3] == -1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  0.00) { 
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[4] ==  0.00) {
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[4];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[4];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[3] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[3] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		 
      } else if (arrayAlignRelFirst1D5E[3] == 1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  0.00) { 
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[4] ==  0.00) {
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[4];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[4];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[3] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[3] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      }// if (arrayAlignRelFirst1D5E[2] ==
      
           
    } else if (filAlignRelFirst == -1.00) {
      if (arrayAlignRelFirst1D5E[3] ==  -1.00) { 
        coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[3];
        coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[3];
        angRot = arrayAngRot1D5E[3];	
      } else if (arrayAlignRelFirst1D5E[3] == 0.00) {	 
        if (arrayAlignRelFirst1D5E[2] ==  -1.00) { 
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[4] ==  -1.00) {
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[4];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[4];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[3] == 1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  -1.00) { // almost impossible
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[2];
        } else if (arrayAlignRelFirst1D5E[4] ==  -1.00) {
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[4];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[4];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[3] + 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[3] - 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } else if (filAlignRelFirst ==  1.00) {   
      if (arrayAlignRelFirst1D5E[3] ==  1.00) { 
        coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[3];
        coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[3];
        angRot = arrayAngRot1D5E[3];	
      } else if (arrayAlignRelFirst1D5E[3] == 0.00) {	 
        if (arrayAlignRelFirst1D5E[2] ==  1.00) { 
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[4] ==  1.00) {
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[4];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[4];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[3] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[3] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[3] == -1.00) {
        if (arrayAlignRelFirst1D5E[2] ==  1.00) { // almost impossible
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[2];	 
        } else if (arrayAlignRelFirst1D5E[4] ==  1.00) {
          coOrX = arrayCoordX1D5E[3] - arrayOriX1D5E[4];
          coOrY = arrayCoordY1D5E[3] - arrayOriY1D5E[4];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[3] - 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[3] + 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } //if (filAlignRelFirst ==  

    
  } else if (position == 4) { // ptcl5   
    if (filAlignRelFirst == 0.00) {
      if (arrayAlignRelFirst1D5E[4] ==  0.00) { // checked
        coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[4];
        coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[4];
        angRot = arrayAngRot1D5E[4];
      } else if (arrayAlignRelFirst1D5E[4] == -1.00) {
        if (arrayAlignRelFirst1D5E[3] ==  0.00) { 
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[3];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  0.00) {
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[2];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		 
      } else if (arrayAlignRelFirst1D5E[4] == 1.00) {
        if (arrayAlignRelFirst1D5E[3] ==  0.00) { 
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[3];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  0.00) {
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[2];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[4] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[4] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      }// if (arrayAlignRelFirst1D5E[2] ==
      
           
    } else if (filAlignRelFirst == -1.00) {
      if (arrayAlignRelFirst1D5E[4] ==  -1.00) { 
        coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[4];
        coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[4];
        angRot = arrayAngRot1D5E[4];	
      } else if (arrayAlignRelFirst1D5E[4] == 0.00) {	 
        if (arrayAlignRelFirst1D5E[3] ==  -1.00) { 
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[3];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  -1.00) {
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[2];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[4] +  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[4] -  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[4] == 1.00) {
        if (arrayAlignRelFirst1D5E[3] ==  -1.00) { // almost impossible
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[3];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  -1.00) {
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[2];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[2] + 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[2] - 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } else if (filAlignRelFirst ==  1.00) {   
      if (arrayAlignRelFirst1D5E[4] ==  1.00) { 
        coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[4];
        coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[4];
        angRot = arrayAngRot1D5E[4];	
      } else if (arrayAlignRelFirst1D5E[4] == 0.00) { 
        if (arrayAlignRelFirst1D5E[3] ==  1.00) { 
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[3];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  1.00) {
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[2];	 	
        } else {
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[4] -  (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[4] +  (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}		
      } else if (arrayAlignRelFirst1D5E[4] == -1.00) {
        if (arrayAlignRelFirst1D5E[3] ==  1.00) {  // almost impossible
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[3];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[3];	 
        } else if (arrayAlignRelFirst1D5E[2] ==  1.00) {
          coOrX = arrayCoordX1D5E[4] - arrayOriX1D5E[2];
          coOrY = arrayCoordY1D5E[4] - arrayOriY1D5E[2];	 	
        } else {
	  NoOfSubunits = 2*NoOfSubunits;
	  arrayCoordEst[2] = estimateAlignedXY(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, position, subunitRise, NoOfSubunits);
	  // This function assumes that the one closer to [Xo,Yo] is the right one!!!
          coOrX = arrayCoordEst[0];
          coOrY = arrayCoordEst[1];	 
        }	
	if (filDir ==  1.00) { angRotTemp = arrayAngRot1D5E[4] - 2* (0-iParO.helix_twist_mean) ; } else  
	if (filDir == -1.00) { angRotTemp = arrayAngRot1D5E[4] + 2* (0-iParO.helix_twist_mean) ; }  
	
	if (angRotTemp >  180) {angRot = angRotTemp - 360;} else
	if (angRotTemp < -180) {angRot = angRotTemp + 360;} else 
	                       {angRot = angRotTemp;}	
      } else {
        // discontinuous filament
      } // if (arrayAlignRelFirst1D5E[1] == 


    } //if (filAlignRelFirst ==  


  } // if (position ==
  
 
  arrayEST_CoOrX_CoOrY_AngRot[0] = coOrX; 
  arrayEST_CoOrX_CoOrY_AngRot[1] = coOrY; 
  arrayEST_CoOrX_CoOrY_AngRot[2] = angRot; 
  
  return arrayEST_CoOrX_CoOrY_AngRot[3];
}






void SmoothFilamentsInRunDataStarXcrt::smoothFilamentsInRunDataStarXcrt() 
{
  //std::cout.precision(17);
  
  //std::cout.precision (6);
  //std::fixed;
  // O: original (input file)
  // S: smoothed (input file)
  // R: RELION  (output file)
  // N: NEDIT	(output file)
  
  // progress
  std::cout << "working on: " << iParO.inp_run_data_star << "\n";  
   
  //// read
  std::ifstream inputFile (iParO.inp_run_data_star, std::ifstream::in);
  std::string lineInInputFile;
  
         
  if ( inputFile.is_open() )
  {
    int numOfHeaderLines = 0;
    int numOfPtclLines = 0;
    int totalNumOfLines = 0;
    int lineNum = 0;
               
    int micNameCol = 0;
    int coordXCol = 0;  
    int coordYCol = 0;
    int tubeIdCol = 0;
    int helTLCol = 0;      
    int detPixSizeCol = 0;  
    int magCol = 0;	
	  
    std::string micNameCurr = "";
    std::string micNamePrev = "";    
    int tubeIdCurr = 0;	    
    int tubeIdPrev = 0;
    float pixSizeCurr = 0.0;
    float pixSizePrev = 0.0;
    float helTLCurr = 0.0;
    float helTLPrev = 0.0;
    	 	       
       
    int numOfPtclsInCurrFil  = 0;
    int numOfPtclsInTheLongestFil = 0;
    //int lineNumFilStart = 0;
    //int lineNumFilEnd = 0;  
    
    int colNum = 0;
    int numOfCols = 0;
      
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100 
    std::cout << "------------------------------\n";
    //// get the column number of interest, the number of lines, and the number of segments in the longest filament
    while ( std::getline(inputFile, lineInInputFile) )
    {
      
      lineNum = lineNum + 1;
      //std::cout << "lineNum: " << lineNum << "\n";
      
      //// split lines      
      std::vector<std::string> vectorContainingTheSplitLine;
      boost::split(vectorContainingTheSplitLine, lineInInputFile, boost::is_any_of("\t "),boost::token_compress_on );

      //// get column IDs
      if (vectorContainingTheSplitLine.size() == 3 && 
          vectorContainingTheSplitLine[0]     == "_rlnMicrographName") {     
  	  micNameCol	 = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
      if (vectorContainingTheSplitLine.size() == 3 && 
          vectorContainingTheSplitLine[0]     == "_rlnHelicalTubeID" ) {
  	  tubeIdCol	 = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
      if (vectorContainingTheSplitLine.size() == 3 && 
          vectorContainingTheSplitLine[0]     == "_rlnDetectorPixelSize" ) {
  	  detPixSizeCol = std::stoi(vectorContainingTheSplitLine[1].substr(1));}	  
      
      if (vectorContainingTheSplitLine.size() == 3 && 
          vectorContainingTheSplitLine[0]     == "_rlnMagnification" ) {
  	  magCol = std::stoi(vectorContainingTheSplitLine[1].substr(1));}   
      if (vectorContainingTheSplitLine.size() == 3 && 
          vectorContainingTheSplitLine[0]     == "_rlnImageName") {  
  	  imgNameCol	 = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
	         	  
      //// get column IDs    
      if (iParO.rlnCoordinateXLabel           == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnCoordinateX"){
  	  coordXCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
      if (iParO.rlnCoordinateYLabel           == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnCoordinateY"){
  	  coordYCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
	  
      if (iParO.rlnOriginXLabel               == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnOriginX"){
  	  oriXCol    = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
      if (iParO.rlnOriginYLabel               == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnOriginY"){
  	  oriYCol    = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
	  
      if (iParO.rlnAngleRotLabel              == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnAngleRot"){
  	  angRotCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
      if (iParO.rlnAngleTiltLabel             == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnAngleTilt"){
  	  angTiltCol = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
      if (iParO.rlnAnglePsiLabel              == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnAnglePsi"){
  	  angPsiCol  = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
	  
      if (iParO.rlnDefocusULabel              == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnDefocusU"){
  	  defUCol    = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
      if (iParO.rlnDefocusVLabel              == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnDefocusV"){
  	  defVCol    = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
      if (iParO.rlnDefocusAngleLabel          == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnDefocusAngle"){
  	  defACol    = std::stoi(vectorContainingTheSplitLine[1].substr(1));}
	  
      if (iParO.rlnHelicalTrackLengthLabel    == "y" && 
          vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0]     == "_rlnHelicalTrackLength"){
  	  helTLCol   = std::stoi(vectorContainingTheSplitLine[1].substr(1));} 
        
      if (vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0].substr(0,4) == "_rln"){
  	  colNum   = std::stoi(vectorContainingTheSplitLine[1].substr(1));
	  if (colNum > numOfCols) { numOfCols = colNum;}}	  
      // std::cout <<    "vectorContainingTheSplitLine.size(): " <<  vectorContainingTheSplitLine.size() 
      //           <<    " numOfCols: " <<  numOfCols << "\n";  
      //   vectorContainingTheSplitLine.size() should be equal to "numOfCols + 2"
      	         
      //// header lines
      if (vectorContainingTheSplitLine.size() <= 3) {
        if (numOfPtclLines <= 0) {
          numOfHeaderLines  = numOfHeaderLines + 1;
	} else {
	  std::cout << "ERROR: No comment line nor blank line is allowed after the header! LINE: " << lineNum << "\n";
	  exit(1);
	} 
 	
      //// particle lines	
      } else { 
        numOfPtclLines =  numOfPtclLines + 1;

        micNameCurr = vectorContainingTheSplitLine[micNameCol]; 
        tubeIdCurr  = std::stod(vectorContainingTheSplitLine[tubeIdCol]);
	
	
        if        ( micNameCurr != micNamePrev || tubeIdCurr != tubeIdPrev ){ // new filament
	  //// process the previous filament
	  if (numOfPtclsInCurrFil != 0) { // don't process the 1st data line
	    //std::cout << "numOfPtclsInCurrFil: " << numOfPtclsInCurrFil << "\n";
	    if ( numOfPtclsInCurrFil > numOfPtclsInTheLongestFil ){
	      numOfPtclsInTheLongestFil = numOfPtclsInCurrFil;}
	  } // if (numOfPtclsInCurrFil != 0) {
	  
	     
	  //lineNumFilStart = lineNum -1; // Current line is not 
	  numOfPtclsInCurrFil = 0; 
	  numOfPtclsInCurrFil = numOfPtclsInCurrFil + 1;	  
	  
        } else if ( micNameCurr == micNamePrev && tubeIdCurr == tubeIdPrev ){ // same filament
 	  //lineNumFilEnd = lineNum -1;
	  numOfPtclsInCurrFil = numOfPtclsInCurrFil + 1;
        } // if     ( micNameCurr != micNamePrev || tubeIdCurr != tubeIdPrev ){ // new filament
	
	micNamePrev	= micNameCurr;
	tubeIdPrev	= tubeIdCurr;
      } //if (vectorContainingTheSplitLine.size() <= 3) { 
    } // while inputFile // get info
    
        // work on the last filament
        if (inputFile.eof() ){ // end of the star file 
          //// process the last filament
	    if ( numOfPtclsInCurrFil > numOfPtclsInTheLongestFil ){
	      numOfPtclsInTheLongestFil = numOfPtclsInCurrFil;
	    } //if
        } // if (inputFile.eof() ){
    
    
    std::cout << "numOfHeaderLines             : " << std::right << std::setw(7) << numOfHeaderLines << "\n";
    std::cout << "numOfPtclLines               : " << std::right << std::setw(7) << numOfPtclLines << "\n";
    std::cout << "totalNumOfLines              : " << std::right << std::setw(7) << lineNum << "\n";
    std::cout << "numOfPtclsInTheLongestFil    : " << std::right << std::setw(7) << numOfPtclsInTheLongestFil << "\n";
    std::cout << "------------------------------\n";    
    
////////10////////20////////30////////40////////50////////60////////70////////80////////90///////100    
    numOfPtclLines = 0;
    totalNumOfLines = lineNum;
    lineNum = 0;
    numOfPtclsInCurrFil = 0;
    
    double oriX = 0.00; // _rlnOriginX in each particle
    double oriY = 0.00; // _rlnOriginY in each particle  
    int flagPrinted = 0;
    
    currAlignRelPrev = -100000.00;
    currAlignRelFirst = -100000.00;
    prevAlignRelFirst = 0.00;
    numOfcurrAlignRelFirstZ0 = 0;
    numOfcurrAlignRelFirstM1 = 0;
    numOfcurrAlignRelFirstP1 = 0;
    numOfcurrAlignRelFirstM2 = 0;
    numOfcurrAlignRelFirstP2 = 0;
    discon  = 0.00;
    nonChgLengthZ0 = 0;
    nonChgLengthM1 = 0;
    nonChgLengthP1 = 0; 
    
    currDirRelPrev = 0.00;    
    numOfCurrDirP1 = 0;
    numOfCurrDirM1 = 0;
    numOfCurrDirZ0 = 0;    
    numOfCurrDirXX = 0; 
    
    	    
    std::vector<std::string> vectorImgName1D5E;
    
    std::vector< std::vector<std::string> > tableContainingTheSplitLine(numOfPtclsInTheLongestFil+1); // 0 won't be used
    
    std::ofstream ALLoutputFile(iParO.out_run_data_star_all, std::ofstream::out);  // clean and write
    std::ofstream SELoutputFile(iParO.out_run_data_star_sel, std::ofstream::out);   // clean and write  
       
    //std::ofstream CSRoutputFile(iParO.updated_run_data_star_cal_sel_RLN, std::ofstream::out);  // clean and write
    //std::ofstream SELoutputFile(iParO.updated_run_data_star_cal_sel_CHK, std::ofstream::out);   // clean and write       
        
    //std::ofstream RoutputFile(iParO.updated_run_data_star_RELION, std::ofstream::out);  // clean and write
    //std::ofstream CoutputFile(iParO.updated_run_data_star_CHECK, std::ofstream::out);   // clean and write    
    //std::ofstream outputFile(outputFileName, std::ofstream::out | std::ofstream::app);// append  
    
  
    std::stringstream ALLlineInOutputSS;
    //ALLlineInOutputSS.str(std::string()); // empty the string stream  
             
   
    std::stringstream SELlineInOutputSS;
    //SELlineInOutputSS.str(std::string()); // empty the string stream    
    	
    //std::stringstream RlineInOutputSS;
    //RlineInOutputSS.str(std::string()); // empty the string stream    
    //std::stringstream ClineInOutputSS;
    //ClineInOutputSS.str(std::string()); // empty the string stream    
    
    inputFile.clear();
    inputFile.seekg(0, std::ios::beg); 
    //// smooth filaments
    while ( std::getline(inputFile, lineInInputFile) )
    {
      lineNum = lineNum + 1; 
      //std::cout << "lineNum: " << lineNum << "\n";
      
      //// split lines      
      std::vector<std::string> vectorContainingTheSplitLine;
      boost::split(vectorContainingTheSplitLine, lineInInputFile, boost::is_any_of("\t "),boost::token_compress_on );
      //std::cout << "* size of the vector: " << vectorContainingTheSplitLine.size() << "\n"; 
      // std::size_t usually works better than int when indexing C++ containers, such as std::vectors, std::string.
      //for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++)
  	//  std::cout << vectorContainingTheSplitLine[i] << "\n";
          
      //// print out the header
      if (vectorContainingTheSplitLine.size() <= 3) {
      
        if (numOfPtclLines <= 0) {
          //numOfHeaderLines  = numOfHeaderLines + 1;
	} else {
	  std::cout << "ERROR: No comment line nor blank line is allowed after the header! LINE: " << lineNum << "\n";
	  exit(1);
	} 

 	
   	//EARlineInOutputSS << lineInInputFile;
   	ALLlineInOutputSS << lineInInputFile; 
   	SELlineInOutputSS << lineInInputFile;
	
	
        if (vectorContainingTheSplitLine.size() ==  3  && 
          vectorContainingTheSplitLine[0].substr(0,4) == "_rln"){
  	  colNum   = std::stoi(vectorContainingTheSplitLine[1].substr(1));
	  if (colNum == numOfCols) { 
   	    SELlineInOutputSS << "\n" << "_rlnHelicalRise #" <<  colNum+1 << " \n";
   	    SELlineInOutputSS << "_rlnHelicalTwist #" <<  colNum+2 << " ";	     	  
	  }
	}
	
			
	ALLoutputFile << ALLlineInOutputSS.str() << "\n";
	SELoutputFile << SELlineInOutputSS.str() << "\n";	
	
        ALLlineInOutputSS.str(std::string()); // empty the string stream  
        SELlineInOutputSS.str(std::string()); // empty the string stream 
			  
      //// print out the data lines	
      } else { // any data line

        numOfPtclLines =  numOfPtclLines + 1; // numOfPtclLines/totalNumOfLines can be used to calcualte the progress
	
        micNameCurr = vectorContainingTheSplitLine[micNameCol]; 
        tubeIdCurr  = std::stod(vectorContainingTheSplitLine[tubeIdCol]);
        pixSizeCurr = (double)(std::stod(vectorContainingTheSplitLine[detPixSizeCol])/std::stod(vectorContainingTheSplitLine[magCol])*10000); 
        // um => A
	
	
	//std::cout << "DIAGNOSIS: " << lineInInputFile << "\n";
	
	oriX = std::stod(vectorContainingTheSplitLine[oriXCol]);
	oriY = std::stod(vectorContainingTheSplitLine[oriYCol]);  
        //std::cout << micNameCurr << " " << tubeIdCurr << " shift_dist: " << sqrt (oriX*oriX+oriY*oriY) << "\n";
	
        if        ( micNameCurr != micNamePrev || tubeIdCurr != tubeIdPrev || lineNum == totalNumOfLines){ // new filament
	  //// process the previous filament or last filament (lineNum == totalNumOfLines)
	  
	  if (vectorContainingTheSplitLine.size() > numOfCols && lineNum == totalNumOfLines) { // for the last ptcl in the last fil
	    numOfPtclsInCurrFil = numOfPtclsInCurrFil + 1;
	    for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++) {
	      tableContainingTheSplitLine[numOfPtclsInCurrFil].push_back(vectorContainingTheSplitLine[i]);}
	  } // if (lineNum == totalNumOfLines) 
	    


	  if (numOfPtclsInCurrFil == 0) { // don't process the 1st data line
	    
	  } else if (numOfPtclsInCurrFil >= 6) { // filaments have more than 6 particles	  
            std::cout << "==============================\n"; 	  
	    std::cout << "numOfPtclsInCurrFil: " << numOfPtclsInCurrFil << "\n";  
	    
	    //// 111111111111111111111111111111111111111111111111111111111111111111111111111
	    for (int p=1; p<=numOfPtclsInCurrFil; p++) { // starts from 1, rather than 0.
              std::cout << "------------------------------\n";  
	      //std::cout << "\n";
	      //////////////////////////////////////////////////////////////////////////////
	      //// smooth defU, defV, defA, angTilt, angPsi separately among 5 consecutive segments
	      //// smooth defU among 5 consecutive segments
	      std::cout << "working on: " << p << "\n";  
	      if (p == 1) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][defUCol]), 
		  std::stod(tableContainingTheSplitLine[2][defUCol]),std::stod(tableContainingTheSplitLine[3][defUCol]),
		  std::stod(tableContainingTheSplitLine[4][defUCol]),std::stod(tableContainingTheSplitLine[5][defUCol])}; 
		defU = smoothData1D5E2A(arrayData1D5E, 0);  // postion range: 0-4
		/*std::cout << " U1 = " << tableContainingTheSplitLine[1][defUCol] 
		          << " U2 = " << tableContainingTheSplitLine[2][defUCol] 
		          << " U3 = " << tableContainingTheSplitLine[3][defUCol] 
		          << " U4 = " << tableContainingTheSplitLine[4][defUCol] 
		          << " U5 = " << tableContainingTheSplitLine[5][defUCol] << "\n";*/
	      } else if (p == 2) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][defUCol]), 
		  std::stod(tableContainingTheSplitLine[2][defUCol]),std::stod(tableContainingTheSplitLine[3][defUCol]),
		  std::stod(tableContainingTheSplitLine[4][defUCol]),std::stod(tableContainingTheSplitLine[5][defUCol])}; 
		defU = smoothData1D5E2A(arrayData1D5E, 1);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil-1) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][defUCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][defUCol]),std::stod(tableContainingTheSplitLine[p-1][defUCol]),
		  std::stod(tableContainingTheSplitLine[p][defUCol]),std::stod(tableContainingTheSplitLine[p+1][defUCol])}; 
		defU = smoothData1D5E2A(arrayData1D5E, 3);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][defUCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][defUCol]),std::stod(tableContainingTheSplitLine[p-2][defUCol]),
		  std::stod(tableContainingTheSplitLine[p-1][defUCol]),std::stod(tableContainingTheSplitLine[p][defUCol])}; 
		defU = smoothData1D5E2A(arrayData1D5E, 4);  // postion range: 0-4
	      } else {
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][defUCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][defUCol]),std::stod(tableContainingTheSplitLine[p][defUCol]),
		  std::stod(tableContainingTheSplitLine[p+1][defUCol]),std::stod(tableContainingTheSplitLine[p+2][defUCol])}; 
		defU = smoothData1D5E2A(arrayData1D5E, 2);  // postion range: 0-4
	      } // if (p == 1);
              char sprintfDefU[100];
	      sprintf(sprintfDefU, "%.6f", defU); std::cout << "defU =: " << sprintfDefU << "\n";
	      //std::cout << "U5 =: " << sprintfDefU << "\n";
	      
	      
	      //// smooth defV among 5 consecutive segments
	      if (p == 1) { 	      
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][defVCol]), 
		  std::stod(tableContainingTheSplitLine[2][defVCol]),std::stod(tableContainingTheSplitLine[3][defVCol]),
		  std::stod(tableContainingTheSplitLine[4][defVCol]),std::stod(tableContainingTheSplitLine[5][defVCol])}; 
		defV = smoothData1D5E2A(arrayData1D5E, 0);  // postion range: 0-4
	      } else if (p == 2) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][defVCol]), 
		  std::stod(tableContainingTheSplitLine[2][defVCol]),std::stod(tableContainingTheSplitLine[3][defVCol]),
		  std::stod(tableContainingTheSplitLine[4][defVCol]),std::stod(tableContainingTheSplitLine[5][defVCol])}; 
		defV = smoothData1D5E2A(arrayData1D5E, 1);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil-1) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][defVCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][defVCol]),std::stod(tableContainingTheSplitLine[p-1][defVCol]),
		  std::stod(tableContainingTheSplitLine[p][defVCol]),std::stod(tableContainingTheSplitLine[p+1][defVCol])}; 
		defV = smoothData1D5E2A(arrayData1D5E, 3);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][defVCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][defVCol]),std::stod(tableContainingTheSplitLine[p-2][defVCol]),
		  std::stod(tableContainingTheSplitLine[p-1][defVCol]),std::stod(tableContainingTheSplitLine[p][defVCol])}; 
		defV = smoothData1D5E2A(arrayData1D5E, 4);  // postion range: 0-4
	      } else {
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][defVCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][defVCol]),std::stod(tableContainingTheSplitLine[p][defVCol]),
		  std::stod(tableContainingTheSplitLine[p+1][defVCol]),std::stod(tableContainingTheSplitLine[p+2][defVCol])}; 
		defV = smoothData1D5E2A(arrayData1D5E, 2);  // postion range: 0-4
	      } // if (p == 1);
              char sprintfDefV[100];
	      sprintf(sprintfDefV, "%.6f", defV); std::cout << "defV =: " << sprintfDefV << "\n";
	      //std::cout << "V5 =: " << sprintfDefV << "\n";

	      //// smooth defA among 5 consecutive segments // actually defA doesn't need to be smoothed in most cases.
	      if (p == 1) { 	      
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][defACol]), 
		  std::stod(tableContainingTheSplitLine[2][defACol]),std::stod(tableContainingTheSplitLine[3][defACol]),
		  std::stod(tableContainingTheSplitLine[4][defACol]),std::stod(tableContainingTheSplitLine[5][defACol])}; 
		defA = smoothData1D5E2A(arrayData1D5E, 0);  // postion range: 0-4
	      } else if (p == 2) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][defACol]), 
		  std::stod(tableContainingTheSplitLine[2][defACol]),std::stod(tableContainingTheSplitLine[3][defACol]),
		  std::stod(tableContainingTheSplitLine[4][defACol]),std::stod(tableContainingTheSplitLine[5][defACol])}; 
		defA = smoothData1D5E2A(arrayData1D5E, 1);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil-1) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][defACol]), 
		  std::stod(tableContainingTheSplitLine[p-2][defACol]),std::stod(tableContainingTheSplitLine[p-1][defACol]),
		  std::stod(tableContainingTheSplitLine[p][defACol]),std::stod(tableContainingTheSplitLine[p+1][defACol])}; 
		defA = smoothData1D5E2A(arrayData1D5E, 3);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][defACol]), 
		  std::stod(tableContainingTheSplitLine[p-3][defACol]),std::stod(tableContainingTheSplitLine[p-2][defACol]),
		  std::stod(tableContainingTheSplitLine[p-1][defACol]),std::stod(tableContainingTheSplitLine[p][defACol])}; 
		defA = smoothData1D5E2A(arrayData1D5E, 4);  // postion range: 0-4
	      } else {
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][defACol]), 
		  std::stod(tableContainingTheSplitLine[p-1][defACol]),std::stod(tableContainingTheSplitLine[p][defACol]),
		  std::stod(tableContainingTheSplitLine[p+1][defACol]),std::stod(tableContainingTheSplitLine[p+2][defACol])}; 
		defA = smoothData1D5E2A(arrayData1D5E, 2);  // postion range: 0-4
	      } // if (p == 1);
              char sprintfDefA[100];
	      sprintf(sprintfDefA, "%.6f", defA); std::cout << "defA =: " << sprintfDefA << "\n";
	      //std::cout << "A5 =: " << sprintfDefA << "\n";
	      
	      //// smooth angTilt among 5 consecutive segments 
	      if (p == 1) { 	      
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angTiltCol]), 
		  std::stod(tableContainingTheSplitLine[2][angTiltCol]),std::stod(tableContainingTheSplitLine[3][angTiltCol]),
		  std::stod(tableContainingTheSplitLine[4][angTiltCol]),std::stod(tableContainingTheSplitLine[5][angTiltCol])}; 
		angTilt = smoothData1D5E2A(arrayData1D5E, 0);  // postion range: 0-4
	      } else if (p == 2) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angTiltCol]), 
		  std::stod(tableContainingTheSplitLine[2][angTiltCol]),std::stod(tableContainingTheSplitLine[3][angTiltCol]),
		  std::stod(tableContainingTheSplitLine[4][angTiltCol]),std::stod(tableContainingTheSplitLine[5][angTiltCol])}; 
		angTilt = smoothData1D5E2A(arrayData1D5E, 1);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil-1) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][angTiltCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][angTiltCol]),std::stod(tableContainingTheSplitLine[p-1][angTiltCol]),
		  std::stod(tableContainingTheSplitLine[p][angTiltCol]),std::stod(tableContainingTheSplitLine[p+1][angTiltCol])}; 
		angTilt = smoothData1D5E2A(arrayData1D5E, 3);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][angTiltCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][angTiltCol]),std::stod(tableContainingTheSplitLine[p-2][angTiltCol]),
		  std::stod(tableContainingTheSplitLine[p-1][angTiltCol]),std::stod(tableContainingTheSplitLine[p][angTiltCol])}; 
		angTilt = smoothData1D5E2A(arrayData1D5E, 4);  // postion range: 0-4
	      } else {
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][angTiltCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][angTiltCol]),std::stod(tableContainingTheSplitLine[p][angTiltCol]),
		  std::stod(tableContainingTheSplitLine[p+1][angTiltCol]),std::stod(tableContainingTheSplitLine[p+2][angTiltCol])}; 
		angTilt = smoothData1D5E2A(arrayData1D5E, 2);  // postion range: 0-4
	      } // if (p == 1);
              char sprintfangTilt[100];
	      sprintf(sprintfangTilt, "%.6f", angTilt); std::cout << "angTilt =: " << sprintfangTilt << "\n";
	      //std::cout << "A5 =: " << sprintfangTilt << "\n";
	      
	      //// smooth angPsi among 5 consecutive segments 
	      if (p == 1) { 	      
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angPsiCol]), 
		  std::stod(tableContainingTheSplitLine[2][angPsiCol]),std::stod(tableContainingTheSplitLine[3][angPsiCol]),
		  std::stod(tableContainingTheSplitLine[4][angPsiCol]),std::stod(tableContainingTheSplitLine[5][angPsiCol])}; 
		angPsi = smoothData1D5E2A(arrayData1D5E, 0);  // postion range: 0-4
	      } else if (p == 2) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angPsiCol]), 
		  std::stod(tableContainingTheSplitLine[2][angPsiCol]),std::stod(tableContainingTheSplitLine[3][angPsiCol]),
		  std::stod(tableContainingTheSplitLine[4][angPsiCol]),std::stod(tableContainingTheSplitLine[5][angPsiCol])}; 
		angPsi = smoothData1D5E2A(arrayData1D5E, 1);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil-1) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][angPsiCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][angPsiCol]),std::stod(tableContainingTheSplitLine[p-1][angPsiCol]),
		  std::stod(tableContainingTheSplitLine[p][angPsiCol]),std::stod(tableContainingTheSplitLine[p+1][angPsiCol])}; 
		angPsi = smoothData1D5E2A(arrayData1D5E, 3);  // postion range: 0-4
	      } else if (p == numOfPtclsInCurrFil) { 
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][angPsiCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][angPsiCol]),std::stod(tableContainingTheSplitLine[p-2][angPsiCol]),
		  std::stod(tableContainingTheSplitLine[p-1][angPsiCol]),std::stod(tableContainingTheSplitLine[p][angPsiCol])}; 
		angPsi = smoothData1D5E2A(arrayData1D5E, 4);  // postion range: 0-4
	      } else {
	        double arrayData1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][angPsiCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][angPsiCol]),std::stod(tableContainingTheSplitLine[p][angPsiCol]),
		  std::stod(tableContainingTheSplitLine[p+1][angPsiCol]),std::stod(tableContainingTheSplitLine[p+2][angPsiCol])}; 
		angPsi = smoothData1D5E2A(arrayData1D5E, 2);  // postion range: 0-4
	      } // if (p == 1);
              char sprintfangPsi[100];
	      sprintf(sprintfangPsi, "%.6f", angPsi); std::cout << "angPsi =: " << sprintfangPsi << "\n";
	      //std::cout << "A5 =: " << sprintfangPsi << "\n";
	      
	      //////////////////////////////////////////////////////////////////////////////
	      //// get particle alignment, direction, rise & twist
	      if (p == 1) { 
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordXCol]),std::stod(tableContainingTheSplitLine[3][coordXCol]),
		  std::stod(tableContainingTheSplitLine[4][coordXCol]),std::stod(tableContainingTheSplitLine[5][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordYCol]),std::stod(tableContainingTheSplitLine[3][coordYCol]),
		  std::stod(tableContainingTheSplitLine[4][coordYCol]),std::stod(tableContainingTheSplitLine[5][coordYCol])}; 		  
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriXCol]),std::stod(tableContainingTheSplitLine[3][oriXCol]),
		  std::stod(tableContainingTheSplitLine[4][oriXCol]),std::stod(tableContainingTheSplitLine[5][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriYCol]),std::stod(tableContainingTheSplitLine[3][oriYCol]),
		  std::stod(tableContainingTheSplitLine[4][oriYCol]),std::stod(tableContainingTheSplitLine[5][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[2][angRotCol]),std::stod(tableContainingTheSplitLine[3][angRotCol]),
		  std::stod(tableContainingTheSplitLine[4][angRotCol]),std::stod(tableContainingTheSplitLine[5][angRotCol])};
		vectorImgName1D5E.push_back(tableContainingTheSplitLine[1][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[3][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[4][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[5][imgNameCol]);

		std::cout << "vectorImgName1D5E[0]: " << vectorImgName1D5E[0] << "\n"; 				   		  	  
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 0); 
	      } else if (p == 2) {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordXCol]),std::stod(tableContainingTheSplitLine[3][coordXCol]),
		  std::stod(tableContainingTheSplitLine[4][coordXCol]),std::stod(tableContainingTheSplitLine[5][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordYCol]),std::stod(tableContainingTheSplitLine[3][coordYCol]),
		  std::stod(tableContainingTheSplitLine[4][coordYCol]),std::stod(tableContainingTheSplitLine[5][coordYCol])}; 		  
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriXCol]),std::stod(tableContainingTheSplitLine[3][oriXCol]),
		  std::stod(tableContainingTheSplitLine[4][oriXCol]),std::stod(tableContainingTheSplitLine[5][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriYCol]),std::stod(tableContainingTheSplitLine[3][oriYCol]),
		  std::stod(tableContainingTheSplitLine[4][oriYCol]),std::stod(tableContainingTheSplitLine[5][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[2][angRotCol]),std::stod(tableContainingTheSplitLine[3][angRotCol]),
		  std::stod(tableContainingTheSplitLine[4][angRotCol]),std::stod(tableContainingTheSplitLine[5][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[1][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[3][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[4][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[5][imgNameCol]);

		 
		std::cout << "vectorImgName1D5E[1]: " << vectorImgName1D5E[1] << "\n"; 		 
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 1);			
	      } else if (p == numOfPtclsInCurrFil-1) {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][coordXCol]),std::stod(tableContainingTheSplitLine[p-1][coordXCol]),
		  std::stod(tableContainingTheSplitLine[p][coordXCol]),std::stod(tableContainingTheSplitLine[p+1][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][coordYCol]),std::stod(tableContainingTheSplitLine[p-1][coordYCol]),
		  std::stod(tableContainingTheSplitLine[p][coordYCol]),std::stod(tableContainingTheSplitLine[p+1][coordYCol])}; 
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][oriXCol]),std::stod(tableContainingTheSplitLine[p-1][oriXCol]),
		  std::stod(tableContainingTheSplitLine[p][oriXCol]),std::stod(tableContainingTheSplitLine[p+1][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][oriYCol]),std::stod(tableContainingTheSplitLine[p-1][oriYCol]),
		  std::stod(tableContainingTheSplitLine[p][oriYCol]),std::stod(tableContainingTheSplitLine[p+1][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][angRotCol]),std::stod(tableContainingTheSplitLine[p-1][angRotCol]),
		  std::stod(tableContainingTheSplitLine[p][angRotCol]),std::stod(tableContainingTheSplitLine[p+1][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-3][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p+1][imgNameCol]); 
		std::cout << "vectorImgName1D5E[3]: " << vectorImgName1D5E[3] << "\n"; 
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 3);
	      } else if (p == numOfPtclsInCurrFil) {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][coordXCol]),std::stod(tableContainingTheSplitLine[p-2][coordXCol]),
		  std::stod(tableContainingTheSplitLine[p-1][coordXCol]),std::stod(tableContainingTheSplitLine[p][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][coordYCol]),std::stod(tableContainingTheSplitLine[p-2][coordYCol]),
		  std::stod(tableContainingTheSplitLine[p-1][coordYCol]),std::stod(tableContainingTheSplitLine[p][coordYCol])}; 	
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][oriXCol]),std::stod(tableContainingTheSplitLine[p-2][oriXCol]),
		  std::stod(tableContainingTheSplitLine[p-1][oriXCol]),std::stod(tableContainingTheSplitLine[p][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][oriYCol]),std::stod(tableContainingTheSplitLine[p-2][oriYCol]),
		  std::stod(tableContainingTheSplitLine[p-1][oriYCol]),std::stod(tableContainingTheSplitLine[p][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][angRotCol]),std::stod(tableContainingTheSplitLine[p-2][angRotCol]),
		  std::stod(tableContainingTheSplitLine[p-1][angRotCol]),std::stod(tableContainingTheSplitLine[p][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-4][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-3][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p][imgNameCol]); 
		std::cout << "vectorImgName1D5E[4]: " << vectorImgName1D5E[4] << "\n"; 			   		  	  
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 4);
	      } else {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][coordXCol]),std::stod(tableContainingTheSplitLine[p][coordXCol]),
		  std::stod(tableContainingTheSplitLine[p+1][coordXCol]),std::stod(tableContainingTheSplitLine[p+2][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][coordYCol]),std::stod(tableContainingTheSplitLine[p][coordYCol]),
		  std::stod(tableContainingTheSplitLine[p+1][coordYCol]),std::stod(tableContainingTheSplitLine[p+2][coordYCol])}; 
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][oriXCol]),std::stod(tableContainingTheSplitLine[p][oriXCol]),
		  std::stod(tableContainingTheSplitLine[p+1][oriXCol]),std::stod(tableContainingTheSplitLine[p+2][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][oriYCol]),std::stod(tableContainingTheSplitLine[p][oriYCol]),
		  std::stod(tableContainingTheSplitLine[p+1][oriYCol]),std::stod(tableContainingTheSplitLine[p+2][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][angRotCol]),std::stod(tableContainingTheSplitLine[p][angRotCol]),
		  std::stod(tableContainingTheSplitLine[p+1][angRotCol]),std::stod(tableContainingTheSplitLine[p+2][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-2][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p+1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p+2][imgNameCol]); 
		std::cout << "vectorImgName1D5E[2]: " << vectorImgName1D5E[2] << "\n"; 				   		  	  
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 2);
	      } // if (p == 1);
	      
	      //// print out each particle in current filament
	      for (std::size_t j = 0; j < vectorContainingTheSplitLine.size(); j++) {
	        if (iParO.rlnDefocusULabel == "y" && j == defUCol) {
		  //EARlineInOutputSS << "  " << sprintfDefU;
		  //ALLlineInOutputSS << "  " << sprintfDefU; 
		  flagPrinted = 1;}
			
	        if (iParO.rlnDefocusVLabel == "y" && j == defVCol) {
		  //EARlineInOutputSS << "  " << sprintfDefV;
		  //ALLlineInOutputSS << "  " << sprintfDefV; 
		  flagPrinted = 1;} 
		  
	        if (iParO.rlnDefocusAngleLabel == "y" && j == defACol) {
		  //EARlineInOutputSS << "  " << sprintfDefA;
		  //ALLlineInOutputSS << "  " << sprintfDefA; 
		  flagPrinted = 1;} 
		  		
	        if (iParO.rlnAngleTiltLabel == "y" && j == angTiltCol) {
		  //EARlineInOutputSS << "  " << sprintfangTilt;
		  //ALLlineInOutputSS << "  " << sprintfangTilt; 
		  flagPrinted = 1;} 
		  
	        if (iParO.rlnAnglePsiLabel == "y" && j == angPsiCol) {
		  //EARlineInOutputSS << "  " << sprintfangPsi;
		  //ALLlineInOutputSS << "  " << sprintfangPsi; 
		  flagPrinted = 1;} 
		  
		if (flagPrinted == 0) {
		  //EARlineInOutputSS << "  " << tableContainingTheSplitLine[p][j];
	          //ALLlineInOutputSS << "  " << tableContainingTheSplitLine[p][j];	
		} else {
		  //flagPrinted = 0; 		
		}// if
	      }
	      
	      // MAY NEED TO MOVE THE FOLLOWING TWO LINES TO SOMEWHERE ELSE
	      //EARoutputFile << ALLlineInOutputSS.str() << "\n";
              //EARlineInOutputSS.str(std::string()); // empty the string stream 	
	      
	      //// This module (repeated later) is used for getting the filament alignment & the filament direction  
	      // In class getAlignDirRiseTwist(), the array was defined as following
	      //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[0] = alignRelPrev; 
              //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[1] = directionRel; 
              //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2] = rise; 
              //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3] = twist; 
	      
	      currAlignRelPrev = arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[0];
	      if (currAlignRelPrev == -5.00) { currAlignRelPrev = 0.00; currAlignRelFirst = 0.00; discon = 0.00; // p0
	      
	      } else if (currAlignRelPrev ==  0.00) {
	        if (prevAlignRelFirst ==  0.00) { currAlignRelFirst =  0.00; numOfcurrAlignRelFirstZ0++; discon =  0.00; nonChgLengthZ0++;} else
		if (prevAlignRelFirst == -1.00) { currAlignRelFirst = -1.00; numOfcurrAlignRelFirstM1++; discon =  0.00; nonChgLengthM1++;} else
		if (prevAlignRelFirst ==  1.00) { currAlignRelFirst =  1.00; numOfcurrAlignRelFirstP1++; discon =  0.00; nonChgLengthP1++;}
		prevAlignRelFirst = currAlignRelFirst;	      
	      } else if (currAlignRelPrev ==  -1.00) {
	        if (prevAlignRelFirst ==  0.00) { currAlignRelFirst = -1.00; numOfcurrAlignRelFirstM1++; discon =  0.00;} else
		if (prevAlignRelFirst == -1.00) { currAlignRelFirst = -2.00; numOfcurrAlignRelFirstM2++; discon = -2.00;} else
		if (prevAlignRelFirst ==  1.00) { currAlignRelFirst =  0.00; numOfcurrAlignRelFirstZ0++; discon =  0.00;}
		prevAlignRelFirst = currAlignRelFirst;		      
	      } else if (currAlignRelPrev ==  1.00) {
	        if (prevAlignRelFirst ==  0.00) { currAlignRelFirst =  1.00; numOfcurrAlignRelFirstP1++; discon =  0.00;} else
		if (prevAlignRelFirst == -1.00) { currAlignRelFirst =  0.00; numOfcurrAlignRelFirstZ0++; discon =  0.00;} else
		if (prevAlignRelFirst ==  1.00) { currAlignRelFirst =  2.00; numOfcurrAlignRelFirstP2++; discon =  2.00;}
		prevAlignRelFirst = currAlignRelFirst;	
	      } else if (currAlignRelPrev == -9.00) { currAlignRelPrev = -9.00; currAlignRelFirst = -9.00; discon = -9.00; // NOTE_ADRT ?? 
	      } else {currAlignRelFirst = -10000.00; discon = -8.00;}
	      
	      arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[4] = currAlignRelFirst; 
	      arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[5] = discon;      
	      tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelFirst) );// add 1st extra column at the end; vectorContainingTheSplitLine.size()
	      tableContainingTheSplitLine[p].push_back( std::to_string(discon) );           // add 2nd extra column at the end; vectorContainingTheSplitLine.size()+1
	      tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelPrev) ); // add 3rd extra column at the end; vectorContainingTheSplitLine.size()+2
	      
	      tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2] / cos((angTilt-90) * 3.1415926/180) ) ); // calculated rise;
	      // after 2eca and Refine3D, you NEED to / cos((angTilt-90) * 3.1415926/180) to get rise
	      
	      //tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3] * cos((angTilt-90) * 3.1415926/180) ) ); // calculated twist; 
	      // after 2eca and Refine3D, you DO NO NEED to / cos((angTilt-90) * 3.1415926/180) to get twist	      
	      
	      //tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2]) ); // calculated rise;
	      tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3]) ); // calculated twist; 
	      
	      std::cout << "angTilt: " <<  angTilt << " cos( (angTilt-90) * 3.1415926/180): " <<  cos((angTilt-90) * 3.1415926/180) << "\n";

	      currDirRelPrev = arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[1];
	      if ( currDirRelPrev ==  1.00 ) {numOfCurrDirP1++;} else
	      if ( currDirRelPrev == -1.00 ) {numOfCurrDirM1++;} else
	      if ( currDirRelPrev ==  0.00 ) {numOfCurrDirZ0++;} else	      
	      {numOfCurrDirXX++;}
	      
	      	      
	      //ALLlineInOutputSS << "  " << currAlignRelPrev;   // extra column 1 in output .star file
	      //ALLlineInOutputSS << "  " << currAlignRelFirst;  // extra column 2 in output .star file
	      //ALLlineInOutputSS << "  " << discon;   	     // extra column 3 in output .star file
	      //ALLlineInOutputSS << "  " << currDirRelPrev;     // extra column 4 in output .star file
	      //ALLlineInOutputSS << "  " << arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2]; // estimated rise; extra column 5 in output .star file
	      //ALLlineInOutputSS << "  " << arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3]; // estimated twist; extra column 6 in output .star file	           		      	      
	      //EARoutputFile << ALLlineInOutputSS.str() << "\n";
              //EARlineInOutputSS.str(std::string()); // empty the string stream 	  
	      
	      //ALLoutputFile << ALLlineInOutputSS.str() << "\n";
              //ALLlineInOutputSS.str(std::string()); // empty the string stream   
              
	      vectorImgName1D5E.clear(); // empty the vector
              
	    } // for (int p=1; p<=numOfPtclsInCurrFil; p++) {
	    
            //////////////////////////////////////////////////////////////////////////////
            // get the filament alignment
	    if ((numOfcurrAlignRelFirstZ0 >= numOfcurrAlignRelFirstM1) && (numOfcurrAlignRelFirstZ0 >= numOfcurrAlignRelFirstP1))                     
	       {filAlignRelFirst =  0;} else 
	    if ((numOfcurrAlignRelFirstM1 >= numOfcurrAlignRelFirstP1) && (numOfcurrAlignRelFirstM1 >= numOfcurrAlignRelFirstZ0)) 
	       {filAlignRelFirst = -1;} else 
	    if ((numOfcurrAlignRelFirstP1 >= numOfcurrAlignRelFirstM1) && (numOfcurrAlignRelFirstP1 >= numOfcurrAlignRelFirstZ0))
	       {filAlignRelFirst =  1;} else 	    
	       {filAlignRelFirst =  100; std::cout << "WARNING: CANNOT DETERMININE THE BEST ALIGNMENT FOR THE ABOVE FILAMENT!\n";}
	     
	    // get the filament direction
	    if ((numOfCurrDirP1 > numOfCurrDirM1) && (numOfCurrDirP1 > numOfCurrDirZ0)) {filDir =  1;} else 
	    if ((numOfCurrDirM1 > numOfCurrDirP1) && (numOfCurrDirM1 > numOfCurrDirZ0)) {filDir = -1;} else 
	       {filDir = 0; std::cout << "WARNING: UNKNOWN DIRIRECTION FOR THE ABOVE FILAMENT! " << tableContainingTheSplitLine[1][imgNameCol] << "\n";}	    
	       //{filDir = 0; std::cout << "WARNING: UNKNOWN DIRIRECTION FOR THE ABOVE FILAMENT!\n";}
	     
	    // between tubes
	    ALLoutputFile << "numOfPtclsInCurrFil: "<<numOfPtclsInCurrFil << " filAlignRelFirst: "<<filAlignRelFirst << "\n";
	    std::cout   << "numOfPtclsInCurrFil: "<<numOfPtclsInCurrFil << " filAlignRelFirst: "<<filAlignRelFirst << "\n";	    
	    
	    ALLoutputFile << "numOfCurrDirM1: "<<numOfCurrDirM1<<" numOfCurrDirZ0: "<<numOfCurrDirZ0<<" numOfCurrDirP1: "<<numOfCurrDirP1<< "\n";
	    std::cout   << "numOfCurrDirM1: "<<numOfCurrDirM1<<" numOfCurrDirZ0: "<<numOfCurrDirZ0<<" numOfCurrDirP1: "<<numOfCurrDirP1<< "\n";	    
	    
	    ALLoutputFile << "nonChgLengthM1: "<<nonChgLengthM1<<" nonChgLengthZ0: "<<nonChgLengthZ0<<" nonChgLengthP1: "<<nonChgLengthP1<< "\n";
	    std::cout   << "nonChgLengthM1: "<<nonChgLengthM1<<" nonChgLengthZ0: "<<nonChgLengthZ0<<" nonChgLengthP1: "<<nonChgLengthP1<< "\n";

	    
	    currAlignRelPrev = -100000.00;
	    currAlignRelFirst = -100000.00;
	    prevAlignRelFirst = 0.00;	    	    
	    numOfcurrAlignRelFirstZ0 = 0;
	    numOfcurrAlignRelFirstM1 = 0;
	    numOfcurrAlignRelFirstP1 = 0;
	    numOfcurrAlignRelFirstM2 = 0;
	    numOfcurrAlignRelFirstP2 = 0;
	    discon = 0.00;
	    
	    nonChgLengthZ0 = 0;
	    nonChgLengthM1 = 0;
	    nonChgLengthP1 = 0; 
	    
	    numOfCurrDirP1 = 0;
	    numOfCurrDirM1 = 0;
	    numOfCurrDirZ0 = 0;	          
	    numOfCurrDirXX = 0;
	    
	    
            //// 222222222222222222222222222222222222222222222222222222222222222222222222222	    
	    for (int p=1; p<=numOfPtclsInCurrFil; p++) { // starts from 1, rather than 0.	    
	      //// estimate coordX, coordY, angRot 
	      if (p == 1) { 
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordXCol]),std::stod(tableContainingTheSplitLine[3][coordXCol]),
		  std::stod(tableContainingTheSplitLine[4][coordXCol]),std::stod(tableContainingTheSplitLine[5][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordYCol]),std::stod(tableContainingTheSplitLine[3][coordYCol]),
		  std::stod(tableContainingTheSplitLine[4][coordYCol]),std::stod(tableContainingTheSplitLine[5][coordYCol])}; 		  
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriXCol]),std::stod(tableContainingTheSplitLine[3][oriXCol]),
		  std::stod(tableContainingTheSplitLine[4][oriXCol]),std::stod(tableContainingTheSplitLine[5][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriYCol]),std::stod(tableContainingTheSplitLine[3][oriYCol]),
		  std::stod(tableContainingTheSplitLine[4][oriYCol]),std::stod(tableContainingTheSplitLine[5][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[2][angRotCol]),std::stod(tableContainingTheSplitLine[3][angRotCol]),
		  std::stod(tableContainingTheSplitLine[4][angRotCol]),std::stod(tableContainingTheSplitLine[5][angRotCol])};
		vectorImgName1D5E.push_back(tableContainingTheSplitLine[1][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[3][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[4][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[5][imgNameCol]);
		
	        double arrayAlignRelFirst1D5E[5] = {std::stod(tableContainingTheSplitLine[1][vectorContainingTheSplitLine.size()]), 
		  std::stod(tableContainingTheSplitLine[2][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[3][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[4][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[5][vectorContainingTheSplitLine.size()])};
		
	        double arrayDiscon1D5E[5] = {std::stod(tableContainingTheSplitLine[1][vectorContainingTheSplitLine.size()+1]), 
		  std::stod(tableContainingTheSplitLine[2][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[3][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[4][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[5][vectorContainingTheSplitLine.size()+1])};


		//std::cout << "vectorImgName1D5E[0]: " << vectorImgName1D5E[0] << "\n"; 				   		  	  
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 0);	
		arrayEST_CoOrX_CoOrY_AngRot[3] = estimateCoordxyAngrot(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 0, filAlignRelFirst, filDir, arrayAlignRelFirst1D5E, arrayDiscon1D5E); 					
	      } else if (p == 2) {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordXCol]),std::stod(tableContainingTheSplitLine[3][coordXCol]),
		  std::stod(tableContainingTheSplitLine[4][coordXCol]),std::stod(tableContainingTheSplitLine[5][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[2][coordYCol]),std::stod(tableContainingTheSplitLine[3][coordYCol]),
		  std::stod(tableContainingTheSplitLine[4][coordYCol]),std::stod(tableContainingTheSplitLine[5][coordYCol])}; 		  
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriXCol]),std::stod(tableContainingTheSplitLine[3][oriXCol]),
		  std::stod(tableContainingTheSplitLine[4][oriXCol]),std::stod(tableContainingTheSplitLine[5][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[1][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[2][oriYCol]),std::stod(tableContainingTheSplitLine[3][oriYCol]),
		  std::stod(tableContainingTheSplitLine[4][oriYCol]),std::stod(tableContainingTheSplitLine[5][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[1][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[2][angRotCol]),std::stod(tableContainingTheSplitLine[3][angRotCol]),
		  std::stod(tableContainingTheSplitLine[4][angRotCol]),std::stod(tableContainingTheSplitLine[5][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[1][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[3][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[4][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[5][imgNameCol]);
		
	        double arrayAlignRelFirst1D5E[5] = {std::stod(tableContainingTheSplitLine[1][vectorContainingTheSplitLine.size()]), 
		  std::stod(tableContainingTheSplitLine[2][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[3][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[4][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[5][vectorContainingTheSplitLine.size()])};
		  
	        double arrayDiscon1D5E[5] = {std::stod(tableContainingTheSplitLine[1][vectorContainingTheSplitLine.size()+1]), 
		  std::stod(tableContainingTheSplitLine[2][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[3][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[4][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[5][vectorContainingTheSplitLine.size()+1])};
		  		 
		//std::cout << "vectorImgName1D5E[1]: " << vectorImgName1D5E[1] << "\n"; 	
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 1);	
		arrayEST_CoOrX_CoOrY_AngRot[3] = estimateCoordxyAngrot(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 1, filAlignRelFirst, filDir, arrayAlignRelFirst1D5E, arrayDiscon1D5E);			
	      } else if (p == numOfPtclsInCurrFil-1) {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][coordXCol]),std::stod(tableContainingTheSplitLine[p-1][coordXCol]),
		  std::stod(tableContainingTheSplitLine[p][coordXCol]),std::stod(tableContainingTheSplitLine[p+1][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][coordYCol]),std::stod(tableContainingTheSplitLine[p-1][coordYCol]),
		  std::stod(tableContainingTheSplitLine[p][coordYCol]),std::stod(tableContainingTheSplitLine[p+1][coordYCol])}; 
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][oriXCol]),std::stod(tableContainingTheSplitLine[p-1][oriXCol]),
		  std::stod(tableContainingTheSplitLine[p][oriXCol]),std::stod(tableContainingTheSplitLine[p+1][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][oriYCol]),std::stod(tableContainingTheSplitLine[p-1][oriYCol]),
		  std::stod(tableContainingTheSplitLine[p][oriYCol]),std::stod(tableContainingTheSplitLine[p+1][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[p-2][angRotCol]),std::stod(tableContainingTheSplitLine[p-1][angRotCol]),
		  std::stod(tableContainingTheSplitLine[p][angRotCol]),std::stod(tableContainingTheSplitLine[p+1][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-3][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p+1][imgNameCol]); 
		
	        double arrayAlignRelFirst1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][vectorContainingTheSplitLine.size()]), 
		  std::stod(tableContainingTheSplitLine[p-2][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p-1][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p+1][vectorContainingTheSplitLine.size()])};
		  		
	        double arrayDiscon1D5E[5] = {std::stod(tableContainingTheSplitLine[p-3][vectorContainingTheSplitLine.size()+1]), 
		  std::stod(tableContainingTheSplitLine[p-2][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p-1][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p+1][vectorContainingTheSplitLine.size()+1])};
		  		
		//std::cout << "vectorImgName1D5E[3]: " << vectorImgName1D5E[3] << "\n";
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 3);	
		arrayEST_CoOrX_CoOrY_AngRot[3] = estimateCoordxyAngrot(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 3, filAlignRelFirst, filDir, arrayAlignRelFirst1D5E, arrayDiscon1D5E);
	      } else if (p == numOfPtclsInCurrFil) {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][coordXCol]),std::stod(tableContainingTheSplitLine[p-2][coordXCol]),
		  std::stod(tableContainingTheSplitLine[p-1][coordXCol]),std::stod(tableContainingTheSplitLine[p][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][coordYCol]),std::stod(tableContainingTheSplitLine[p-2][coordYCol]),
		  std::stod(tableContainingTheSplitLine[p-1][coordYCol]),std::stod(tableContainingTheSplitLine[p][coordYCol])}; 	
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][oriXCol]),std::stod(tableContainingTheSplitLine[p-2][oriXCol]),
		  std::stod(tableContainingTheSplitLine[p-1][oriXCol]),std::stod(tableContainingTheSplitLine[p][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][oriYCol]),std::stod(tableContainingTheSplitLine[p-2][oriYCol]),
		  std::stod(tableContainingTheSplitLine[p-1][oriYCol]),std::stod(tableContainingTheSplitLine[p][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[p-3][angRotCol]),std::stod(tableContainingTheSplitLine[p-2][angRotCol]),
		  std::stod(tableContainingTheSplitLine[p-1][angRotCol]),std::stod(tableContainingTheSplitLine[p][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-4][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-3][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-2][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p][imgNameCol]); 
		
	        double arrayAlignRelFirst1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][vectorContainingTheSplitLine.size()]), 
		  std::stod(tableContainingTheSplitLine[p-3][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p-2][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p-1][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()])};
		  		
	        double arrayDiscon1D5E[5] = {std::stod(tableContainingTheSplitLine[p-4][vectorContainingTheSplitLine.size()+1]), 
		  std::stod(tableContainingTheSplitLine[p-3][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p-2][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p-1][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()+1])};
		  		
		//std::cout << "vectorImgName1D5E[4]: " << vectorImgName1D5E[4] << "\n"; 
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 4);			  	  
		arrayEST_CoOrX_CoOrY_AngRot[3] = estimateCoordxyAngrot(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 4, filAlignRelFirst, filDir, arrayAlignRelFirst1D5E, arrayDiscon1D5E);
	      } else {
	        double arrayCoordX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][coordXCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][coordXCol]),std::stod(tableContainingTheSplitLine[p][coordXCol]),
		  std::stod(tableContainingTheSplitLine[p+1][coordXCol]),std::stod(tableContainingTheSplitLine[p+2][coordXCol])}; 
	        double arrayCoordY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][coordYCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][coordYCol]),std::stod(tableContainingTheSplitLine[p][coordYCol]),
		  std::stod(tableContainingTheSplitLine[p+1][coordYCol]),std::stod(tableContainingTheSplitLine[p+2][coordYCol])}; 
	        double arrayOriX1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][oriXCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][oriXCol]),std::stod(tableContainingTheSplitLine[p][oriXCol]),
		  std::stod(tableContainingTheSplitLine[p+1][oriXCol]),std::stod(tableContainingTheSplitLine[p+2][oriXCol])}; 
	        double arrayOriY1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][oriYCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][oriYCol]),std::stod(tableContainingTheSplitLine[p][oriYCol]),
		  std::stod(tableContainingTheSplitLine[p+1][oriYCol]),std::stod(tableContainingTheSplitLine[p+2][oriYCol])}; 		  
	        double arrayAngRot1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][angRotCol]), 
		  std::stod(tableContainingTheSplitLine[p-1][angRotCol]),std::stod(tableContainingTheSplitLine[p][angRotCol]),
		  std::stod(tableContainingTheSplitLine[p+1][angRotCol]),std::stod(tableContainingTheSplitLine[p+2][angRotCol])};
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-2][imgNameCol]); 
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p-1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p+1][imgNameCol]);
	        vectorImgName1D5E.push_back(tableContainingTheSplitLine[p+2][imgNameCol]); 
		
	        double arrayAlignRelFirst1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][vectorContainingTheSplitLine.size()]), 
		  std::stod(tableContainingTheSplitLine[p-1][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p+1][vectorContainingTheSplitLine.size()]),
		  std::stod(tableContainingTheSplitLine[p+2][vectorContainingTheSplitLine.size()])};
		  		
	        double arrayDiscon1D5E[5] = {std::stod(tableContainingTheSplitLine[p-2][vectorContainingTheSplitLine.size()+1]), 
		  std::stod(tableContainingTheSplitLine[p-1][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p+1][vectorContainingTheSplitLine.size()+1]),
		  std::stod(tableContainingTheSplitLine[p+2][vectorContainingTheSplitLine.size()+1])};
		  		
		//std::cout << "vectorImgName1D5E[2]: " << vectorImgName1D5E[2] << "\n"; 		
		arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[6] = getAlignDirRiseTwist(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 2);		   		  	  
		arrayEST_CoOrX_CoOrY_AngRot[3] = estimateCoordxyAngrot(arrayCoordX1D5E, arrayCoordY1D5E, arrayOriX1D5E, arrayOriY1D5E, arrayAngRot1D5E, vectorImgName1D5E, 2, filAlignRelFirst, filDir, arrayAlignRelFirst1D5E, arrayDiscon1D5E);
	      } // if (p == 1);
	      
	      char sprintfCoOrX[100];
	           sprintf(sprintfCoOrX, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[0]); std::cout << "CoOrX =: " << sprintfCoOrX << "\n";
		   
	      char sprintfCoOrY[100];
	           sprintf(sprintfCoOrY, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[1]); std::cout << "CoOrY =: " << sprintfCoOrY << "\n";
		   
		   double oriX = std::stod(tableContainingTheSplitLine[p][coordXCol]) - arrayEST_CoOrX_CoOrY_AngRot[0];	      
	      char sprintfOriX[100];
	           sprintf(sprintfOriX, "%.6f", oriX); std::cout << "OriX =: " << sprintfOriX << "\n";
	           //sprintf(sprintfOriX, "%.6f", 0.00); std::cout << "OriX =: " << sprintfOriX << "\n";
		   		   
		   double oriY = std::stod(tableContainingTheSplitLine[p][coordYCol]) - arrayEST_CoOrX_CoOrY_AngRot[1];	      
	      char sprintfOriY[100];
	           sprintf(sprintfOriY, "%.6f", oriY); std::cout << "OriY =: " << sprintfOriY << "\n";
	           //sprintf(sprintfOriY, "%.6f", 0.00); std::cout << "OriY =: " << sprintfOriY << "\n";
		   		   
	      char sprintfAngRot[100];
	      	   sprintf(sprintfAngRot, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[2]); std::cout << "AngRot =: " << sprintfAngRot << "\n";
		   
		   
	      //// print out each particle in current filament
	      for (std::size_t j = 0; j < vectorContainingTheSplitLine.size(); j++) {
	        /*
	        if (iParO.rlnCoordinateXLabel == "y" && j == coordXCol) { 
		  //char sprintfCoOrX[100];
	          //sprintf(sprintfCoOrX, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[0]); std::cout << "CoOrX =: " << sprintfCoOrX << "\n";
		  //EARlineInOutputSS << "  " << sprintfCoOrX;
		  ALLlineInOutputSS << "  " << sprintfCoOrX; 
		  flagPrinted = 1;}
			
	        if (iParO.rlnCoordinateYLabel == "y" && j == coordYCol) { 
		  //char sprintfCoOrY[100];
	          //sprintf(sprintfCoOrY, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[1]); std::cout << "CoOrY =: " << sprintfCoOrY << "\n";
		  //EARlineInOutputSS << "  " << sprintfCoOrY;
		  ALLlineInOutputSS << "  " << sprintfCoOrY; 
		  flagPrinted = 1;}
		  
	        if (iParO.rlnOriginXLabel == "y" && j == oriXCol) { 
		  //double oriX = std::stod(tableContainingTheSplitLine[p][coordXCol]) - arrayEST_CoOrX_CoOrY_AngRot[0];
		  //char sprintfOriX[100];
	          //sprintf(sprintfOriX, "%.6f", oriX); std::cout << "OriX =: " << sprintfOriX << "\n";
		  //EARlineInOutputSS << "  " << sprintfOriX;
		  ALLlineInOutputSS << "  " << sprintfOriX; 
		  flagPrinted = 1;}
			
	        if (iParO.rlnOriginYLabel == "y" && j == oriYCol) { 
		  //double oriY = std::stod(tableContainingTheSplitLine[p][coordYCol]) - arrayEST_CoOrX_CoOrY_AngRot[1];
		  //char sprintfOriY[100];
	          //sprintf(sprintfOriY, "%.6f", oriY); std::cout << "OriY =: " << sprintfOriY << "\n";
		  //EARlineInOutputSS << "  " << sprintfOriY;
		  ALLlineInOutputSS << "  " << sprintfOriY; 
		  flagPrinted = 1;}
		  
	        if (iParO.rlnAngleRotLabel == "y" && j == angRotCol) { 
		  //char sprintfAngRot[100];
	          //sprintf(sprintfAngRot, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[2]); std::cout << "AngRot =: " << sprintfAngRot << "\n";
		  //EARlineInOutputSS << "  " << sprintfAngRot;
		  ALLlineInOutputSS << "  " << sprintfAngRot; 
		  flagPrinted = 1;}
		*/
		if (flagPrinted == 0) {
		  //EARlineInOutputSS << "  " << tableContainingTheSplitLine[p][j];
	          ALLlineInOutputSS << "  " << tableContainingTheSplitLine[p][j];
		  	
		} else {
		  flagPrinted = 0; 		
		}// if
	      }
	      	
	      
		      
	      //// This module is repeated for printing 
	      // In class getAlignDirRiseTwist(), the array was defined as following
	      //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[0] = alignRelPrev; 
              //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[1] = directionRel; 
              //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2] = rise; 
              //arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3] = twist; 
	      
	      currAlignRelPrev = arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[0];
	      if (currAlignRelPrev == -5.00) { currAlignRelPrev = 0.00; currAlignRelFirst = 0.00; discon = 0.00; // p0
	      
	      } else if (currAlignRelPrev ==  0.00) {
	        if (prevAlignRelFirst ==  0.00) { currAlignRelFirst =  0.00; numOfcurrAlignRelFirstZ0++; discon =  0.00; nonChgLengthZ0++;} else
		if (prevAlignRelFirst == -1.00) { currAlignRelFirst = -1.00; numOfcurrAlignRelFirstM1++; discon =  0.00; nonChgLengthM1++;} else
		if (prevAlignRelFirst ==  1.00) { currAlignRelFirst =  1.00; numOfcurrAlignRelFirstP1++; discon =  0.00; nonChgLengthP1++;}
		prevAlignRelFirst = currAlignRelFirst;	      
	      } else if (currAlignRelPrev ==  -1.00) {
	        if (prevAlignRelFirst ==  0.00) { currAlignRelFirst = -1.00; numOfcurrAlignRelFirstM1++; discon =  0.00;} else
		if (prevAlignRelFirst == -1.00) { currAlignRelFirst = -2.00; numOfcurrAlignRelFirstM2++; discon = -2.00;} else
		if (prevAlignRelFirst ==  1.00) { currAlignRelFirst =  0.00; numOfcurrAlignRelFirstZ0++; discon =  0.00;}
		prevAlignRelFirst = currAlignRelFirst;		      
	      } else if (currAlignRelPrev ==  1.00) {
	        if (prevAlignRelFirst ==  0.00) { currAlignRelFirst =  1.00; numOfcurrAlignRelFirstP1++; discon =  0.00;} else
		if (prevAlignRelFirst == -1.00) { currAlignRelFirst =  0.00; numOfcurrAlignRelFirstZ0++; discon =  0.00;} else
		if (prevAlignRelFirst ==  1.00) { currAlignRelFirst =  2.00; numOfcurrAlignRelFirstP2++; discon =  2.00;}
		prevAlignRelFirst = currAlignRelFirst;	
	      } else if (currAlignRelPrev == -9.00) { currAlignRelPrev = -9.00; currAlignRelFirst = -9.00; discon = -9.00; // NOTE_ADRT ?? 
	      } else {currAlignRelFirst = -10000.00; discon = -8.00;}
	      
	      arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[4] = currAlignRelFirst; 
	      arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[5] = discon;      
	      //tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelFirst) );// add 1st extra column at the end    	            
	      //tableContainingTheSplitLine[p].push_back( std::to_string(discon) );           // add 2nd extra column at the end  
		      
	      currDirRelPrev = arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[1];
	      if ( currDirRelPrev ==  1.00 ) {numOfCurrDirP1++;} else
	      if ( currDirRelPrev == -1.00 ) {numOfCurrDirM1++;} else
	      if ( currDirRelPrev ==  0.00 ) {numOfCurrDirZ0++;} else	      
	      {numOfCurrDirXX++;}

	      ALLlineInOutputSS << "  " << currAlignRelPrev;   // extra column 1 in output .star file
	      ALLlineInOutputSS << "  " << currAlignRelFirst;  // extra column 2 in output .star file
	      ALLlineInOutputSS << "  " << discon;   	       // extra column 3 in output .star file
	      ALLlineInOutputSS << "  " << currDirRelPrev;     // extra column 4 in output .star file
	      ALLlineInOutputSS << "  " << arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2]; // estimated rise; extra column 5 in output .star file // angTilt ignored
	      ALLlineInOutputSS << "  " << arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3]; // estimated twist; extra column 6 in output .star file // angTilt ignored
	      
	      ALLlineInOutputSS << "  " << sprintfCoOrX;   // extra column 1 in output .star file
	      ALLlineInOutputSS << "  " << sprintfCoOrY;   // extra column 2 in output .star file
	      ALLlineInOutputSS << "  " << sprintfOriX;    // extra column 3 in output .star file
	      ALLlineInOutputSS << "  " << sprintfOriY;    // extra column 4 in output .star file
	      ALLlineInOutputSS << "  " << sprintfAngRot;  // estimated rise; extra column 5 in output .star file
	      
	      	           		      	      
	      //EARoutputFile << ALLlineInOutputSS.str() << "\n";
              //EARlineInOutputSS.str(std::string()); // empty the string stream 	  
	      
	      ALLoutputFile << ALLlineInOutputSS.str() << "\n";
              //ALLlineInOutputSS.str(std::string()); // empty the string stream  
	      	      
	      
              ALLlineInOutputSS.str(std::string()); // empty the string stream 	       
	      vectorImgName1D5E.clear(); // empty the vector
	      

	    } // for (int p=1; p<=numOfPtclsInCurrFil; p++) {
	    


	      //tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelFirst) );// add 1st extra column at the end; vectorContainingTheSplitLine.size()
	      //tableContainingTheSplitLine[p].push_back( std::to_string(discon) );           // add 2nd extra column at the end; vectorContainingTheSplitLine.size()+1
	      //tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelPrev) ); // add 3rd extra column at the end; vectorContainingTheSplitLine.size()+2
	      //tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2]) ); // calculated rise;
	      //tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3]) ); // calculated twist; 

            //// 333333333333333333333333333333333333333333333333333333333333333333333333333 

	    
	    int currFilamentHasAtLeastOneContinuousFragment = 0; 
            int numOfMeaningfulBreaks = 0; 
	    for (int p=1; p<=numOfPtclsInCurrFil; p++) { // starts from 1, rather than 0. 
	      
	      ////**** should I print current ptcl? [if (maxNumOfContPtclsInRangeOfPm4AndPp4 >= 5), we should print it out. This implys that curr ptcl is continuous]
	      int numOfContPtclsInRangeOfPm4AndPp4 = 0;
	      int maxNumOfContPtclsInRangeOfPm4AndPp4 = 0; // in range of p-4 and p+4
	      for (int c = p-4; c <= p+4; c++) { // for printing continuous parts of the current filament
	        if (c >= 1 && c <= numOfPtclsInCurrFil) { // meaningful numbers
		  if (std::stod( tableContainingTheSplitLine[c][vectorContainingTheSplitLine.size()+1]) == 0.00) {
		    numOfContPtclsInRangeOfPm4AndPp4++;
		  } else {
		    numOfContPtclsInRangeOfPm4AndPp4 = 0;
		  }		  
		  
		  if (numOfContPtclsInRangeOfPm4AndPp4 > maxNumOfContPtclsInRangeOfPm4AndPp4) {
		    maxNumOfContPtclsInRangeOfPm4AndPp4 = numOfContPtclsInRangeOfPm4AndPp4;
		  }
		  
		} // if (c >= 1 || c <= numOfPtclsInCurrFil) { // meaningful numbers
	      } // for (c = p-4; c <= p+4; c++) { 
	      
	      
	      ////**** should I update the tube ID?  [dealing with tubes with meaningful breaks (curr ptcl is discontinuous, and at least the folloing 5 ptcls are continuous)]
	      // get the original tube ID
	      int tubeIdOrig = 0; // xx (1-99); Here, tubeIdOrig is different from tubeIdCurr used previously. 
	      int tubeIdCont = 0; // continuous tubeID after breaking one filament into continuous filaments (100+xx; 200+xx; ...)
	      tubeIdOrig  = std::stoi(tableContainingTheSplitLine[1][tubeIdCol]); 

              // get the number of meanful breaks	      
	      int numOfContPtclsInRangeOfPp1AndPp5 = 0;
	      int maxNumOfContPtclsInRangeOfPp1AndPp5 = 0; // in range of p-4 and p+4	      
	      for (int c = p+1; c <= p+5; c++) { // for printing continuous parts of the current filament
	        if (c >= 1 && c <= numOfPtclsInCurrFil) { // meaningful numbers
		  if (std::stod( tableContainingTheSplitLine[c][vectorContainingTheSplitLine.size()+1]) == 0.00) {
		    numOfContPtclsInRangeOfPp1AndPp5++;
		  } else {
		    numOfContPtclsInRangeOfPp1AndPp5 = 0;
		  }		  
		  
		  if (numOfContPtclsInRangeOfPp1AndPp5 > maxNumOfContPtclsInRangeOfPp1AndPp5) {
		    maxNumOfContPtclsInRangeOfPp1AndPp5 = numOfContPtclsInRangeOfPp1AndPp5;
		  }
		  
		} // if (c >= 1 || c <= numOfPtclsInCurrFil) { // meaningful numbers
	      } // for (c = p+1; c <= p+5; c++) {
	      
	      
	      ////**** update the tube ID
	      // current ptcl is discontinuous
	      // between 6 and numOfPtclsInCurrFil-5
	      // all 5 ptcls after current ptcl are continuous
	      // there is at least one continuous fragment in the current filament already
	      if (std::stod( tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()+1]) != 0.00 
	          && p >= 6 && p <= numOfPtclsInCurrFil-5 
		  && maxNumOfContPtclsInRangeOfPp1AndPp5 == 5  
		  && currFilamentHasAtLeastOneContinuousFragment == 1 ) {                      
	        numOfMeaningfulBreaks++; 	      
	      } // if (maxNumOfContPtcls >= 5) {

              tubeIdCont = tubeIdOrig + numOfMeaningfulBreaks * 100;
	      std::cout << "tubeIdCol: " << tubeIdCol << " tubeIdOrig: " << tubeIdOrig << " tubeIdCont: " << tubeIdCont << " imgName: " << tableContainingTheSplitLine[p][imgNameCol] << "\n";
	      
	      //tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelFirst) );// add 1st extra column at the end; vectorContainingTheSplitLine.size()
	      //tableContainingTheSplitLine[p].push_back( std::to_string(discon) );           // add 2nd extra column at the end; vectorContainingTheSplitLine.size()+1
	      //tableContainingTheSplitLine[p].push_back( std::to_string(currAlignRelPrev) ); // add 3rd extra column at the end; vectorContainingTheSplitLine.size()+2
	      //tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[2]) ); // calculated rise;
	      //tableContainingTheSplitLine[p].push_back( std::to_string(arrayEST_AliRP_DirRP_Rise_Twist_AliRF_DisC[3]) ); // calculated twist; 
	      
	      ////**** print current ptcl [if (maxNumOfContPtclsInRangeOfPm4AndPp4 >= 5), we should print it out. This implys that curr ptcl is continuous]
	      //if (maxNumOfContPtclsInRangeOfPm4AndPp4 >= 5) {
	      int nextAlignRelPrev;
	      if (p < numOfPtclsInCurrFil) {
	         nextAlignRelPrev = std::stod( tableContainingTheSplitLine[p+1][vectorContainingTheSplitLine.size()+2]);
	      } else {
	         nextAlignRelPrev = 0.00;
	      }
	      
	      // after 2eca (old 1b) and Refine3D, you need to / cos((angTilt-90) * 3.1415926/180) to get rise, but do not need to /--- to get twist
	      double calculated_rise  = std::stod( tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()+3]); 
	      double calculated_twist = std::stod( tableContainingTheSplitLine[p][vectorContainingTheSplitLine.size()+4]); 
	      
	      
	      //if (maxNumOfContPtclsInRangeOfPm4AndPp4 >= 5
	      //  && nextAlignRelPrev == 0.00 
	      //  && fabs(calculated_rise  - iParO.helix_rise_mean)  < iParO.helix_rise_sd  * iParO.helix_rise_range_in_sd 
	      //  && fabs(calculated_twist - iParO.helix_twist_mean) < iParO.helix_twist_sd * iParO.helix_twist_range_in_sd) {	      
	      if (maxNumOfContPtclsInRangeOfPm4AndPp4 >= 5 && currAlignRelPrev ==  0.00) {	      
	        currFilamentHasAtLeastOneContinuousFragment = 1;
     
		//// print out each record of current ptcl; If necessary, the record will be updated
	        for (std::size_t j = 0; j < vectorContainingTheSplitLine.size(); j++) {
	          /*
	          if (iParO.rlnCoordinateXLabel == "y" && j == coordXCol) { 
		    //char sprintfCoOrX[100];
	            //sprintf(sprintfCoOrX, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[0]); std::cout << "CoOrX =: " << sprintfCoOrX << "\n";
		    //EARlineInOutputSS << "  " << sprintfCoOrX;
		    ALLlineInOutputSS << "  " << sprintfCoOrX; 
		    flagPrinted = 1;}
			
	          if (iParO.rlnCoordinateYLabel == "y" && j == coordYCol) { 
		    //char sprintfCoOrY[100];
	            //sprintf(sprintfCoOrY, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[1]); std::cout << "CoOrY =: " << sprintfCoOrY << "\n";
		    //EARlineInOutputSS << "  " << sprintfCoOrY;
		    ALLlineInOutputSS << "  " << sprintfCoOrY; 
		    flagPrinted = 1;}
		  
	          if (iParO.rlnOriginXLabel == "y" && j == oriXCol) { 
		    //double oriX = std::stod(tableContainingTheSplitLine[p][coordXCol]) - arrayEST_CoOrX_CoOrY_AngRot[0];
		    //char sprintfOriX[100];
	            //sprintf(sprintfOriX, "%.6f", oriX); std::cout << "OriX =: " << sprintfOriX << "\n";
		    //EARlineInOutputSS << "  " << sprintfOriX;
		    ALLlineInOutputSS << "  " << sprintfOriX; 
		    flagPrinted = 1;}
			
	          if (iParO.rlnOriginYLabel == "y" && j == oriYCol) { 
		    //double oriY = std::stod(tableContainingTheSplitLine[p][coordYCol]) - arrayEST_CoOrX_CoOrY_AngRot[1];
		    //char sprintfOriY[100];
	            //sprintf(sprintfOriY, "%.6f", oriY); std::cout << "OriY =: " << sprintfOriY << "\n";
		    //EARlineInOutputSS << "  " << sprintfOriY;
		    ALLlineInOutputSS << "  " << sprintfOriY; 
		    flagPrinted = 1;}
		  
	          if (iParO.rlnAngleRotLabel == "y" && j == angRotCol) { 
		    //char sprintfAngRot[100];
	            //sprintf(sprintfAngRot, "%.6f", arrayEST_CoOrX_CoOrY_AngRot[2]); std::cout << "AngRot =: " << sprintfAngRot << "\n";
		    //EARlineInOutputSS << "  " << sprintfAngRot;
		    ALLlineInOutputSS << "  " << sprintfAngRot; 
		    flagPrinted = 1;}
		  */
		  
	          if (j == tubeIdCol) { 
		    char sprintfTubeId[100];
	            sprintf(sprintfTubeId, "%4d", tubeIdCont); //std::cout << "tubeIdCont =: " << tubeIdCont << "\n";
		    //EARlineInOutputSS << "  " << sprintfAngRot;
		    SELlineInOutputSS << "  " << sprintfTubeId; 
		    flagPrinted = 1;}		  
		  
		  
		  if (flagPrinted == 0) {
		    //EARlineInOutputSS << "  " << tableContainingTheSplitLine[p][j];
	            SELlineInOutputSS << "  " << tableContainingTheSplitLine[p][j];
		  	
		  } else {
		    flagPrinted = 0; 		
		  }// if
	        } // for  (std::size_t j = 0; j < vectorContainingTheSplitLine.size(); j++) {	
		
		char sprintfRise[100];
	        sprintf(sprintfRise, "%.6f", calculated_rise); std::cout << "Rise =: " << sprintfRise << "\n";
		char sprintfTwist[100];
	        sprintf(sprintfTwist, "%.6f", calculated_twist); std::cout << "Twist =: " << sprintfTwist << "\n";
		    	
		SELlineInOutputSS << "  " << sprintfRise; 
		SELlineInOutputSS << "  " << sprintfTwist; 		
				 
	        SELoutputFile << SELlineInOutputSS.str() << "\n";
			 		     
	      } // if (maxNumOfContPtclsInRangeOfPm4AndPp4 >= 5) {
	       
              SELlineInOutputSS.str(std::string()); // empty the string stream 	       

	        
	    } // for (int p=1; p<=numOfPtclsInCurrFil; p++) {
	    
	    /***********************
	            tubeIdCurr  = std::stod(vectorContainingTheSplitLine[tubeIdCol]);
        pixSizeCurr = (double)(std::stod(vectorContainingTheSplitLine[detPixSizeCol])/std::stod(vectorContainingTheSplitLine[magCol])*10000); 
        // um => A
	
	
	//std::cout << "DIAGNOSIS: " << lineInInputFile << "\n";
	
	oriX = std::stod(vectorContainingTheSplitLine[oriXCol]);
	oriY = std::stod(vectorContainingTheSplitLine[oriYCol]);  
        //std::cout << micNameCurr << " " << tubeIdCurr << " shift_dist: " << sqrt (oriX*oriX+oriY*oriY) << "\n";
	
        if        ( micNameCurr != micNamePrev || tubeIdCurr != tubeIdPrev || lineNum == totalNumOfLines){ // new filament
	  //// process the previous filament or last filament (lineNum == totalNumOfLines)
	  
	  if (vectorContainingTheSplitLine.size() > numOfCols && lineNum == totalNumOfLines) { // for the last ptcl in the last fil
	    numOfPtclsInCurrFil = numOfPtclsInCurrFil + 1;
	    for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++) {
	      tableContainingTheSplitLine[numOfPtclsInCurrFil].push_back(vectorContainingTheSplitLine[i]);}
	  } // if (lineNum == totalNumOfLines) 
	    


	  if (numOfPtclsInCurrFil == 0) { // don't process the 1st data line
	    
	  } else if (numOfPtclsInCurrFil >= 6) { // filaments have more than 6 particles	  
            std::cout << "==============================\n"; 	  
	    std::cout << "numOfPtclsInCurrFil: " << numOfPtclsInCurrFil << "\n";  
	    
	    //// 111111111111111111111111111111111111111111111111111111111111111111111111111
	    for (int p=1; p<=numOfPtclsInCurrFil; p++) { // starts from 1, rather than 0.

	    ********************/
            currAlignRelPrev = -100000.00;
	    currAlignRelFirst = -100000.00;
	    prevAlignRelFirst = 0.00;	    	    
	    numOfcurrAlignRelFirstZ0 = 0;
	    numOfcurrAlignRelFirstM1 = 0;
	    numOfcurrAlignRelFirstP1 = 0;
	    numOfcurrAlignRelFirstM2 = 0;
	    numOfcurrAlignRelFirstP2 = 0;
	    discon = 0.00;
	    
	    nonChgLengthZ0 = 0;
	    nonChgLengthM1 = 0;
	    nonChgLengthP1 = 0; 
	    
	    numOfCurrDirP1 = 0;
	    numOfCurrDirM1 = 0;
	    numOfCurrDirZ0 = 0;	          
	    numOfCurrDirXX = 0;	    
	    

	    //// 444444444444444444444444444444444444444444444444444444444444444444444444444
	    for (int p=1; p<=numOfPtclsInCurrFil; p++) { // starts from 1, rather than 0. // clear fil w/ >= 6 ptcls
	      tableContainingTheSplitLine[p].clear();  
	      // Clear it before loading it with the ptcls of a new filament, otherwise, new filaments will be appended to old ones.
	      // Because we need to get the information of previous particles, so I can only empty the vector in a new for loop.
	    } // for (int i=1; i<=numOfPtclsInCurrFil; i++) { 	    
	  } else {
	    std::cout << "WARNING: THE RELATED FILAMENT HAS <6 SEGMENTS " << tableContainingTheSplitLine[1][imgNameCol] << "\n";
	    

	    //// ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
	    for (int p=1; p<=numOfPtclsInCurrFil; p++) { // starts from 1, rather than 0. // clear fil w/ < 6 ptcls
	      tableContainingTheSplitLine[p].clear();  
	      // Clear it before loading it with the ptcls of a new filament, otherwise, new filaments will be appended to old ones.
	      // Because we need to get the information of previous particles, so I can only empty the vector in a new for loop.
	    } // for (int i=1; i<=numOfPtclsInCurrFil; i++) { 
	    	    
	  }// if (numOfPtclsInCurrFil != 0) {
	  
          if ( vectorContainingTheSplitLine.size() > numOfCols ) {
	  //// record the info of current particle into a new filament 
	  for (std::size_t k = 0; k < vectorContainingTheSplitLine.size(); k++) {
	    tableContainingTheSplitLine[1].push_back(vectorContainingTheSplitLine[k]);}

	     
	  //lineNumFilStart = lineNum -1;
	  numOfPtclsInCurrFil = 0;
	  numOfPtclsInCurrFil = numOfPtclsInCurrFil + 1;	  
	  }
        } else if (micNameCurr == micNamePrev && tubeIdCurr == tubeIdPrev ){ // same filament
 	  //lineNumFilEnd = lineNum -1;
	  if ( vectorContainingTheSplitLine.size() > numOfCols ) {
	  numOfPtclsInCurrFil = numOfPtclsInCurrFil + 1;
	  for (std::size_t i = 0; i < vectorContainingTheSplitLine.size(); i++) {
	    tableContainingTheSplitLine[numOfPtclsInCurrFil].push_back(vectorContainingTheSplitLine[i]);}
	  } 
	  	  
        } // if   ( micNameCurr != micNamePrev || tubeIdCurr != tubeIdPrev ){ // new filament 
	  
	micNamePrev	= micNameCurr;
	tubeIdPrev	= tubeIdCurr;

      } //if (vectorContainingTheSplitLine.size() <= 3) { 
      
                           
    } // while inputFile // smooth filaments
    
    SELoutputFile.close(); 
    ALLoutputFile.close();      
    inputFile.close();        
  } else {
    std::cout << "Cannot open input file: " << iParO.inp_run_data_star << "\n";
  } // if ( inputFile.is_open() )
  
  //return 0;
   
}; 

 
 
 /*
 0. Before running the program, you should remove the last blank line in .star file
 1. After running the program, you should check the warnings 
 2. Most warnings are like this: 
 WARNING: UNKNOWN DIRIRECTION FOR THE ABOVE FILAMENT! 000031@Extract/job010/Micrographs/dp6_0196.mrcs
numOfCurrDirM1: 0 numOfCurrDirZ0: 11 numOfCurrDirP1: 5
We may loose the rule

	    // get the filament direction
	    if ((numOfCurrDirP1 > numOfCurrDirM1) ) {filDir =  1;} else 
	    if ((numOfCurrDirM1 > numOfCurrDirP1) ) {filDir = -1;} else 
	       {filDir = 0; std::cout << "WARNING: UNKNOWN DIRIRECTION FOR THE ABOVE FILAMENT! " << tableContainingTheSplitLine[1][imgNameCol] << "\n";}	    
	       //{filDir = 0; std::cout << "WARNING: UNKNOWN DIRIRECTION FOR THE ABOVE FILAMENT!\n";}

Should I remove these filaments from further analysis.
3. NOTES: 
smooth_filaments_in_run_data_star -parFile smooth_filaments_in_run_data_star_1a.par > temp1a
cat temp1a | grep "NOTE_ADRT ??" | wc -l ; this number should be devided by 2).
======================================
#################################################


# 1a. SmoothFilament_1a_ExtrContFragBasedOnRiseTwist  // only print the lines (1) in continuous fragment; 
                                                     // est rise and twist, align, direct
# Actually, it only uses class getAlignDirRiseTwist() and //// 3333

# 1b. SmoothFilament_1b_EstCoOrAngRot // estimate the coordX, coordY, oriX, oriY, and angRot
# Actually, it only uses class estCoOrXYAngRot()
# x. run relion reline directly with the output .star (by varying the parameters in small ranges);  
# y. re-extract particles in relion using .star file and run relion refine in GUI (by ignoring all the previous alignment parameters)
# 3sca. SmoothFilament_3sca_CalcRiseTwist // only print the lines (1) in continuous fragment; (2)alignment is 0.00; (3) rise and twist are in ?*sd range        
#                                    // for selecting ptcls that meet the above requirements
# 2b. SmoothFilament_2b_AvgCoOrAng    // averages the coordX, coordY, oriX, oriY, angRot, angTilt, and angPsi  
                                     // for map recons and res est (relion_reconstruct in command line)
#################################################
## rise range is NOT explicitly used
## twist range actually is NOT used
#################################################
All of the flowing are in the class functions; so they are the same in 1a and 1b

##** replace 26.2 with iParO.helix_rise_mean  [about 10 places; half of them were comment lines]
##** For non-actin filaments, replacing twist like this might exclude some ptcls out of these ranges.
** replace  some -166.7  with " (0+iParO.helix_twist_mean) "
            some -166.7  with " +iParO.helix_twist_mean "
** replace 166.7 with " (0-iParO.helix_twist_mean) "   [both getAlignDirRiseTwist() and estimateCoOrXYangRot()]

** replace -193.3 with " (0-iParO.helix_twist_mean-360) " 
** replace 193.3 with " (0+iParO.helix_twist_mean+360) " 

** replace -26.6 with " (0-2*iParO.helix_twist_mean-360) "
** replace -26.7 with " (0-2*iParO.helix_twist_mean-360) "
** replace 26.6 with " (0+2*iParO.helix_twist_mean+360)  " 
** replace -333.4 with " (0+2*iParO.helix_twist_mean) " 
** replace 333.4 with " (0-2*iParO.helix_twist_mean) " 

** replace SOME < 5 with " < iParO.helix_rise_range " 
** replace SOME > 5 with " > iParO.helix_rise_range " 
** replace < 10 with " <2*iParO.helix_rise_range " 
 

** replace -5 with " -iParO.helix_twist_range " 
** replace +5 with " +iParO.helix_twist_range " 


#################################################

To do
0. take a look at the xxxx
1. reextract ptcls using the output .star file from mode 1b
2. rerun relion





*/
