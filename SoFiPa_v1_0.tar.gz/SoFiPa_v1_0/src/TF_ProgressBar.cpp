#include "TF_ProgressBar.h" 

// sleep for a while
#include <chrono>
#include <thread>

void printProgress(double progressPercentage)
{

    int barWidth = 72;
    std::cout << "Progress: [";     
    int progressPosition = barWidth * progressPercentage;
    for (int i = 0; i < barWidth; ++i) {
        if (i < progressPosition) {std::cout << "-";
        } else if (i == progressPosition) {std::cout << ">";
        } else {std::cout << " ";}
    }
    
    if (progressPercentage  < 1.0) {
        std::cout << "] " << int(progressPercentage * 100.0) << "%\r";
    } else {
        std::cout << "] " << int(progressPercentage * 100.0) << "%\n";   
    }
    std::cout.flush();
    
    // sleep for a while
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    
}

















